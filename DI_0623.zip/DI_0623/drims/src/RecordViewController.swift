//
//  RecordViewController.swift
//  drims
//
//  Created by 黄海 on 2020/04/04.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class RecordViewController: UIViewController, UIGestureRecognizerDelegate {
    var startFlg = true
    var isDoing = false
    
    @IBOutlet weak var infoTextView: UITextView!
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var videoTimerLabel: VideoTimerLabel!
    
    var videoRecoder: VideoService!
    @IBOutlet weak var videoFrameView: UIView!
    @IBOutlet var videoFrameViewPanGesture: UIPanGestureRecognizer!
    
    
    @IBAction func handlePan(_ gestureRecognizer: UIPanGestureRecognizer) {
        if gestureRecognizer.state == .began || gestureRecognizer.state == .changed {

            let translation = gestureRecognizer.translation(in: self.view)
            gestureRecognizer.view!.center = CGPoint(x: gestureRecognizer.view!.center.x + translation.x, y: gestureRecognizer.view!.center.y + translation.y)
            gestureRecognizer.setTranslation(CGPoint.zero, in: self.view)
        }
    }

    // start button click
    @IBAction func recordPressed(_ sender: UIButton) {
        // check setting
        let alert = ProcessService.sharedInstance.checkSetting() {
            let vc = self.tabBarController!.viewControllers![3];
            self.tabBarController?.selectedViewController = vc
        }
        
        if alert != nil {
            self.present(alert!, animated: true, completion: nil)
            return
        }
        
        // Get Datas
        print(isDoing)
        if isDoing {
            return;
        }
        
        let queue = DispatchQueue(label: "proc_que")
        let group:DispatchGroup = DispatchGroup()
        
        isDoing = true
        if startFlg {
            UIApplication.shared.isIdleTimerDisabled = true
            
            ProcessService.sharedInstance.startGetDataWhenVideo(completionHandler: {
                ret in
                print("*Process is started.")
                self.startFlg = !self.startFlg
                self.isDoing = false
            })
            
        } else {
            UIApplication.shared.isIdleTimerDisabled = false
            // グループに 「+1」
            group.enter()
            queue.async(group: group) { [weak self] () -> Void in
                ProcessService.sharedInstance.stopGetDataWhenVideo {
                    ret in
                    print("*Process is stoped.")
                    self!.startFlg = !self!.startFlg
                    self!.isDoing = false
                    
                    // グループに 「-1」
                    group.leave()
                }
            }
            
        }
        
        // Get Video
        if videoRecoder.isInitialized{
            
            if (!videoRecoder.isRecording){
                print(CommUtil.date2string(Date())! + " 動画撮像開始.")
                videoRecoder.startRecording()
                videoTimerLabel.startTimer()
            }else{
                // グループに 「+1」
                group.enter()
                queue.async(group: group) { [weak self] () -> Void in
                    self!.videoRecoder.stopRecording(completionHandler: {
                        ret in
                        
                        // ファイル 圧縮
                        DataService.sharedInstance.makeZipFileWhenVideo()
                        
                        print(CommUtil.date2string(Date())! + " 動画撮像終了.")
                        // グループに 「-1」
                        group.leave()
                    })
                }
                
                group.notify(queue: queue) { [weak self] () -> Void in
                    // ファイル 圧縮
//                    DataService.sharedInstance.makeZipFile()
                    print(CommUtil.date2string(Date())! + " ZIPファイルを生成しました.")
                }
            }
        }
        
        updateControls()
    }
    
    // pause button click
    @IBAction func pausePressed(_ sender: UIButton) {
        if videoRecoder.isInitialized{
            
            if (videoRecoder.isPaused){
                
                videoRecoder.resumeRecording()
                
            }else{
                
                videoRecoder.pauseRecording()
            }
        }
        
        updateControls()
    }
    
    // play button click
    @IBAction func playPressed(_ sender: Any) {
        if hasPlayList{
            
            let playListController = PlayListTableViewController(style: .plain)
            
            let navController = UINavigationController(rootViewController: playListController)
            
            self.present(navController, animated: true, completion: nil)
            
        }
    }
    
    var hasPlayList:Bool{
        
        get{
            
            let playList = DataService.sharedInstance.defaults.get(for: .playListKey)

            return playList != nil && playList!.count > 0
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        videoFrameView.layer.borderWidth = 10
        videoFrameView.layer.borderColor = UIColor.white.cgColor
        videoFrameViewPanGesture.delegate = self
        
        self.navigationItem.title = NSLocalizedString("Video", comment: "")
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateControls(_:)), name: .VideoRecordingUpdate, object: nil)
                
        videoRecoder = VideoService()
        setupUI()

        checkCameraPermission()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if videoRecoder.isRecording {
            self.recordPressed(UIButton())
        }
    }
    
    private func checkCameraPermission(){
        
        AVCaptureDevice.requestAccess(for: .video, completionHandler: {(_ granted: Bool) -> Void in
        
            if granted {
            
                DispatchQueue.main.async(execute: {() -> Void in
                    
                    self.startVideoSession()
                })
            }
            else {
                
                DispatchQueue.main.async(execute: {() -> Void in
                
                    let cameraAlertController = UIAlertController(title: "Camera Permission Denied", message: "RegTrac needs access to your camera in order to scan Barcodes. Please enable it", preferredStyle: .alert)
                    
                    cameraAlertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in
                        
                    }))
                    
                    cameraAlertController.addAction(UIAlertAction(title: "Settings", style: .default, handler: { (action) in
                                                    
                        let settingsURL = URL(string: UIApplication.openSettingsURLString)
                        UIApplication.shared.open(settingsURL!, options: [:], completionHandler: nil)

                    }))
                    
                    self.present(cameraAlertController, animated: true, completion: nil)
                })
            }
        })
    }
    
    private func startVideoSession(){
        
        if videoRecoder.setupRecorder(){
            
            setUpCameraPreview()
            
            videoRecoder.resumeSession()
        }
                
        self.view.bringSubviewToFront(recordButton)
        self.view.bringSubviewToFront(pauseButton)
        self.view.bringSubviewToFront(playButton)
        self.view.bringSubviewToFront(videoTimerLabel)
        
        updateControls()
    }

    private func setupUI(){
        recordButton.applyBorder(20.0, color: .white, width: 2)
        pauseButton.applyBorder(20.0, color: .white, width: 2)
        playButton.applyBorder(20.0, color: .white, width: 2)
        videoTimerLabel.applyBorder(20.0, color: .white, width: 2)
        
        if ProcessService.sharedInstance.curtLocation != nil {
            let lat = ProcessService.sharedInstance.curtLocation!.coordinate.latitude
            let lng = ProcessService.sharedInstance.curtLocation!.coordinate.longitude
            self.infoTextView.text = "Loc: " + String(format: "%.5f", lat) + " , " + String(format: "%.5f", lng)
        }
//        recordButton.alpha = 0.8
//        pauseButton.alpha = 0.8
//        playButton.alpha = 0.8
//        videoTimerLabel.alpha = 0.8
        
        updateControls()
    }
    
    @objc private func updateControls(_ notification: Notification? = nil){
        DispatchQueue.main.async {
            self.playButton.isHidden = true
            if self.videoRecoder.isRecording{
                                    
    //            pauseButton.isHidden = false
                self.videoTimerLabel.isHidden = false

                self.recordButton.setTitle("STOP", for: .normal)
                
                if self.videoRecoder.isPaused{
                    
                    self.videoTimerLabel.pauseTimer()
                    
                    self.pauseButton.setTitle("RESUME", for: .normal)
                }else{
                    
                    self.videoTimerLabel.startTimer()

                    self.pauseButton.setTitle("PAUSE", for: .normal)
                }
            }else{
                
                self.videoTimerLabel.stopTimer()
                
                self.recordButton.setTitle("START", for: .normal)
                self.pauseButton.isHidden = true
                self.videoTimerLabel.isHidden = true
                
                if self.hasPlayList{
                    
                    self.playButton.isHidden = false
                }
            }
            
            if notification != nil && notification!.userInfo != nil {
                let msg = notification!.userInfo!["msg"] as! String
                self.infoTextView.text = msg
            }
        }
    }
    
    func setUpCameraPreview() {
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: videoRecoder.session)
        previewLayer.backgroundColor = UIColor.white.cgColor
        previewLayer.videoGravity = .resizeAspectFill

        let rootLayer: CALayer = self.view.layer
        rootLayer.masksToBounds = true
        
        previewLayer.frame = rootLayer.bounds
        
//        rootLayer.addSublayer(previewLayer)
        rootLayer.insertSublayer(previewLayer, at: 0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

extension UIView{
    
    func applyBorder(_ radius:CGFloat, color:UIColor, width:CGFloat){
        
        self.layer.cornerRadius = radius
        self.layer.borderColor = color.cgColor
        self.layer.masksToBounds = true
        self.layer.borderWidth = width
    }
}

extension Notification.Name{
    
    static let VideoRecordingUpdate = Notification.Name("VideoRecordingDoneNotification")
}
