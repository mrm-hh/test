//
//  ViewController.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import UIKit


enum settingItem: String {
    case DeviceID = "device_id"
    case WholeSpan = "wheel_base"
    case Distance = "sensor_position"
    case UserID = "user_id"
    case Password = "password"
}

class SettingViewController: UIViewController {
    static let AccessoryViewHeight: CGFloat = 44.0
    
    let dataService = DataService.sharedInstance

    var sections = [String]()
    var settingsLabel = [[String]]()
    var settingValue = [[String]]()
    
    var rootView = UIView()
    
    private var settingsTableView = UITableView(frame: .zero, style: .plain)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        rootView.frame = CGRect(
            x: 0,
            y: 0,
            width: UIScreen.main.bounds.size.width,
            height: UIScreen.main.bounds.size.height);
//        rootView.frame.origin.x = view.frame.origin.x;
//        rootView.frame.origin.y = view.frame.origin.y;
//        rootView.frame.size.height = view.frame.size.height;
//        rootView.frame.size.width = view.frame.size.width;
//        rootView.backgroundColor = UIColor.init(rgb: 0x769e00)
        view.addSubview(rootView)
//        rootView.layouts([
//            "H:|-[self]-|": .directionLeadingToTrailing,
//            "V:|-[self]-|": .directionLeadingToTrailing,
//        ])
        
        /*
        let footerView = UIView()
        footerView.frame = CGRect(
            x: 0,
            y: UIScreen.main.bounds.size.height - 60,
            width: UIScreen.main.bounds.size.width,
            height: 60);
        footerView.backgroundColor = UIColor.init(rgb: 0x769ecb)
        view.addSubview(footerView)
//        footerView.layouts([
//            "H:|-[self]-|": .directionLeadingToTrailing,
//            "V:[rootView]-[self(60)]-|": .directionLeadingToTrailing,
//        ], with: [
//            "rootView": self.rootView
//        ])
        */
        
        sections = [
            NSLocalizedString("device_info_header", comment: ""),
            NSLocalizedString("server_info_header", comment: "register"),
            NSLocalizedString("app_info", comment: "")]

        for _ in 0 ... 3 {
            settingsLabel.append([])
            settingValue.append([])
        }

        settingsLabel[0] = [
            settingItem.DeviceID.rawValue,
            settingItem.WholeSpan.rawValue,
            settingItem.Distance.rawValue
        ]
        settingsLabel[1] = [
            settingItem.UserID.rawValue,
            settingItem.Password.rawValue
        ]
        settingsLabel[2] = [
            NSLocalizedString("version", comment: ""),
            NSLocalizedString("equipmentid", comment: "")
        ]
        
        settingValue[0] = ["","",""]
        settingValue[1] = ["",""]
        settingValue[2] = ["",""]
        self.loadLocalSettings()
        
        navigationItem.title = NSLocalizedString("Setting", comment: "")

//        mainView = view
        rootView.addSubview(settingsTableView)
        settingsTableView.layouts([
//            "H:|-10-[self]-10-|": .directionLeadingToTrailing,
//            "V:|-10-[self]-10-|": .directionLeadingToTrailing,
            "H:|-[self]-|": .directionLeadingToTrailing,
            "V:|-[self]-|": .directionLeadingToTrailing,
            ])
        settingsTableView.tableHeaderView = UIView(frame: CGRect(x: 0.0,
                                                         y: 0.0,
                                                         width: UIScreen.main.bounds.width,
                                                         height: .leastNonzeroMagnitude))
        settingsTableView.separatorInset = .zero
        settingsTableView.separatorStyle = .none
        settingsTableView.dataSource = self
        settingsTableView.delegate = self
        settingsTableView.register(SettingTableviewCell.self, forCellReuseIdentifier: "Default")
        settingsTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        settingsTableView.separatorInset = UIEdgeInsets.zero
        settingsTableView.reloadData()

        /*
//        let buttonRegister: UIButton = UIButton()
        let buttonRegister: UILabel = UILabel()
//        let AttributedString = NSAttributedString(string: "Copyright© SmartCityInstitute All Rights Reserved.", attributes:[.underlineStyle: NSUnderlineStyle.single.rawValue,
//            NSAttributedString.Key.foregroundColor : UIColor.white])
//        buttonRegister.setAttributedTitle(AttributedString, for: .normal)
//        buttonRegister.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: .touchUpInside)
        buttonRegister.text = "Copyright© SmartCityInstitute All Rights Reserved."
        buttonRegister.font = buttonRegister.font.withSize(14)
        buttonRegister.textColor = UIColor.white
        buttonRegister.textAlignment = .center
        footerView.addSubview(buttonRegister)
        buttonRegister.layouts([
            "H:|-10-[self]-10-|": .directionLeadingToTrailing,
            "V:|-10-[self]-|": .directionLeadingToTrailing,
        ])
        */
//        addRegisterButton()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
    
    func addRegisterButton(){
        var buttonRegister: UIButton = UIButton()
        buttonRegister.setTitle("Regitster from website", for: .normal)
        buttonRegister.setTitleColor(UIColor.blue, for: .normal)
//        buttonRegister.frame = CGRect(15, -50, 300, 500)
        buttonRegister.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: .touchUpInside)
        rootView.addSubview(buttonRegister)
        
        
        buttonRegister.layouts([
            "H:|-20-[self]": .directionLeadingToTrailing,
            "V:[settingsTableView]-10-[self]-10-|": .directionLeadingToTrailing,
        ], with: [
            "settingsTableView": self.settingsTableView
        ])
    }
    
    @objc func procBtnOnClick(_ sender: UIButton) {
        if let url = URL(string: "https://www.smc-road.com"){
            UIApplication.shared.openURL(url as URL)
        }
    }
    
//    deinit {
//        NotificationCenter.default.removeObserver(self)
//    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        dataService.saveSetting()
    }
    
    func loadLocalSettings(){
        // deviceID
        settingValue[0][0] = dataService.setting.devId
        
        // wholespan
        settingValue[0][1] = String(dataService.setting.wheelbase)
        
        // distance
        settingValue[0][2] = String(dataService.setting.sensorPosition)
        
        
        // userID
        settingValue[1][0] = dataService.setting.userId
        
        // password
        settingValue[1][1] = dataService.setting.userPass
        
        // Version
        settingValue[2][0] = dataService.defaults.get(for: .appVersion) as! String
        
        // EquipmentID
        settingValue[2][1] = dataService.defaults.get(for: .deviceID) as! String
    }


}

extension SettingViewController: UITableViewDataSource, UITableViewDelegate {

    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
        view.backgroundColor = UIColor.init(rgb: 0x769ecb)
        let label = UILabel(frame: CGRect(x: 10, y: 0, width: tableView.frame.size.width - 30, height: 50))
        label.text = sections[section]
        label.textColor = UIColor.white

        view.addSubview(label)

        return view
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
//    func tableView(_ tableView: UITableView, rowHeight indexPath: IndexPath) -> CGFloat? {
//        if indexPath.section == 2 {
//            let frame = tableView.rectForRow(at: indexPath)
//            return frame.size.height
//        }
//        return 80
//    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsLabel[section].count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell? = nil
        
        if indexPath.section == 2 {
            cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            let text = settingsLabel[indexPath.section][indexPath.row] + "：" + settingValue[indexPath.section][indexPath.row]
            cell?.textLabel!.font = UIFont.themeFont(with: .level1, strong: .level1, language: .japanese)
//            cell?.textLabel!.sizeToFit()
            cell?.textLabel!.numberOfLines = 1
            
            cell?.backgroundColor = UIColor.themeGrayAlpha5
            
            var attributes: [NSAttributedString.Key: Any] = [:]
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 8.0
            attributes.updateValue(paragraphStyle, forKey: .paragraphStyle)
            cell?.textLabel!.attributedText = NSAttributedString(string:text, attributes: attributes)
            if indexPath.row > 0 {
                cell?.textLabel!.numberOfLines = 2
//                cell?.separatorInset = UIEdgeInsets(top: 0, left: 3, bottom: 0, right: 11);
                let underLineView: UIView = {
                    let underLineView = UIView()
                    underLineView.backgroundColor = .themeUiLightGrayAlpha30
                    return underLineView
                }()
                cell?.contentView.addSubview(underLineView)
                underLineView.layouts([
                    "H:|-15-[self]|": .directionLeadingToTrailing,
                    "V:|-0-[self(1)]": .directionLeadingToTrailing,
                ])
            }
//
//                let layer:CAShapeLayer  = CAShapeLayer.init()
//                let lineLayer:CALayer = CALayer.init()
//                let lineHeight = (1 / UIScreen.main.scale);
//                lineLayer.frame = CGRectMake(CGRectGetMinX(bounds), bounds.size.height-lineHeight, bounds.size.width, lineHeight);
//                lineLayer.backgroundColor = tableView.separatorColor.CGColor;
//                [layer addSublayer:lineLayer];
//
//                UIView *testView = [[UIView alloc] initWithFrame:bounds];
//                [testView.layer insertSublayer:layer atIndex:0];
//                testView.backgroundColor = UIColor.clearColor;
//                cell.backgroundView = testView;
//            }
        } else {
            let tcell = tableView.dequeueReusableCell(withIdentifier: "Default", for: indexPath) as! SettingTableviewCell
            
            tcell.setLabelAndValue(
                label: settingsLabel[indexPath.section][indexPath.row],
                value: settingValue[indexPath.section][indexPath.row])
            tcell.delegate = self
            cell = tcell as UITableViewCell
        }
        cell!.selectionStyle = UITableViewCell.SelectionStyle.none;
        
        
//        if indexPath.section == 1 && indexPath.row == 1 {
//            cell.rightTextField.isSecureTextEntry = true
//        }
        
        
        return cell!
    }
    
//    func getCarInfoLabelText(row: Int) -> String {
//        let labelText: String
//        switch row{
//            case 0: labelText = "DeviceID"
//            case 1: labelText = "Whole span"
//            case 2: labelText = "Distance"
//        default:
//            labelText = ""
//        }
//        return labelText
//    }
//
//    func getUserInfoLabelText(row: Int) -> String {
//        let labelText: String
//        switch row{
//            case 0: labelText = "UserID"
//            case 1: labelText = "Password"
//        default:
//            labelText = ""
//        }
//        return labelText
//    }

//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        switch indexPath.row {
//            case 0:
//                print("1")
////                self.parent?.performSegue(withIdentifier: "showSetting", sender: false)
//            default:
//                return
//        }
//    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.rootView.frame.size.height == UIScreen.main.bounds.height {
                self.rootView.frame.size.height -= keyboardSize.height + SettingViewController.AccessoryViewHeight
            }
            
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.rootView.frame.size.height != UIScreen.main.bounds.height {
            self.rootView.frame.size.height = UIScreen.main.bounds.height
        }
    }
    
}

extension SettingViewController: SettingTableviewCellDelegate {
    func didChanged(label: String, value: String) {
        if NSLocalizedString(settingItem.DeviceID.rawValue, comment: "") == label {
            if !checkID(id: value) {
                DispatchQueue.main.async() {
                    let alert = CommUtil.createAlertWithOnlyClose(
                    NSLocalizedString("Error", comment: ""),
                    message: NSLocalizedString("msg_userid_incorrect", comment: ""))
                    self.present(alert, animated: true, completion: nil)
                }
                return
            }
            dataService.setting.devId = value
        }
        else if NSLocalizedString(settingItem.WholeSpan.rawValue, comment: "") == label {
            if let val = Int(value) {
                dataService.setting.wheelbase = val
            } else {
                dataService.setting.wheelbase = 0
            }
        }
        else if NSLocalizedString(settingItem.Distance.rawValue, comment: "") == label {
            if let val = Int(value) {
                dataService.setting.sensorPosition = val
            } else {
                dataService.setting.sensorPosition = 0
            }
        }
        else if NSLocalizedString(settingItem.UserID.rawValue, comment: "") == label {
//            if !checkID(id: value) {
//                DispatchQueue.main.async() {
//                    let alert = CommUtil.createAlertWithOnlyClose(
//                    NSLocalizedString("Error", comment: ""),
//                    message: NSLocalizedString("msg_userid_incorrect", comment: ""))
//                    self.present(alert, animated: true, completion: nil)
//                }
//                return
//            }
            dataService.setting.userId = value
        }
        else if NSLocalizedString(settingItem.Password.rawValue, comment: "") == label {
            dataService.setting.userPass = value
        }

        self.loadLocalSettings()
    }
    
    // 半角特殊記号チェック(true: OK、false: NG)
    func checkID(id: String) -> Bool {
        var ret = true
        let hankaku = NSCharacterSet(range: NSMakeRange(0x20, 0x7e))
            
        let strs = id.splitInto(1)
        for i in 0..<strs.count {
            let char = strs[i]
            let initialChar = char[char.startIndex]
            // 半角特殊記号なら、NG
            if initialChar.isASCII && !char.isAlphanumeric() {
                ret = false
                break
            }
            print("Char\(i + 1): \(char)")
        }
        return ret
    }
}

