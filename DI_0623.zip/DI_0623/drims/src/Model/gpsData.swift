//
//  gpsData.swift
//  drims
//
//  Created by 黄海 on 2020/05/06.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import Foundation
import CoreLocation

class GpsData: NSObject {
    var lat: String
    var lng: String
    var timestamp: Date?
    
    override init() {
        lat = ""
        lng = ""
        timestamp = nil
        super.init()
    }
    
    init(lat: String, lng: String, timestamp: Date?) {
        self.lat = lat
        self.lng = lng
        self.timestamp = timestamp
        
        super.init()
    }
    
    // distance: from self to other
    // unit: meter
    func distanceTo(other: GpsData) -> Int {
        let nowLoc = CLLocation(latitude: self.lat, longitude: self.lng)
        let toLoc = CLLocation(latitude: other.lat, longitude: other.lng)
        let distance = other.distance(from: toLoc)
        return round(distance)
    }
    
    func toJSON() -> JSON {
        var json:JSON = JSON([:])
        json["timestamp"].string = CommUtil.date2string(timestamp, format: "yyMMddHHmmssSSS")
        json["lat"].string = lat
        json["lng"].string = lng
        return json
    }
}
