//
//  gpsData.swift
//  drims
//
//  Created by 黄海 on 2020/05/06.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import Foundation

class GpsData: NSObject {
    var lat: String
    var lng: String
    var timestamp: Date?
    
    override init() {
        lat = ""
        lng = ""
        timestamp = nil
        super.init()
    }
    
    init(lat: String, lng: String, timestamp: Date?) {
        self.lat = lat
        self.lng = lng
        self.timestamp = timestamp
        
        super.init()
    }
    
    func toJSON() -> JSON {
        var json:JSON = JSON([:])
        json["timestamp"].string = CommUtil.date2string(timestamp, format: "yyMMddHHmmssSSS")
        json["lat"].string = lat
        json["lng"].string = lng
        return json
    }
}
