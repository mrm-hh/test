//
//  SettingsTableviewCell.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import Foundation
import UIKit

protocol FileTableviewCellDelegate: class {
    func checkBoxStatusChanged(status: Bool, row: Int)
}

private let sw:CGFloat = UIScreen.main.bounds.width
class FileTableviewCell: UITableViewCell{
    weak var delegate: FileTableviewCellDelegate?
    
    var gpsFilePath:String = ""
    var row: Int = 0
    var checkBoxStatus: Bool = false
    
    var checkBoxButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage.init(named: "status_unchecked"), for: .normal)
        button.setImage(UIImage.init(named: "status_checked"), for: .selected)
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return button
    }()
    
    var fileNameLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.themeFont(with: .level2, strong: .level1, language: .japanese)
        label.sizeToFit()
        label.numberOfLines = 1
        label.textColor = UIColor.themeUiDarkGray
        return label
    }()
    
    var fileSizeLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.themeFont(with: .level2, strong: .level1, language: .japanese)
        label.sizeToFit()
        label.numberOfLines = 1
        label.textColor = UIColor.themeUiDarkGray
        return label
    }()
    
    var fileCreateDateLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.themeFont(with: .level2, strong: .level1, language: .japanese)
        label.sizeToFit()
        label.numberOfLines = 1
        label.textColor = UIColor.themeUiDarkGray
        label.textAlignment = .right
        return label
    }()
    
    var showGPSUIButton:UILabel = {
        let showgps = UILabel()
        showgps.font = UIFont.themeFont(with: .level2, strong: .level1, language: .japanese)
        showgps.sizeToFit()
        showgps.text = ">"
        showgps.textAlignment = .right
//        showgps.setTitleColor(.lightGray, for: .normal)
//        showgps.contentHorizontalAlignment = .right
//        showgps.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12.0)
//        showgps.titleLabel?.textAlignment = .right
        
        return showgps;
    }()
//    var showGPSUIButton:UIButton = {
//        let showgps = UIButton(frame: CGRect(x: 120, y: 10, width: 20, height: 60))
//        showgps.setTitle(" ＞", for: .normal)
//        showgps.setTitleColor(.lightGray, for: .normal)
//        showgps.contentHorizontalAlignment = .right
//        showgps.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12.0)
//        showgps.titleLabel?.textAlignment = .right
//
//        return showgps;
//    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String!)
    {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        contentView.addSubview(self.checkBoxButton)
        contentView.addSubview(self.fileNameLabel)
        contentView.addSubview(self.fileSizeLabel)
        contentView.addSubview(self.fileCreateDateLabel)
        contentView.addSubview(self.showGPSUIButton)
        
        self.checkBoxButton.layouts([
            "H:|[self(44)]|": .directionLeadingToTrailing,
            "V:|-[self(44)]-|": .alignAllTop
        ], with: [
            "name": self.fileNameLabel
        ])
        
        self.fileNameLabel.layouts([
            "H:|-[checkBox]-[self]-10-|": .directionLeadingToTrailing,
            "V:|-10-[self]-[size]-10-|": .directionLeadingToTrailing
        ], with: [
            "checkBox": self.checkBoxButton,
            "size": self.fileSizeLabel
        ])
        
        self.showGPSUIButton.layouts([
            "H:[self(14)]-0-|": .alignAllRight,
            "V:|-[self]-|": .alignAllTop
        ])
        
        self.fileSizeLabel.layouts([
            "H:|-[checkBox]-[self]-[date]-10-|": .directionLeadingToTrailing
        ], with: [
            "checkBox": self.checkBoxButton,
            "date": self.fileCreateDateLabel
        ])

        self.fileCreateDateLabel.layouts([
            "V:|-14-[name]-[self]-10-|": .directionLeadingToTrailing,
        ], with: [
            "name": self.fileNameLabel
        ])

    }
    
    func setup(name: String, size: String, careateDate: String, gpsFilePath: String, checkBoxStatus: Bool, row: Int) {
        self.fileNameLabel.text = name
        self.fileSizeLabel.text = size
        self.fileCreateDateLabel.text = careateDate
        self.gpsFilePath = gpsFilePath
        self.row = row
        self.checkBoxButton.isSelected = checkBoxStatus
        
        self.checkBoxButton.addTarget(self, action: #selector(checkBoxStatusChanged), for: .touchUpInside)
        
        if gpsFilePath != "" {
            self.showGPSUIButton.isHidden = false
        } else {
            self.showGPSUIButton.isHidden = true
        }
    }
    
    required init?(coder aDecoder: NSCoder)
    {
       super.init(coder: aDecoder)
    }
    
    @objc func checkBoxStatusChanged() {
        self.checkBoxButton.isSelected = !self.checkBoxButton.isSelected
        delegate?.checkBoxStatusChanged(status: self.checkBoxButton.isSelected, row: self.row)
    }
}
