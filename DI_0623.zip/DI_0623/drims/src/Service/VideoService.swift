//
//  VideoService.swift
//  drims
//
//  Created by 黄海 on 2020/04/18.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import Foundation
import AVFoundation
import AVKit
import UIKit
import Vision

class VideoService: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
//    let processService = ProcessService.sharedInstance
    let dataService = DataService.sharedInstance
    
    var isPaused = false
    var isRecording = false
    var discont = false
    
    var timeOffset = CMTimeMake(value: 0, timescale: 0)
//    var lastAudio = CMTimeMake(value: 0, timescale: 0)
    
    var isInitialized: Bool = false
    var isTorchOn: Bool = false{
        
        didSet{
            
            self.toggleTorch(isTorchOn)
        }
    }

    var session: AVCaptureSession!
    var videoDataOutput: AVCaptureVideoDataOutput!
    var audioDataOutput: AVCaptureAudioDataOutput!
    
    var captureQueue : DispatchQueue!
    
    var videoInput:AVAssetWriterInput!
//    var audioInput:AVAssetWriterInput!
        
    var videoWriter:AVAssetWriter!
        
    deinit {
        
        cleanupRecorder()
    }
    
    func setupRecorder() -> Bool{
        
        if isInitialized {
            return true
        }
        
        addObservers()
        
        captureQueue = DispatchQueue(label: "VideoDataOutputQueue")
        
        // Set up default camera settings.
        session = AVCaptureSession()
        // 高解像度の写真品質出力
        session.sessionPreset = .photo
        
        updateCameraSelection()
        // Set up video processing pipeline.
        setUpVideoProcessing()
        
        // Set up audio processing pipeline.
//        setUpAudioProcessing()
                    
        isInitialized = true
        
        return true
    }
    
    private func addObservers(){
        
        removeObservers()
        
        NotificationCenter.default.addObserver(self, selector: #selector(pauseSession), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(stopSession), name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(resumeSession), name: UIApplication.didBecomeActiveNotification, object: nil)
    }
    
    private func removeObservers(){
        
        NotificationCenter.default.removeObserver(self, name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIApplication.didBecomeActiveNotification, object: nil)
    }
    
    // MARK: - Camera setup
    func cleanupVideoProcessing() {
        
        if (session != nil && videoDataOutput != nil) {
            session.removeOutput(videoDataOutput)
        }
        
        videoDataOutput = nil
    }
    
//    func cleanupAudioProcessing() {
//
//        if (session != nil && audioDataOutput != nil) {
//            session.removeOutput(audioDataOutput)
//        }
//
//        audioDataOutput = nil
//    }
    
    func cleanupCaptureSession() {
        
        if session != nil && session.isRunning{
            
            session.stopRunning()
        }
        
        cleanupVideoProcessing()
//        cleanupAudioProcessing()
        
        session = nil
    }
    
    func setUpVideoProcessing() {
        
        videoDataOutput = AVCaptureVideoDataOutput()
                
        let rgbOutputSettings: [AnyHashable: Any] = [kCVPixelBufferPixelFormatTypeKey:
            kCVPixelFormatType_32BGRA]
        
        videoDataOutput.videoSettings = rgbOutputSettings as? [String : Any]
        
        if !session.canAddOutput(videoDataOutput) {
        
            cleanupVideoProcessing()
            print("Failed to setup video output")
            return
        }
        
        videoDataOutput.alwaysDiscardsLateVideoFrames = true
        videoDataOutput.setSampleBufferDelegate(self, queue: captureQueue)
        
        session.addOutput(videoDataOutput)
    }
    
//    func setUpAudioProcessing() {
//
//        audioDataOutput = AVCaptureAudioDataOutput()
//
//        if !session.canAddOutput(audioDataOutput) {
//
//            cleanupAudioProcessing()
//            print("Failed to setup audio output")
//            return
//        }
//
//        audioDataOutput.setSampleBufferDelegate(self, queue: captureQueue)
//
//        session.addOutput(audioDataOutput)
//    }
    
    func updateCameraSelection() {
        
        session.beginConfiguration()
        
        // Remove old inputs
        let oldInputs = session.inputs
        
        for oldInput: AVCaptureInput in oldInputs {
            session.removeInput(oldInput)
        }
        
        // 入力の指定
//        guard let captureDevice = AVCaptureDevice.default(for: .video),
//            let input = try? AVCaptureDeviceInput(device: captureDevice),
//            session.canAddInput(input) else {
//                assertionFailure("Could not initialize for AVMediaTypeVideo for device")
//                return
//        }
        var input : AVCaptureDeviceInput?
        do{
            let captureDevice = AVCaptureDevice.default(for: .video)
            // 指定Frame数設定
            do { try captureDevice!.lockForConfiguration()
                captureDevice!.activeVideoMinFrameDuration = CMTimeMake(value: 1, timescale: Int32(AppConstants.VideoFrameRate))
                captureDevice!.activeVideoMaxFrameDuration = CMTimeMake(value: 1, timescale: Int32(AppConstants.VideoFrameRate))
                captureDevice!.unlockForConfiguration()
            } catch {
                print("LockForConfiguration failed with error: \(error.localizedDescription)")
            }
            
            input = try AVCaptureDeviceInput(device: captureDevice!)
            
            if !session.canAddInput(input!) {
                assertionFailure("Could not initialize for AVMediaTypeVideo for device")
            }
            
        }catch{
            
            print("Could not initialize for AVMediaTypeVideo for device error:\(error)")
        }
        if input == nil {
            // Failed, restore old inputs
            for oldInput: AVCaptureInput in oldInputs {
                session.addInput(oldInput)
            }
        }
        else {
            // Succeeded, set input and update connection states
            session.addInput(input!)
        }
        
//        let mic = AVCaptureDevice.default(for: .audio)
//
//        do{
//
//            let  micInput = try AVCaptureDeviceInput.init(device: mic!)
//
//            if session.canAddInput(micInput){
//
//                session.addInput(micInput)
//
//            }else{
//
//                fatalError("updateCameraSelection canAddInput micInput error")
//            }
//        }catch{
//            
//            fatalError("updateCameraSelection micInput error:\(error)")
//        }
                
        session.commitConfiguration()
    }
    
    func cleanupRecorder() {
        
        stopSession()
        removeObservers()
        
        isInitialized = false
        
        cleanupCaptureSession()
    }
    
    var hasTorch: Bool {
        
        let device = AVCaptureDevice.default(for: .video)
        
        return (device!.hasTorch)
    }
    
    private func getVideoTransform() -> CGAffineTransform {
        
        switch UIDevice.current.orientation {
        case .portrait:
            return .identity
        case .portraitUpsideDown:
            return CGAffineTransform(rotationAngle: .pi)
        case .landscapeLeft:
            return CGAffineTransform(rotationAngle: .pi/2)
        case .landscapeRight:
            return CGAffineTransform(rotationAngle: -.pi/2)
        default:
            return .identity
        }
    }
    
    @discardableResult
    func toggleTorch(_ on: Bool) -> Bool {
        
        if hasTorch == false {
            return false
        }
        
        let device : AVCaptureDevice = AVCaptureDevice.default(for: .video)!
        
        do {
            try device.lockForConfiguration()
            
            if on {
                device.torchMode = .on
            }
            else {
                device.torchMode = .off
            }
            
            device.unlockForConfiguration()
            return true
            
        } catch {
            return false
        }
    }
    
    @objc func resumeSession() {
            
        guard isInitialized else {
            
            return
        }
        
        if session.isRunning {
            return
        }
        session.startRunning()
                    
        if isTorchOn {
            toggleTorch(isTorchOn)
        }
        
        if isRecording{
            
            resumeRecording()
            
            NotificationCenter.default.post(Notification(name: .VideoRecordingUpdate))
        }
    }
    
    @objc func pauseSession() {
    
        print("pauseSession called")
        
        if (session != nil && session.isRunning) {
            
            session.stopRunning()
        }
        
        if isRecording{
            
            pauseRecording()
            
            NotificationCenter.default.post(Notification(name: .VideoRecordingUpdate))
        }
    }
            
    @objc func stopSession() {
        
        print("stopSession called")

        if (session != nil && session.isRunning) {
            session.stopRunning()
        }
        
        if isRecording{
            
            stopRecording(completionHandler: {
                ret in
            })
            
            NotificationCenter.default.post(Notification(name: .VideoRecordingUpdate))
        }
    }
    
    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
//        // CMSampleBufferをCVPixelBufferに変換
//        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
//            assertionFailure("Error: バッファの変換に失敗しました")
//            return
//        }
//
//        // CoreMLのモデルクラスの初期化
//        guard let model = try? VNCoreMLModel(for: Resnet50().model) else {
//            assertionFailure("Error: CoreMLモデルの初期化に失敗しました")
//            return
//        }
//
//        // 画像認識リクエストを作成（引数はモデルとハンドラ）
//        let request = VNCoreMLRequest(model: model) { [weak self] (request: VNRequest, error: Error?) in
////            print(CommUtil.date2string(Date())! + " 画像認識リクエスト作成完了.")
//            guard let results = request.results as? [VNClassificationObservation] else { return }
//
//            // 判別結果とその確信度を上位1件まで表示
//            // identifierは類義語がカンマ区切りで複数書かれていることがあるので、最初の単語のみ取得する
//            let displayText = results.prefix(1).compactMap { "\(Int($0.confidence * 100))% \($0.identifier.components(separatedBy: ", ")[0])" }.joined(separator: "\n")
            var displayText = "Location:"
            var locationText = "--- , ---"
//            if procService.gpsDatas.count > 0 {
//                let gpsData = procService.gpsDatas[ procService.gpsDatas.count - 1 ]
//                locationText = "Location: " + gpsData.lat + " , " + gpsData.lng
//            } else
            if ProcessService.sharedInstance.curtLocation != nil {
                let lat = ProcessService.sharedInstance.curtLocation!.coordinate.latitude
                let lng = ProcessService.sharedInstance.curtLocation!.coordinate.longitude
                locationText = String(format: "%.5f", lat) + " , " + String(format: "%.5f", lng)
                displayText = ProcessService.sharedInstance.curtLocationDesp!
            }
//            DispatchQueue.main.async {
//                self!.infoTextView.text = displayText + "\n" + locationText
//            }
            let n : Notification = Notification(name: .VideoRecordingUpdate,
                                                userInfo: ["msg": displayText + "\n" + locationText])
            NotificationCenter.default.post(n)
//        }

//        // CVPixelBufferに対し、画像認識リクエストを実行
//        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
        
        guard isRecording && isPaused == false else {

            return
        }

//        var isVideo = false
//
//        if output == videoDataOutput{
//
//            isVideo = true
//        }

//        write(sampleBuffer, isVideo: isVideo)
        write(sampleBuffer)
    }
    
    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {

//        print("captureOutput didDrop sampleBuffer: \(sampleBuffer)")
    }
    
//    func write(_ buffer:CMSampleBuffer, isVideo:Bool){
    func write(_ buffer:CMSampleBuffer) {
        
//        setupWriter(buffer, isVideo: isVideo)
        setupWriter(buffer)
        
        if videoWriter == nil{
            
            return
        }
        
        var sampleBuffer:CMSampleBuffer! = buffer
                        
        if (discont)
        {
//            if (isVideo)
//            {
//                return
//            }
            
            discont = false
            
            // calc adjustment
            var pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
                        
//            if lastAudio.flags.contains(.valid)
//            {
//                if timeOffset.flags.contains(.valid)
//                {
//                    pts = CMTimeSubtract(pts, timeOffset)
//                }
//
//                let offset = CMTimeSubtract(pts, lastAudio)
//
//                // this stops us having to set a scale for _timeOffset before we see the first video time
//                if (timeOffset.value == 0)
//                {
//                    timeOffset = offset
//                }
//                else
//                {
//                    timeOffset = CMTimeAdd(timeOffset, offset)
//                }
//            }
//
//            lastAudio.flags = []
        }
                        
        if timeOffset.value > 0
        {
            sampleBuffer = adjustTime(sample: sampleBuffer, offset: timeOffset)
        }
                
        // record most recent time so we know the length of the pause
        var pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        let dur = CMSampleBufferGetDuration(sampleBuffer)
        
        if (dur.value > 0)
        {
            pts = CMTimeAdd(pts, dur);
        }
        
//        if (isVideo == false)
//        {
//            lastAudio = pts;
//        }
                        
        if (CMSampleBufferDataIsReady(sampleBuffer))
        {
            if (videoWriter.status == .unknown)
            {
                print("videoWriter starts...")

                let startTime = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)

                videoInput.transform = CGAffineTransform(rotationAngle: .pi/2)
                
                if videoWriter.startWriting(){
                    
                    videoWriter.startSession(atSourceTime: startTime)
                    
                }else{
                    
                    fatalError("startRecording videoWriter error")
                }
            }
            
            if (videoWriter.status == .failed)
            {
                fatalError("writer error:\(String(describing: videoWriter.error))")
            }
            
//            if (isVideo)
//            {
                if videoInput.isReadyForMoreMediaData
                {
                    videoInput.append(sampleBuffer)
                }else{
                    
                    print("videoInput is not ready")
                }
//            }
//            else
//            {
//                if audioInput.isReadyForMoreMediaData
//                {
//                    audioInput.append(sampleBuffer)
//                }else{
//
//                    print("audioInput is not ready")
//                }
//            }
        }
        
        sampleBuffer = nil
    }
    
    private func adjustTime(sample: CMSampleBuffer, offset:CMTime) -> CMSampleBuffer
    {
        var count: CMItemCount = 0
        CMSampleBufferGetSampleTimingInfoArray(sample, entryCount: 0, arrayToFill: nil, entriesNeededOut: &count);
        var info = [CMSampleTimingInfo](repeating: CMSampleTimingInfo(duration: CMTimeMake(value: 0, timescale: 0), presentationTimeStamp: CMTimeMake(value: 0, timescale: 0), decodeTimeStamp: CMTimeMake(value: 0, timescale: 0)), count: count)
        CMSampleBufferGetSampleTimingInfoArray(sample, entryCount: count, arrayToFill: &info, entriesNeededOut: &count);
        
        for i in 0..<count {
            info[i].decodeTimeStamp = CMTimeSubtract(info[i].decodeTimeStamp, offset);
            info[i].presentationTimeStamp = CMTimeSubtract(info[i].presentationTimeStamp, offset);
        }

        var out: CMSampleBuffer?
        CMSampleBufferCreateCopyWithNewTiming(allocator: nil, sampleBuffer: sample, sampleTimingEntryCount: count, sampleTimingArray: &info, sampleBufferOut: &out);
        
        return out!
    }
    
//    private func setupWriter(_ buffer:CMSampleBuffer, isVideo:Bool){
    private func setupWriter(_ buffer:CMSampleBuffer){
        
//        if videoWriter != nil || isVideo{
        if videoWriter != nil {
            
            return
        }
        
        do{
            let fileTime = dataService.saveTime!
            dataService.createTestItemDir(saveTime: fileTime)
            let videoFileUrl = getVideoFileURL(saveTime: fileTime)
            try videoWriter = AVAssetWriter(outputURL: videoFileUrl, fileType: .mp4)
            
        }catch{
        
            fatalError("startRecording error:\(error)")
        }
                
        let h = videoDataOutput.videoSettings["Height"] as? NSNumber ?? NSNumber(720.0)
        let w = videoDataOutput.videoSettings["Width"] as? NSNumber ?? NSNumber(1280.0)
        
        let outputSettings = [AVVideoCodecKey : AVVideoCodecType.h264, AVVideoWidthKey : w, AVVideoHeightKey : h] as [String : Any]
        
        guard videoWriter.canApply(outputSettings: outputSettings, forMediaType: .video) else {
            
            fatalError("startRecording error: Can't apply the Output settings")
        }
        
        videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: outputSettings)
        videoInput.expectsMediaDataInRealTime = true
        
        if videoWriter.canAdd(videoInput){
            
            videoWriter.add(videoInput)
        }else{
        
            fatalError("startRecording videoInput error")
        }
        
//        let fmt = CMSampleBufferGetFormatDescription(buffer)
//        let desc = CMAudioFormatDescriptionGetStreamBasicDescription(fmt!)
//
//        let ch = desc!.pointee.mChannelsPerFrame
//        let rate = desc!.pointee.mSampleRate
//
//        let audioSettings = [AVFormatIDKey : NSNumber(value: kAudioFormatMPEG4AAC),
//                             AVNumberOfChannelsKey : NSNumber(value: ch),
//                             AVSampleRateKey : NSNumber(value: rate),
//                             AVEncoderBitRateKey : NSNumber(64000)] as [String : Any]
//
//        guard videoWriter.canApply(outputSettings: audioSettings, forMediaType: .audio) else {
//
//            fatalError("startRecording error: Can't apply the Output settings")
//        }
        
//        audioInput = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
//        audioInput.expectsMediaDataInRealTime = true
//
//        if videoWriter.canAdd(audioInput){
//
//            videoWriter.add(audioInput)
//        }else{
//
//            fatalError("startRecording audioInput error")
//        }
    }
    
    @objc func startRecording() {
                
        resumeSession()
        
        videoWriter = nil
        videoInput = nil
//        audioInput = nil
        
        discont = false
        isPaused = false
        isRecording = true
        
//        // set recording time
//        dataService.saveTime = Date()
    }
    
    @objc func pauseRecording() {
                
        isPaused = true
        discont = true
    }
    
    @objc func resumeRecording() {
                
        isPaused = false
    }
    
    @objc func stopRecording(completionHandler: @escaping ( Bool ) -> Void) {
                
        isRecording = false
        
        self.videoWriter.finishWriting { [weak self] () -> Void in
            let fileTime = self!.dataService.saveTime!
            let videoFileUrl = self!.getVideoFileURL(saveTime: fileTime)
            let videoFileNm = self!.videoWriter.outputURL.lastPathComponent
            self!.makeGpsPic(videoUrl: videoFileUrl, completionHandler: {ret in
                
                DispatchQueue.main.async {
                            
                    let defaults = self!.dataService.defaults
                    
                    var playList = defaults.get(for: .playListKey) ?? [String]()
                    
                    playList.append(videoFileNm)
                    print("Videoを作成しました！ (" + videoFileNm + ")")
            //                defaults.setValue(playList, forKey: "playList")
                    playList.sort{ $0 > $1 }
                    defaults.set(playList, for: .playListKey)
                    
                    NotificationCenter.default.post(Notification(name: .VideoRecordingUpdate))
                }
                self!.isRecording = false
                
                self!.videoWriter = nil
                self!.videoInput = nil
                //                self.audioInput = nil
                completionHandler(true)
            })
            
        }
                
    }
    
    // get local url of some files
    func getVideoFileURL(saveTime:Date) -> URL{
//        let fileName = "video_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")! + ".mp4"
        let fileName = dataService.getSaveTargetPathName(saveTime: saveTime) + "/" + dataService.getZipFileName() + "." + AppConstants.VideoExt
        let path = NSHomeDirectory() + AppConstants.DocumentDir
        
        return URL(fileURLWithPath: path + fileName)
    }
    
    func getPicFileURL(saveTime:Date) -> URL{
        let fileName = "gps_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss_SSS")! + ".jpg"
        let path = NSHomeDirectory() + AppConstants.TempDir + AppConstants.ImgDir
        
        return URL(fileURLWithPath: path + fileName)
    }
    
    // get image from video by timeinterval
    func imageFromVideo(url: URL, at time: TimeInterval) -> UIImage? {
        let asset = AVURLAsset(url: url)

        let assetIG = AVAssetImageGenerator(asset: asset)
        assetIG.appliesPreferredTrackTransform = true
        assetIG.apertureMode = AVAssetImageGenerator.ApertureMode.encodedPixels

        let cmTime = CMTime(seconds: time, preferredTimescale: 60)
        let thumbnailImageRef: CGImage
        do {
            thumbnailImageRef = try assetIG.copyCGImage(at: cmTime, actualTime: nil)
        } catch let error {
            print("Error: \(error)")
            return nil
        }

        return UIImage(cgImage: thumbnailImageRef)
    }
    
    func makeGpsPic(videoUrl: URL, completionHandler: @escaping ( Bool ) -> Void) {
        var timeinterval: TimeInterval = 0.0
//        let fileTime = dataService.saveTime!
        
        // GPS情報取得
        let fileUrl = dataService.getGpsFileURL()
        let gpsDatas = JSON(url: fileUrl)
        
        print(CommUtil.date2string(Date())! + " Gps pic get is starting.")
        let startTime: Date = dataService.saveTime!
        let fileManger = FileManager.default
        for (i, v) in gpsDatas {
            // get interval
            var fileTime: Date = CommUtil.string2date(v["timestamp"].string!, format: "yyMMddHHmmssSSS")!
//            let gd = GpsData(lat: v["lat"].string!, lng: v["lng"].string!, timestamp: timestamp)
            timeinterval = fileTime.timeIntervalSince(startTime)
            if timeinterval < 0 {
                timeinterval = 0.0
                fileTime = startTime
            }
            let image = self.imageFromVideo(url: videoUrl, at: timeinterval)
            if image != nil {
                //save png
//                let imageData = image!.pngData()
                // save jpg
//                let compressImage = image?.resized(withPercentage: 0.8)
//                let imageData = compressImage!.jpegData(compressionQuality: 1.0)
                let imageData = image!.jpegData(compressionQuality: 0.8)
                
                let fileURL = self.getPicFileURL(saveTime: fileTime)
                if fileManger.fileExists(atPath: fileURL.path){
                    continue
                }
                do {
                    try imageData!.write(to: fileURL)
                    print(CommUtil.date2string(Date())! + " Pic \(i) is getted!")
                } catch {
                    print(error)
                }
            }
        }
        print(CommUtil.date2string(Date())! + " Gps pic get is ended.")
        
        // callback
        completionHandler(true)
        
//        // グループに 「+1」
//        group.enter()
//        queue.async(group: group) { [weak self] () -> Void in
//            let image = self!.imageFromVideo(url: videoUrl, at: timeinterval)
//            if image != nil {
//                //save png
////                let imageData = image!.pngData()
//                // save jpg
//                let compressImage = image?.resized(withPercentage: 0.8)
//                let imageData = compressImage!.jpegData(compressionQuality: 1.0)
//
//                let documentsURL = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask)[0]
//                let fileURL = self!.getPicFileURL(saveTime: fileTime)
//                do {
//                    try imageData!.write(to: fileURL)
//                } catch {
//                    print(error)
//                }
//            }
//
////            files.append(filename)
//            // グループに 「-1」
//            group.leave()
//        }
//
//        group.notify(queue: queue) { [weak self] () -> Void in
//
//
//            // callback
//            completionHandler(true)
//        }

    }

}
