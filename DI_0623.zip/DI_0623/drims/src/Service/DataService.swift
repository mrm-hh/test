//
//  DataService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import Zip

open class DataService: NSObject{
    // SINGLETON
    public static let sharedInstance : DataService = DataService()
    
    let defaults: Defaults  = Defaults()
  
    var setting: Setting
    var carDataNames: [String]
    
    var isRecording = false
    var saveTime: Date? = nil
  
    var deviceID: String = ""
    var appVersion: String = ""
    var installTime: String = ""
    var drimsId: String = ""
  
    private var fileAcc:FileHandle? = nil
    private let headerAccText = "localTimeStamp , x, y, z"
    private var recordAccText = "init"
    private var fileAngVel:FileHandle? = nil
    private let headerAngVelText = "localTimeStamp , x, y, z"
    private var recordAngVelText = "init"
    private var fileGPS:FileHandle? = nil
    private let headerGpsText = "localTimeStamp , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course"
    private var recordGpsText = "init"
  
    override init() {
        let hasDatas = defaults.has(.carDatasKey)
        if hasDatas {
            carDataNames = defaults.get(for: .carDatasKey)!
            print("Car data list is getted.")
        } else {
            carDataNames = []
        }
        let hasSetting = defaults.has(.settingKey)
        if hasSetting {
            setting = defaults.get(for: .settingKey)!
        } else {
            setting = Setting(devId: "", wheelbase: 0, sensorPosition: 0, userId: "", userPass: "")
        }
        super.init()
        
    }
  
    func saveSetting() {
        defaults.set(setting, for: .settingKey)
    }
    
    func saveSysInfo() {
        defaults.set(appVersion, for: .appVersion)
        defaults.set(deviceID, for: .deviceID)
        defaults.set(drimsId, for: .drimsId)
        defaults.set(installTime, for: .installTime)
    }
    
    func loadData() {
//        deviceID = "2BEA0B88-1DE9-4D96-B25E-FBF702C8957B"
        var flg = defaults.has(.deviceID)
        if flg {
            deviceID = defaults.get(for: .deviceID)!
        }
        
//        appVersion = "1.0"
        flg = defaults.has(.appVersion)
        if flg {
            appVersion = defaults.get(for: .appVersion)!
        }
        
//        installTime = "2020/02/06 00:20:30"
        flg = defaults.has(.installTime)
        if flg {
            installTime = defaults.get(for: .installTime)!
        }
//        drimsId = "xLoKOnZjtN9RmqcpQIPukE05SU8xRQxPsFkDTz1m1lsYZyVMTBHgLrf0Ya90NbKW"
        flg = defaults.has(.drimsId)
        if flg {
            drimsId = defaults.get(for: .drimsId)!
        }
    }
    func startRecording() {
        recordAccText = ""
        recordAccText += headerAccText + "\n"
        recordAngVelText = ""
        recordAngVelText += headerAngVelText + "\n"
        recordGpsText = ""
        recordGpsText += headerGpsText + "\n"
        isRecording = true
        saveTime = Date()
    }
    
    func stopRecording() {
        isRecording = false
      
        // ファイルを閉じる
        if fileAcc != nil {
            fileAcc!.closeFile()
            fileAcc = nil
        }
        if fileAngVel != nil {
            fileAngVel!.closeFile()
            fileAngVel = nil
        }
        if fileGPS != nil {
            fileGPS!.closeFile()
            fileGPS = nil
        }
    }
    
    func addRecordAccText(addText:String) {
        recordAccText += addText + "\n"
//        print("加速度：" + addText)
    }
  
    func addRecordAngVelText(addText:String) {
        recordAngVelText += addText + "\n"
//        print("角速度：" + addText)
    }
    
    func addRecordGpsText(addText:String) {
        recordGpsText += addText + "\n"
//        print("GPS：" + addText)
    }
    
    func createTestItemDir(saveTime: Date) {
        let targetPathName = getSaveTargetPathName(saveTime: saveTime)

        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let targetPath = documentsURL.appendingPathComponent(targetPathName, isDirectory: true)
        do {
            try fileManager.createDirectory(at: targetPath, withIntermediateDirectories: true, attributes: nil)
        } catch let e {
            print(e)
        }
    }
    
    func initWorkDir(createDirFlg: Bool = true) {
        let fmanager = FileManager.default
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir
        do {
            if isDirectory(filePath) {
                try fmanager.removeItem(atPath: filePath)
            }
            if createDirFlg {
                try fmanager.createDirectory(at: URL(fileURLWithPath: filePath), withIntermediateDirectories: true, attributes: nil)
            }
        } catch let e {
            print(e)
        }
    }
    
    func initImgDir(createDirFlg: Bool = true) {
        let fmanager = FileManager.default
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.ImgDir
        do {
            if isDirectory(filePath) {
                try fmanager.removeItem(atPath: filePath)
            }
            if createDirFlg {
                try fmanager.createDirectory(at: URL(fileURLWithPath: filePath), withIntermediateDirectories: true, attributes: nil)
            }
        } catch let e {
            print(e)
        }
    }
    
    func isDirectory(_ dirName: String) -> Bool {
        let fileManager = FileManager.default
        var isDir: ObjCBool = false
        if fileManager.fileExists(atPath: dirName, isDirectory: &isDir) {
            if isDir.boolValue {
                return true
            }
        }
        return false
    }
    
    // 各ファイル保存メソッド
    func saveAccCsv() {
        if !isRecording {
            return
        }
        if fileAcc == nil {
            let recordTitle = "SamplingNumber, 998, SamplingFrequency(Hz), 100, CarID, "
                            + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
            let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
                // + "_" + self.getTimeZoneID() /// TODO:timezone
            let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_acc.dat"
            do {
                try "".write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
                fileAcc = FileHandle(forWritingAtPath: filePath)!
                
            } catch let error as NSError {
                print("Failure to Write Acceleration CSV\n\(error)")
            }
            recordAccText = recordTitle + recordAccText
        }
        let buff = recordAccText
        recordAccText = ""
        do {
          // String->Dataに変換
          let contentData = buff.data(using: .utf8)!
          // 一番うしろにシーク
          fileAcc!.seekToEndOfFile()
          // Dataを書き込み
          fileAcc!.write(contentData)
          
//            try recordAccText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
//            print("Success to Write Acceleration CSV")
        } catch let error as NSError {
            print("Failure to Write Acceleration CSV\n\(error)")
        }
    }
  
    func saveAngVelCsv() {
        if !isRecording {
            return
        }
        if fileAngVel == nil {
            let recordTitle = "SamplingNumber, 998, SamplingFrequency(Hz), 100, CarID, "
                            + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
            let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
                // + "_" + self.getTimeZoneID() /// TODO:timezone
            let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_ang_vel.dat"
          
            do {
                try "".write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
                fileAngVel = FileHandle(forWritingAtPath: filePath)!
            } catch let error as NSError {
                print("Failure to Write Ang & Vel CSV\n\(error)")
            }
            recordAngVelText = recordTitle + recordAngVelText
        }
        let buff = recordAngVelText
        recordAngVelText = ""
        do{
            // String->Dataに変換
            let contentData = buff.data(using: .utf8)!
            // 一番うしろにシーク
            fileAngVel!.seekToEndOfFile()
            // Dataを書き込み
            fileAngVel!.write(contentData)
        }catch let error as NSError{
            print("Failure to Write Ang & Vel CSV\n\(error)")
        }
    }
  
    func saveGpsCsv() {
        if !isRecording {
            return
        }
        if fileGPS == nil {
            let recordTitle = "CarID, " + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
            let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
                // + "_" + self.getTimeZoneID() /// TODO:timezone
            let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_gps.dat"
          
            do {
                try "".write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
                fileGPS = FileHandle(forWritingAtPath: filePath)!
            } catch let error as NSError {
                print("Failure to Write GPS CSV\n\(error)")
            }
            recordGpsText = recordTitle + recordGpsText
        }
        let buff = recordGpsText
        recordGpsText = ""
        do{
            // String->Dataに変換
            let contentData = buff.data(using: .utf8)!
            // 一番うしろにシーク
            fileGPS!.seekToEndOfFile()
            // Dataを書き込み
            fileGPS!.write(contentData)
        }catch let error as NSError{
            print("Failure to Write GPS CSV\n\(error)")
        }
    }
  
    func saveCarCsv()-> String {
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        //+ "_" + self.getTimeZoneID() /// TODO:timezone
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_carinfo.txt"
        var recordCarinfoText = "id, " + setting.devId + "\n"
        recordCarinfoText += "number plate, " + "\n"
        recordCarinfoText += "car model, " + "\n"
        recordCarinfoText += "car no, " + "\n"
        recordCarinfoText += "weight, " + "\n"
        recordCarinfoText += "wheelbase, " + String(setting.wheelbase) + "\n"
        recordCarinfoText += "axle track, " + "\n"
        recordCarinfoText += "angle x, " + "\n"
        recordCarinfoText += "angle y, " + "\n"
        recordCarinfoText += "direction, None" + "\n"
        recordCarinfoText += "directionV, None" + "\n"
        recordCarinfoText += "sensor position, " + String(setting.sensorPosition) + "\n"
        recordCarinfoText += "comment1, " + "\n"
        recordCarinfoText += "comment2, " + "\n"
        recordCarinfoText += "comment3, " + "\n"

        do{
            try recordCarinfoText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write CarInfo CSV")
        }catch let error as NSError{
            print("Failure to Write CarInfo CSV\n\(error)")
        }
        return filePath
    }
  
    func saveMeasurementCsv()-> String {
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        // + "_" + self.getTimeZoneID() /// TODO:timezone
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_measurement.txt"
        var recordMeasurementText = "device id," + deviceID + "\n"
        recordMeasurementText += "app version," + appVersion + "\n"
        recordMeasurementText += "app install time," + installTime + "\n"
        recordMeasurementText += "idrims id," + drimsId + "\n"
        recordMeasurementText += "timezone," + self.getTimeZone() + "\n"
        recordMeasurementText += "start time," + CommUtil.date2string(Date(), format: "yyyy/MM/dd HH:mm:ss")! + "\n"
        do{
            try recordMeasurementText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write Measurement CSV")
        }catch let error as NSError{
            print("Failure to Write Measurement CSV\n\(error)")
        }
        return filePath
    }
    
    func getZipFileName() -> String {
        if self.saveTime == nil {
            return ""
        }
        let fileName = setting.devId + "_data_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
//        let filePathName = NSHomeDirectory() + AppConstants.DocumentDir + fileName + ".zip"
//        return filePathName
        return fileName
    }
    
    func getGpsFileURL() -> URL{
        let fileName = getZipFileName() + "_gps.json"
        let path = NSHomeDirectory() + AppConstants.DocumentDir + getSaveTargetPathName(saveTime: saveTime!) + "/"

        return URL(fileURLWithPath: path + fileName)
    }
    
    func outputGPSInfo(data: [GpsData]){
        // 地図、写真用GPS情報ファイル出力
        var jsonData: JSON = JSON([])
        for i in 0..<data.count {
            let gjson = data[i].toJSON()
            jsonData.array!.append(gjson)
        }
        do {
            if jsonData.error == nil {
                let url = getGpsFileURL()
                try jsonData.description.write(to: url, atomically: false, encoding: .utf8)
            }
        } catch {
            print("gpsファイル出力失敗：\(error)")
        }
    }
    
    func getSaveTargetPathName(saveTime:Date) -> String {
        let fileName = setting.devId + "_data_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")! // + "_" + self.getTimeZoneID() /// TODO:timezone
//        let filePathName = NSHomeDirectory() + AppConstants.DocumentDir + fileName + ".zip"
//        return filePathName
        return fileName
    }
    
    func makeZipFile() {
        let targetPathName = getSaveTargetPathName(saveTime: saveTime!)
        let workPath = URL(fileURLWithPath: NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir, isDirectory: true)
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let targetPath = documentsURL.appendingPathComponent(targetPathName, isDirectory: true)
        do {
            try fileManager.createDirectory(at: targetPath, withIntermediateDirectories: true, attributes: nil)
        } catch let e {
            print(e)
        }
        
        do {
            let _ = try Zip.quickZipFiles([workPath], fileName: targetPathName + "/" + targetPathName)
            var gpsSourceFilePath:URL? = nil
            do {
                let fileURLs = try fileManager.contentsOfDirectory(at: workPath, includingPropertiesForKeys: nil)
                for filePath:URL in fileURLs {
                    if filePath.absoluteString.contains("_gps.dat") {
                        gpsSourceFilePath = filePath
                    }
                }
            } catch {
                print("Error while enumerating files \(workPath): \(error.localizedDescription)")
            }
            
            if gpsSourceFilePath != nil {
                let gpsTargetFilePath = URL(fileURLWithPath:targetPathName + "_gps.dat", relativeTo: targetPath)
                try fileManager.moveItem(at: gpsSourceFilePath!, to: gpsTargetFilePath)
            }
            
            initWorkDir(createDirFlg: false)
        } catch let e {
            print(e)
        }
    }
    
    func makeZipFileWhenVideo() {
        let targetPathName = getSaveTargetPathName(saveTime: saveTime!)
        let workPath = URL(fileURLWithPath: NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir, isDirectory: true)
        let imagePath = URL(fileURLWithPath: NSHomeDirectory() + AppConstants.TempDir + AppConstants.ImgDir, isDirectory: true)
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let targetPath = documentsURL.appendingPathComponent(targetPathName, isDirectory: true)
        do {
            try fileManager.createDirectory(at: targetPath, withIntermediateDirectories: true, attributes: nil)
        } catch let e {
            print(e)
        }
        
        do {
            let _ = try Zip.quickZipFiles([workPath, imagePath], fileName: targetPathName + "/" + targetPathName)
            var gpsSourceFilePath:URL? = nil
            do {
                let fileURLs = try fileManager.contentsOfDirectory(at: workPath, includingPropertiesForKeys: nil)
                for filePath:URL in fileURLs {
                    if filePath.absoluteString.contains("_gps.dat") {
                        gpsSourceFilePath = filePath
                    }
                }
            } catch {
                print("Error while enumerating files \(workPath): \(error.localizedDescription)")
            }
            
            if gpsSourceFilePath != nil {
                let gpsTargetFilePath = URL(fileURLWithPath:targetPathName + "_gps.dat", relativeTo: targetPath)
                try fileManager.moveItem(at: gpsSourceFilePath!, to: gpsTargetFilePath)
            }
            
            initWorkDir(createDirFlg: false)
            initImgDir(createDirFlg: false)
        } catch let e {
            print(e)
        }
    }
    
    func getTimeZone() -> String {
        let zone = NSTimeZone.system
    
        let interval = zone.secondsFromGMT()
        let hourDiff = interval/3600
        
        var ret: String = ""
        if hourDiff >= 0 {
            ret = "UTC+\(hourDiff)"
        } else {
            ret = "UTC\(hourDiff)"
        }

        return ret
    }

    func getTimeZoneID() -> String {
        var timeZoneID = TimeZone.current.identifier
        
        timeZoneID = timeZoneID.replacingOccurrences(of: "/", with: "_")
        
        return timeZoneID
    }
}

extension DefaultsKey {
    static let settingKey = Key<Setting>("settingKey")
    static let carDatasKey = Key<[String]>("carDatasKey")
    static let playListKey = Key<[String]>("playListKey")
    
    static let deviceID = Key<String>("deviceID")
    static let appVersion = Key<String>("appVersion")
    static let installTime = Key<String>("installTime")
    static let drimsId = Key<String>("drimsId")
    
}
