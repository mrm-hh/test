//
//  ProcessService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import CoreLocation
import CoreMotion
import UIKit

open class ProcessService: NSObject {
    // SINGLETON
    public static let sharedInstance : ProcessService = ProcessService()
    
    let dataService = DataService.sharedInstance
    
    let motionManager = CMMotionManager()
    var attitude = SIMD3<Double>.zero
    var gyro = SIMD3<Double>.zero
    var gravity = SIMD3<Double>.zero
    var acc = SIMD3<Double>.zero
    // 現在位置情報
    var curtLocation: CLLocation?
    var curtLocationDesp: String?
    var req: LocationRequest? = nil
    // DeviceMotionの起動時間
    var motionStartTime: Date? = nil
    // 記録済み数
    var motionCnt = 0
    
    // データ採集タイマー
    var getDataTimer: Timer?
    
    // GPS track情報
    var gpsDatas: [GpsData] = []
    
    // 初期処理
    func initProcess() {
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir
        if self.dataService.isDirectory(filePath) {
            self.dataService.saveTime = Date()
            self.dataService.makeZipFile()
        }
        
        dataService.loadData()
        
        // アプリの初期化へ移動
//        if dataService.drimsId == "" {
//            print("初期起動")
//            dataService.drimsId = NSUUID().uuidString
//            dataService.installTime = CommUtil.date2string(Date())!
//            dataService.appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
//            dataService.deviceID = NSUUID().uuidString
//
//            dataService.saveSysInfo()
//        }
        curtLocation = nil
        // GPS情報取得確認
        req = LocationManager.shared.locateFromGPS(.continous, accuracy: .block,
//                                                   accuracy: .custom(kCLLocationAccuracyNearestTenMeters),
                                                   distance: CLLocationDistance("-1"),
        activity:.otherNavigation ) { result in
          switch result {
            case .failure(let error):
              debugPrint("Received error: \(error)")
            case .success(let location):
              self.curtLocation = location
              CommUtil.getLocationDesp(loc: self.curtLocation!, onComplete: {desp in
                  self.curtLocationDesp = desp
              })
              debugPrint("Location received: \(location)")
          }
        }
//        req.stop()
        startSensorUpdates(intervalSeconds: 0.01) // 100Hz
    }
    
    func checkSetting(callback: @escaping ()->Void) -> UIAlertController? {
        if dataService.setting.devId == "" {
            let alert = CommUtil.createAlertWithOnlyClose(NSLocalizedString("Warning", comment: ""), message: NSLocalizedString("msg_not_setting", comment: ""), handler: {
                    action in
                
                    callback()
                })
            return alert
        }
        return nil
    }
    
    func confirmParameter(handler: ((UIAlertAction) -> Void)?) -> UIAlertController? {
        let message: String = String(format: "%@\n%@: %@\n%@: %3d\n%@: %3d\n\n%@",
            NSLocalizedString("msg_confirm_parameter", comment: ""),
            NSLocalizedString("device_id", comment: ""),
            DataService.sharedInstance.setting.devId,
            NSLocalizedString("wheel_base", comment: ""),
            DataService.sharedInstance.setting.wheelbase,
            NSLocalizedString("sensor_position", comment: ""),
            DataService.sharedInstance.setting.sensorPosition,
            NSLocalizedString("msg_confirm_parameter2", comment: ""))
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .left
        let messageText = NSAttributedString(
            string: message,
            attributes: [
                NSAttributedString.Key.paragraphStyle: paragraphStyle,
            ]
        )

        let alert = UIAlertController(title: NSLocalizedString("Warning", comment: ""), message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: UIAlertAction.Style.cancel, handler: nil))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Start", comment: ""), style: UIAlertAction.Style.default, handler: handler))
        alert.setValue(messageText, forKey: "attributedMessage")
        
        return alert
    }
    
    func setLocation(data: CLLocation) {
//        didSet {
//            stopButton.setTitle( (request?.state == .running ? "Stop" : "Remove"), for: .normal)
//            titleLabel.text = "GPS LOCATION (MIN ACCEPTED: \(request?.accuracy.description ?? "-"))"

            let loc = data
            // localTimeStamp , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course
            let localTimeStamp = CommUtil.date2string(Date(), format: "yyyy/MM/dd HH:mm:ss.SSS")!
            let gpsTimeStamp = CommUtil.date2string(loc.timestamp, format: "yyyy/MM/dd HH:mm:ss.SSS")!
            let latitude = loc.coordinate.latitude
            let longitude = loc.coordinate.longitude
            let altitude = loc.altitude
            let horizontalAcuracy = loc.horizontalAccuracy
            let verticalAccuracy = loc.verticalAccuracy
            let speed = loc.speed
            let course = loc.course
            
            self.curtLocation = data
            if dataService.isRecording {
                let data = GpsData(lat: String(latitude), lng: String(longitude), timestamp: loc.timestamp)
                self.gpsDatas.append(data)
//                let timestamp = CommUtil.date2string(Date(), format: "h:m:s.SSS")!
                var text = ""
//                text += timestamp + ","
                text += localTimeStamp + ","
                text += gpsTimeStamp + ","
                text += String(latitude) + ","
                text += String(longitude) + ","
                text += String(altitude) + ","
                text += String(horizontalAcuracy) + ","
                text += String(verticalAccuracy) + ","
                text += String(speed) + ","
                text += String(course)
                
                dataService.addRecordGpsText(addText: text)
            }

//        }
    }

    func getGPSData() {
        if req != nil {
            req!.stop()
        }
        gpsDatas = []
        if curtLocation != nil {
            // 開始時locationを出力
            self.setLocation(data: curtLocation!)
        }
        // GPS情報取得確認
        req = LocationManager.shared.locateFromGPS(.continous,
                                                   accuracy: .house,
                                                   distance: CLLocationDistance("-1"),
                                                   activity: .otherNavigation,
                                             timeout: .delayed(10)) {result in
            switch result {
              case .failure(let error):
                print("Location error: \(error)")
              case .success(let location):
                
                if filterLocation(location) {
                    print("New Location: \(location)")
                    self.setLocation(data: location)
                }
            }
        }
        req?.dataFrequency = .fixed(minInterval: 5, minDistance: 5)
    }
    
    // GPS精度向上
    private func filterLocation(_ location: CLLocation) -> Bool{
        let age = -location.timestamp.timeIntervalSinceNow
        // SwiftLocation value: 60(block)
        if age > 10{
            return false
        }
        // error data
        if location.horizontalAccuracy < 0{
            return false
        }
        // SwiftLocation value: 100(block)
//        if location.horizontalAccuracy > 90{
//            return false
//        }
        
        return true
    }
    
    func stopGPSData() {
        if let r = req {
            r.stop()
        }
        
        req = LocationManager.shared.locateFromGPS(.continous, accuracy: .block,
        //                                                   accuracy: .custom(kCLLocationAccuracyNearestTenMeters),
                                                           distance: CLLocationDistance("-1"),
                                                           activity:.otherNavigation )
        { result in
          switch result {
            case .failure(let error):
              debugPrint("Received error: \(error)")
            case .success(let location):
              self.curtLocation = location
              debugPrint("Location received: \(location)")
          }
        }
    }
        
  // intervalSeconds 0.02 :50HZ, 0.01 :100HZ
    func startSensorUpdates(intervalSeconds:Double) {
        if !dataService.isRecording {
            return
        }
        
        if motionManager.isDeviceMotionAvailable{
            motionManager.deviceMotionUpdateInterval = intervalSeconds
            
            // start sensor updates
            motionManager.startDeviceMotionUpdates(to: OperationQueue.current!, withHandler: {(motion:CMDeviceMotion?, error:Error?) in
                self.getMotionData(deviceMotion: motion!)
                
            })
        }
    }
    
    func stopSensorUpdates() {
        if !dataService.isRecording {
            return
        }
        
        if motionManager.isDeviceMotionAvailable{
            motionManager.stopDeviceMotionUpdates()
        }
    }
    
    func getMotionData(deviceMotion:CMDeviceMotion) {
        attitude.x = deviceMotion.attitude.pitch
        attitude.y = deviceMotion.attitude.roll
        attitude.z = deviceMotion.attitude.yaw
        gyro.x = deviceMotion.rotationRate.x
        gyro.y = deviceMotion.rotationRate.y
        gyro.z = deviceMotion.rotationRate.z
        gravity.x = deviceMotion.gravity.x
        gravity.y = deviceMotion.gravity.y
        gravity.z = deviceMotion.gravity.z
        acc.x = deviceMotion.userAcceleration.x
        acc.y = deviceMotion.userAcceleration.y
        acc.z = deviceMotion.userAcceleration.z
        
//        displaySensorData()
        
        // record sensor data
        if dataService.isRecording {
            self.motionCnt += 1
            var newTime: Date?
            if self.motionStartTime == nil {
                self.motionStartTime = Date(timeIntervalSinceNow: (-1 * deviceMotion.timestamp))
            }
            newTime = Date(timeInterval: deviceMotion.timestamp, since: motionStartTime!)
            let timestamp = CommUtil.date2string(newTime, format: "HH:mm:ss.SSS")!
            var text = ""
            text += timestamp + ","
            text += String(format: "%.6f", acc.x + gravity.x) + ","
            text += String(format: "%.6f", acc.y + gravity.y) + ","
            text += String(format: "%.6f", acc.z + gravity.z)
            var text2 = ""
            text2 += timestamp + ","
            text2 += String(format: "%.6f", gyro.x) + ","
            text2 += String(format: "%.6f", gyro.y) + ","
            text2 += String(format: "%.6f", gyro.z)
            
            dataService.addRecordAccText(addText: text)
            dataService.addRecordAngVelText(addText: text2)
        }
    }
    
    func startGetData(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.initWorkDir()
        
        self.motionCnt = 0
        dataService.startRecording()
        getGPSData()
        startSensorUpdates(intervalSeconds: AppConstants.GetDataHZ100)
      
        // ①File1
        self.dataService.saveMeasurementCsv()
        // ②File2
        self.dataService.saveCarCsv()
        // ③File3〜5
        self.getDataTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ProcessService.saveSensorData), userInfo: nil, repeats: true)
        
        completionHandler(true)
    }
    
    func startGetDataWhenVideo(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.initWorkDir()
        dataService.initImgDir()
        
        self.motionCnt = 0
        dataService.startRecording()
        getGPSData()
        startSensorUpdates(intervalSeconds: AppConstants.GetDataHZ100)
      
        // ①File1
        self.dataService.saveMeasurementCsv()
        // ②File2
        self.dataService.saveCarCsv()
        // ③File3〜5
        self.getDataTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ProcessService.saveSensorData), userInfo: nil, repeats: true)
        
        completionHandler(true)
    }
    
    @objc func saveSensorData() {
        print(CommUtil.date2string(Date())! + "save sensor data~~~")
        self.dataService.saveAccCsv()
        self.dataService.saveAngVelCsv()
        self.dataService.saveGpsCsv()
    }
    
    func stopGetData(completionHandler: @escaping ( Bool ) -> Void) {
        stopGPSData()
        dataService.stopRecording()
        self.motionCnt = 0
        self.motionStartTime = nil
        if self.getDataTimer != nil {
            self.getDataTimer!.invalidate()
            self.getDataTimer = nil
        }
        // ファイル 圧縮
        self.dataService.makeZipFile()
        // callback
        completionHandler(true)
    }
    
    func stopGetDataWhenVideo(completionHandler: @escaping ( Bool ) -> Void) {
        stopGPSData()
        dataService.stopRecording()
        self.motionCnt = 0
        self.motionStartTime = nil
        if self.getDataTimer != nil {
            self.getDataTimer!.invalidate()
            self.getDataTimer = nil
        }
        
        // 地図・写真用GPSファイル生成
        self.dataService.outputGPSInfo(data: self.gpsDatas)
        print(CommUtil.date2string(Date())! + " データ採集終了.")
        
        // callback
        completionHandler(true)
    }
}
