//
//  VideoTimerLabel.swift
//  drims
//
//  Created by 黄海 on 2020/04/18.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import UIKit

class VideoTimerLabel: UILabel {

    var timer = Timer()
    
    var isTimerRunning = false
    var isTimerPaused = false
    
    var seconds = 0
    
    func startTimer() {
        
        if timer.isValid{
            
            print("timer is running already!")
            
            return
        }
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
    }
    
    func pauseTimer(){
        
        timer.invalidate()
    }
    
    func resumeTimer(){
        
        startTimer()
    }
    
    func stopTimer(){
        
        pauseTimer()
        
        seconds = 0
        
        updateTime()
    }
    
    @objc private func updateTimer() {
        
        seconds += 1
        
        updateTime()
    }
    
    private func updateTime(){
        DispatchQueue.main.async {
            self.text = self.timeString(time: self.seconds)
        }
    }
    
    private func timeString(time:Int) -> String {
        
        let hours = time / 3600
        let minutes = time / 60 % 60
        let seconds = time % 60
        
        return String(format:"%02i:%02i:%02i", hours, minutes, seconds)
    }

}

