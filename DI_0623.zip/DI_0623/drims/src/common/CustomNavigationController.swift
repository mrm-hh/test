//
//  CustomNavigationController.swift
//  drims
//
//  Created by 卓天成 on 2020/06/16.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import UIKit

class CustomNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationBar.barTintColor = UIColor.init(rgb: 0x769ecb)
        self.navigationBar.titleTextAttributes = [
            .foregroundColor: UIColor.white
        ]
    }
    
}
