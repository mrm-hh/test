import Foundation

public protocol UserDefaultsProtocol {
    func object(forKey key: String) -> Any?
    func set(_ object: Any?, forKey key: String) -> Void
    func removeObject(forKey key: String) -> Void
    func synchronize() -> Bool
}

extension UserDefaults: UserDefaultsProtocol {
}

@objc class LanguageUtility: NSObject{

    public enum Language: String, CaseIterable {
        case ja = "ja"
        case en = "en"
        case zhHans = "zh-Hans"
        case ko = "ko"
        case vi = "vi"
        
        static let separator = "-"
        
        func localizationAndRegion() -> String {
            switch self {
                
            case .ja: return "\(rawValue)\(LanguageUtility.Language.separator)JP"
            case .en: return "\(rawValue)\(LanguageUtility.Language.separator)US"
            case .zhHans: return "\(rawValue)\(LanguageUtility.Language.separator)CN"
            case .ko: return "\(rawValue)\(LanguageUtility.Language.separator)KR"
            case .vi: return "\(rawValue)\(LanguageUtility.Language.separator)VN"
                
            }
        }

        func name() -> String {
            switch self {
            case .ja: return "日本語"
            case .en: return "English"
            case .zhHans: return "简体中文"
            case .ko: return "한국어"
            case .vi: return "Tiếng Việt"
            }
        }

        func phrase() -> String {
            switch self {
            case .ja: return "日本語で利用する"
            case .en: return "Use in English"
            case .zhHans: return "中文使用"
            case .ko: return "한국어로 이용하기"
            case .vi: return "Sử dụng tiếng Việt"
            }
        }

        func wovnCode() -> String {
            // WOVN technologiies URL言語コード
            // https://wovn-support.zendesk.com/hc/ja/articles/360007709372
            // WOVNのコードとrawValueと一致しない場合はこちらで再定義
            switch self {
            case .zhHans: return "zh-CHS"
            default: return rawValue
            }
        }
    }

    var cachedValue: LanguageUtility.Language!

    func cachedLangauge() ->Language{
        if cachedValue == nil {
            cachedValue = language()
        }
        return cachedValue
    }

    /// 本アプリがサポートする言語るリスト
    func supportedLanguages() -> [Language] {
        var seen: [String: Bool] = [:]
        let localizations = Bundle.main.localizations
            .filter({ seen.updateValue(true, forKey: $0) == nil })
            .compactMap({ return Language(rawValue: $0) })
        return localizations
    }

    /// 開発時点で設定したデフォルトの言語
    func developmentLocalization() -> Language {
        return Language(rawValue: Bundle.main.developmentLocalization ?? "ja") ?? .ja
    }

    func isFirstLanguageSupported() -> Bool {
        let preferredLocalizations = preferences.object(forKey: "AppleLanguages") as? [String]
        let lang = preferredLocalizations?.first ?? ""
        for supportedLanguage in Language.allCases {
            if supportedLanguage.rawValue == lang || lang.starts(with: "\(supportedLanguage.rawValue)\(Language.separator)") {
                return true
            }
        }
        return false
    }

    /// (private)優先すべき言語と地域のか配列 i.e.: ["en-JP", "es-419", "it-JP", "ja-JP", "zh-Hans-CN"]
    private func rawPreferredLocalizations() -> [String] {
        // Instead of using Bundle.main.preferredLocations use directly
        // UserDefaults to be able to get latest changes even after change
        let langs = preferences.object(forKey: "AppleLanguages")
        if let langs = langs as? [String], !langs.isEmpty {
            print("rawPreferredLocalizations: \(langs.debugDescription))")
            return langs
        }
        let defLang = developmentLocalization().localizationAndRegion()
        return [defLang]
    }

    /// (private)優先すべき言語と地域をセット i.e.: ["en-JP", "es-419", "it-JP", "ja-JP", "zh-Hans-CN"]
    private func setRawPreferredLocalizations(_ localizations: [String]) {
        if localizations.isEmpty {
            // Avoid overwriting AppleLanguages as much as possible
            preferences.removeObject(forKey: "AppleLanguages")
            return
        }
        print("setRawPreferredLocalizations: \(localizations)")
        let bestLanguageA = language(fromLocalizations: localizations)
        let bestLanguageB = language()
        if bestLanguageA.rawValue == bestLanguageB.rawValue {
            // Writing will have the same effect. So avoid writing.
            return
        }
        // Write only when necessary
        preferences.set(localizations, forKey: "AppleLanguages")
        _ = preferences.synchronize()
    }

    // MARK: -

    /// グローバルオブジェクト
    @objc public static let shared = LanguageUtility(preferences: UserDefaults.standard)

    /// 内部のUserDefaults
    internal let preferences: UserDefaultsProtocol

    /// 初期化
    public init(preferences: UserDefaultsProtocol = UserDefaults.standard) {
        self.preferences = preferences
    }

    /// 言語をゲット
    public func language() -> Language {
        return language(fromLocalizations: rawPreferredLocalizations())
    }

    /// 端末の言語をゲット. 本アプリでサポートしていない言語の場合はnilを返却
    public func isDeviceLanguageJapanese() -> Bool {
        guard let langs = preferences.object(forKey: "AppleLanguages") as? [String], let lang = langs.first, !lang.isEmpty else {
            // This should not happen. There is always AppleLanguages. In this case app will be shown in Japanese so return true
            return true
        }
        return lang == Language.ja.rawValue || lang.starts(with: "\(Language.ja.rawValue)\(LanguageUtility.Language.separator)")
    }
    
    @objc public func isLanguageAppJapanese()  -> Bool {
        return LanguageUtility.shared.cachedLangauge() == .ja
    }

    /// 言語をゲット
    private func language(fromLocalizations localizations: [String]) -> Language {
        for index in 0..<localizations.count {
            for supportedLanguage in supportedLanguages() {
                if localizations[index] == supportedLanguage.rawValue || localizations[index].starts(with: "\(supportedLanguage.rawValue)\(LanguageUtility.Language.separator)") {
                    // Found best language
                    // Remove region information and return
                    var components = localizations[index].components(separatedBy: LanguageUtility.Language.separator)
                    if components.count > 1, let last = components.last, (last.isNumber || last.isAllCapitals) {
                        // Remove continent information which is in numbers (es-419 -> es)
                        // Remove countries information which is ALL in capitals (zh-Hans-CN -> zh-Hans)
                        // Do not remove language sub-information which is not all in capitals: (ex: zh-Hans -> zh-Hans)
                        components.removeLast()
                    }
                    let language = components.joined(separator: LanguageUtility.Language.separator)
                    return Language(rawValue: language) ?? developmentLocalization()
                }
            }
        }
        // language was not found. Ideally this should not happen
        return developmentLocalization()
    }


    /// 言語をセット
    public func setLanguage(_ newLanguage: Language?) {
        guard let newLanguage = newLanguage else {
            // This should not be needed. But in case things brake use this to reset UserDefaults
            setRawPreferredLocalizations([])
            cachedValue = nil
            return
        }
        var appleLanguages = rawPreferredLocalizations()
        // Search in appleLanguages. If found promote that language.
        for index in 0..<appleLanguages.count {
            if appleLanguages[index] == newLanguage.rawValue || appleLanguages[index].starts(with: "\(newLanguage)\(LanguageUtility.Language.separator)") {
                // Found new language.
                // Promote language and return
                let foundLang = appleLanguages.remove(at: index)
                appleLanguages.insert(foundLang, at: 0)
                setRawPreferredLocalizations(appleLanguages)
                cachedValue = newLanguage
                return
            }
        }
        // Language was not found. New record is needed.
        appleLanguages.insert(newLanguage.localizationAndRegion(), at: 0)
        setRawPreferredLocalizations(appleLanguages)
        cachedValue = newLanguage
    }

}


extension LanguageUtility {

    public static let switcherShownkey = "languageSwitcherShown"

    public func shouldShowLanguageSwitcher() -> Bool {
//        guard let realm = DBController.shared.storeRealm else {
            return false
//        }
//        if isDeviceLanguageJapanese() {
//            return false
//        }
//        let obj = realm.object(ofType: LocalConfig.self, forPrimaryKey: LanguageUtility.switcherShownkey)
//        return obj == nil
    }

    public func saveLanguageSwitcherFlag() {
//        guard let realm = DBController.shared.storeRealm else {
//            return
//        }
//        if realm.object(ofType: LocalConfig.self, forPrimaryKey: LanguageUtility.switcherShownkey) != nil {
//            return
//        }
//        let obj = LocalConfig(key: LanguageUtility.switcherShownkey)
//        obj.value = "YES"
//        do {
//            try realm.write {
//                realm.add(obj)
//            }
//        } catch {
//            print("Could not write \(LanguageUtility.switcherShownkey) flag \(error)")
//        }
    }
}
