//
//  SettingsTableviewCell.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import Foundation
import UIKit

protocol SettingTableviewCellDelegate: class {
    func didChanged(label: String, value: String)
}

class SettingTableviewCell: UITableViewCell{
    weak var delegate: SettingTableviewCellDelegate?
    var oldValue:String = ""
    
    var rightTextField:TextField = {
        let storeNumberTextField = TextField()
        storeNumberTextField.placeHolderFont = UIFont.themeFont(with: .level3, strong: .level1, isDynamic: .enabled)
//        storeNumberTextField.clearButtonMode = .whileEditing
//        storeNumberTextField.keyboardType = .numberPad
//        storeNumberTextField.delegate = self
        storeNumberTextField.font = UIFont.themeFont(with: .level3, strong: .level1, language: .english, isDynamic: .enabled)
//        storeNumberTextField.maxLength = 3
//        storeNumberTextField.onlyNumber = true
//        storeNumberTextField.clearsOnBeginEditing = true
        storeNumberTextField.returnKeyType = .next
        storeNumberTextField.sizeToFit()
        return storeNumberTextField
    }()
    
//    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
//        super.init(style: style, reuseIdentifier: reuseIdentifier)
//        self.addSubview(leftLabel)
//        self.addSubview(rightTextField)
//    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String!)
    {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
//        storeNumberTextField = TextField(frame: CGRect(x: 20.0,
//        y: methodSegmentControl.frame.maxY + 14.0,
//        width: 85.0, height: 72.0))
//
        contentView.addSubview(self.rightTextField)
        
        self.rightTextField.layouts([
            "H:|-20-[self]-10-|": .directionLeadingToTrailing,
            "V:|-10-[self(>=60)]-5-|": .directionLeadingToTrailing,
        ])
        self.rightTextField.delegate = self
        
    }
    
    open func setLabelAndValue(label: String, value: String) {
        self.rightTextField.placeHolder = NSLocalizedString(label, comment: "")
        self.rightTextField.text = value
        self.oldValue = value;
        
        self.rightTextField.isSecureTextEntry = false
        
        switch label {
        case "wheel_base":
            self.rightTextField.keyboardType = .numberPad
            self.rightTextField.maxLength = 3
        case "sensor_position":
            self.rightTextField.keyboardType = .numberPad
            self.rightTextField.maxLength = 3
        case "password":
            self.rightTextField.isSecureTextEntry = true
        default:
            self.rightTextField.keyboardType = .default
        }
    }
    
    open func setLabelAndValueOnkyShow(label: String, value: String) {
        self.rightTextField.placeHolder = NSLocalizedString(label, comment: "")
        self.rightTextField.text = value
        self.rightTextField.isEnabled = false
        self.rightTextField.font = UIFont.themeFont(with: .level1, strong: .level1, isDynamic: .enabled)
    }
    
    required init?(coder aDecoder: NSCoder)
    {
       super.init(coder: aDecoder)
    }
}

extension SettingTableviewCell: TextFieldDelegate {
    func didChanged(_ textField: TextField, text: String) {
        delegate?.didChanged(label: textField.placeHolder!,value: text)
    }
}
