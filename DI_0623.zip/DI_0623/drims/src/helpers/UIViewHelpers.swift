import UIKit

extension UIView {
    func addBackgroundGradient(from fromColor: UIColor, to toColor: UIColor, isHorizontal: Bool = true, from: CGFloat = 0.0, to: CGFloat = 1.0) {
        let gradient = CAGradientLayer()
        gradient.frame = bounds
        
        gradient.colors = [fromColor.cgColor, toColor.cgColor]
        if isHorizontal {
            gradient.startPoint = CGPoint(x: from, y: 0.5)
            gradient.endPoint = CGPoint(x: to, y: 0.5)
        } else {
            gradient.startPoint = CGPoint(x: 0.5, y: from)
            gradient.endPoint = CGPoint(x: 0.5, y: to)
        }
        
        layer.insertSublayer(gradient, at: 0)
    }
    
    func updateBackgroundGradient(from fromColor: UIColor, to toColor: UIColor) {
        guard let gradient = layer.sublayers?[0] as? CAGradientLayer else {
            return
        }
        gradient.colors = [fromColor.cgColor, toColor.cgColor]
        
        //layer.insertSublayer(gradient, at: 0)
    }
    
    @discardableResult
    func layouts(_ layoutFormats: [String: NSLayoutConstraint.FormatOptions], with views: [String: UIView]? = nil, metrics: [String: NSNumber]? = nil) -> UIView {
        guard let superview = self.superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        
        var viewsWithSuperview = views ?? [String: UIView]()
        viewsWithSuperview["self"] = self
        viewsWithSuperview.forEach { $1.translatesAutoresizingMaskIntoConstraints = false }
        viewsWithSuperview["superview"] = superview
        
        layoutFormats.forEach {
            superview.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: $0,
                                                                    options: $1,
                                                                    metrics: metrics,
                                                                    views: viewsWithSuperview))
        }
        return self
    }
    /**
     Removes all constrains for this view
     */
    func removeConstraints() {
        let constraints = self.superview?.constraints.filter{
            $0.firstItem as? UIView == self || $0.secondItem as? UIView == self
            } ?? []
        
        self.superview?.removeConstraints(constraints)
        self.removeConstraints(self.constraints)
    }
    
    // toがnilの場合はsuperviewのCenter
    @discardableResult
    func horizenCenter(to: UIView? = nil, constant: CGFloat = 0.0) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .centerX,
                                                   relatedBy: .equal,
                                                   toItem: to == nil ? superview : to,
                                                   attribute: .centerX,
                                                   multiplier: 1.0,
                                                   constant: constant))
        return self
    }
    
    @discardableResult
    func verticalCenter(to: UIView? = nil, constant: CGFloat = 0.0) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .centerY,
                                                   relatedBy: .equal,
                                                   toItem: to == nil ? superview : to,
                                                   attribute: .centerY,
                                                   multiplier: 1.0,
                                                   constant: constant))
        return self
    }
    
    @discardableResult
    func equalFirstBaseline(to: UIView, constant: CGFloat = 0.0) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .firstBaseline,
                                                   relatedBy: .equal,
                                                   toItem: to,
                                                   attribute: .firstBaseline,
                                                   multiplier: 1.0,
                                                   constant: constant))
        return self
    }

    func equalBaseline(to: UIView) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .lastBaseline,
                                                   relatedBy: .equal,
                                                   toItem: to,
                                                   attribute: .lastBaseline,
                                                   multiplier: 1.0,
                                                   constant: 0.0))
        return self
    }
    
    @discardableResult
    func equalTrailing(to: UIView? = nil, constant: CGFloat = 0.0) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .trailing,
                                                   relatedBy: .equal,
                                                   toItem: to == nil ? superview : to,
                                                   attribute: .trailing,
                                                   multiplier: 1.0,
                                                   constant: constant))
        return self
    }
    
    @discardableResult
    func equalTop(to: UIView? = nil, constant: CGFloat = 0.0) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .top,
                                                   relatedBy: .equal,
                                                   toItem: to == nil ? superview : to!,
                                                   attribute: to == nil ? .topMargin : .top,
                                                   multiplier: 1.0,
                                                   constant: constant))
        return self
    }
    
    @discardableResult
    func equalLeading(to: UIView? = nil, constant: CGFloat = 0.0) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .leading,
                                                   relatedBy: .equal,
                                                   toItem: to == nil ? superview : to!,
                                                   attribute: .leading,
                                                   multiplier: 1.0,
                                                   constant: constant))
        return self
    }
    
    @discardableResult
    func equalBottom(to: UIView? = nil, constant: CGFloat = 0.0) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .bottom,
                                                   relatedBy: .equal,
                                                   toItem: to == nil ? superview : to!,
                                                   attribute: to == nil ? .bottomMargin : .bottom,
                                                   multiplier: 1.0,
                                                   constant: constant))
        return self
    }
    
    @discardableResult
    func equalWidth(to: UIView? = nil, constant: CGFloat = 0.0) -> UIView {
        guard let superview = superview else {
            fatalError("viewは必ず何かのsubviewではないといけません。")
        }
        translatesAutoresizingMaskIntoConstraints = false
        superview.addConstraint(NSLayoutConstraint(item: self,
                                                   attribute: .width,
                                                   relatedBy: .equal,
                                                   toItem: to == nil ? superview : to!,
                                                   attribute: .width,
                                                   multiplier: 1.0,
                                                   constant: constant))
        return self
    }
    
    @discardableResult
    func setWidth(_ constant: CGFloat) -> UIView {
        translatesAutoresizingMaskIntoConstraints = false
        addConstraint(NSLayoutConstraint(item: self,
                                         attribute: .width,
                                         relatedBy: .equal,
                                         toItem: nil,
                                         attribute: .notAnAttribute,
                                         multiplier: 1.0,
                                         constant: constant))
        return self
    }
    
    @discardableResult
    func setHeight(_ constant: CGFloat) -> UIView {
        translatesAutoresizingMaskIntoConstraints = false
        addConstraint(NSLayoutConstraint(item: self,
                                         attribute: .height,
                                         relatedBy: .equal,
                                         toItem: nil,
                                         attribute: .notAnAttribute,
                                         multiplier: 1.0,
                                         constant: constant))
        return self
    }
    
    func setBackgroundColor(_ color: UIColor, duration: TimeInterval = 0.33, completion: (() -> Void)? = nil) {
        UIView.transition(with: self, duration: duration, options: [.transitionCrossDissolve], animations: {
            self.backgroundColor = color
        }) { (finish) in
            if finish { completion?() }
        }
    }
    
    func getSnapshot(frame: CGRect? = nil) -> UIView {
        return resizableSnapshotView(from: frame == nil ? bounds : frame!,
                                     afterScreenUpdates: true,
                                     withCapInsets: UIEdgeInsets.zero)!
    }
}

extension UIView {
    func startShimmering() {
        
        let layerName = "shimmerLayer"
        if layer.mask?.name == layerName {
//            debugLog("Skipping shimmer layer")
            return
        }
        let light = UIColor.init(white: 0, alpha: 0.1).cgColor
        //let light = UIColor(red: 0, green: 0, blue: 0, alpha: 0.1).cgColor
        let dark = UIColor.black.cgColor
        let gradient = CAGradientLayer()
        gradient.name = layerName
        gradient.colors = [dark, light, dark]
        gradient.frame = CGRect(x: -bounds.width,
                                y: 0,
                                width: 3 * bounds.width,
                                height: bounds.height)
        gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradient.endPoint = CGPoint(x: 1.0, y: 0.525)
        gradient.locations = [0.4, 0.5, 0.6]
        layer.mask = gradient
        
        let animation: CABasicAnimation = CABasicAnimation(keyPath: "locations")
        animation.fromValue = [0.0, 0.1, 0.2]
        animation.toValue = [0.8, 0.9, 1.0]
        
        animation.duration = 1.5
        animation.repeatCount = HUGE
        animation.isRemovedOnCompletion = false
        gradient.add(animation, forKey: "shimmer")
    }
    
    func stopShimmering() {
        layer.mask = nil
    }
    
    /// 再帰的に全viewを取得する
    var recursiveSubviews: [UIView] {
        return subviews + subviews.flatMap { $0.recursiveSubviews }
    }
}

//extension UIView: ViewStatusProtocol {
//    private static let associationPlaceholderBackgroudColor = ObjectAssociation<NSObject>()
//    var placeholderBackgroudColor: UIColor? {
//        get { return UIView.associationPlaceholderBackgroudColor[self] as? UIColor }
//        set { UIView.associationPlaceholderBackgroudColor[self] = newValue }
//    }
//
//    private static let associationPlaceholderGradientColor = ObjectAssociation<NSObject>()
//    var placeholderGradientColor: CAGradientLayer? {
//        get { return UIView.associationPlaceholderGradientColor[self] as? CAGradientLayer }
//        set { UIView.associationPlaceholderGradientColor[self] = newValue }
//    }
//
//    private static let associationDeinitializationObserver = ObjectAssociation<NSObject>()
//    var deinitializationObserver: DeinitializationObserver? {
//        get { return UIView.associationDeinitializationObserver[self] as? DeinitializationObserver }
//        set { UIView.associationDeinitializationObserver[self] = newValue }
//    }
//
//    static let associationViewStatusString = ObjectAssociation<NSObject>()
//    var viewStatusString: NSString? {
//        get { return UIView.associationViewStatusString[self] as? NSString }
//        set { UIView.associationViewStatusString[self] = newValue }
//    }
//
//    static let associationOriginalViewStatusString = ObjectAssociation<NSObject>()
//    var originalViewStatusString: NSString? {
//        get { return UIView.associationOriginalViewStatusString[self] as? NSString }
//        set { UIView.associationOriginalViewStatusString[self] = newValue }
//    }
//
//    @objc func applyVisualStatus(_ viewStatus: String) {
//        guard let status = ViewStatus(rawValue: viewStatus) else {
//            return
//        }
//
//        self.viewStatusString = viewStatus as NSString
//
//        self.layer.addObserver(self, forKeyPath: "bounds", options: [.new,.old], context: nil)
//        self.deinitializationObserver = DeinitializationObserver() {
//            self.layer.removeObserver(self, forKeyPath: "bounds")
//            self.stopShimmering()
//        }
//
//        switch status {
//        case .placeholder:
//            self.alpha = 1.0
//            if placeholderBackgroudColor != nil {
//                self.backgroundColor = placeholderBackgroudColor
//            } else {
//                guard let placeholderGradientColor = placeholderGradientColor else {
//                    return
//                }
//                placeholderGradientColor.frame = self.bounds
//                self.layer.insertSublayer(placeholderGradientColor, at: 0)
//            }
//            self.originalViewStatusString = ViewStatus.placeholder.rawValue as NSString
//        case .translucent30:
//            self.alpha = 0.3
//            if placeholderBackgroudColor != nil {
//                self.backgroundColor = .clear
//            } else {
//                placeholderGradientColor?.removeFromSuperlayer()
//            }
//            if let originalStatus = ViewStatus(rawValue: self.originalViewStatusString as String? ?? ""),
//                originalStatus == .placeholder && layer.bounds != CGRect.zero {
//                stopShimmering()
//                startShimmering()
//            }
//        case .translucent60:
//            self.alpha = 0.6
//            if placeholderBackgroudColor != nil {
//                self.backgroundColor = .clear
//            } else {
//                placeholderGradientColor?.removeFromSuperlayer()
//            }
//            if let originalStatus = ViewStatus(rawValue: self.originalViewStatusString as String? ?? ""),
//                originalStatus == .placeholder && layer.bounds != CGRect.zero {
//                stopShimmering()
//                startShimmering()
//            }
//        default:
//            self.alpha = 1.0
//            if placeholderBackgroudColor != nil {
//                self.backgroundColor = .clear
//            } else {
//                placeholderGradientColor?.removeFromSuperlayer()
//            }
//            stopShimmering()
//        }
//    }

//    func getCurrentAlpha() -> CGFloat {
//        if let status = ViewStatus(rawValue: self.viewStatusString as String? ?? "") {
//            switch status {
//            case .placeholder:
//                return 1.0
//            case .translucent30, .disableTranslucent30:
//                return 0.3
//            case .translucent60:
//                return 0.6
//            default:
//                return 1.0
//            }
//        } else {
//            return 1.0
//        }
//    }
//
//    override open func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
//        if let layer = object as? CALayer,
//            let keyPath = keyPath {
//            if keyPath == "bounds" {
//                self.placeholderGradientColor?.frame = layer.bounds
//                if let status = ViewStatus(rawValue: self.viewStatusString as String? ?? ""),
//                    let originalStatus = ViewStatus(rawValue: self.originalViewStatusString as String? ?? ""),
//                    originalStatus == .placeholder && (status == .placeholder || status == .translucent30 || status == .translucent60)
//                {
//                    stopShimmering()
//                    startShimmering()
//                }
//            }
//        }
//    }
//}
