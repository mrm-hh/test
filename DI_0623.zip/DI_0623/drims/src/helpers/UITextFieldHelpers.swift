import UIKit

extension UITextField {
    func setLeftMargin(_ width: CGFloat) {
        let leftDummyView = UIView(frame: CGRect(x: 0.0, y: 0.0, width: width, height: 36.0))
        leftDummyView.backgroundColor = UIColor.clear
        leftDummyView.clipsToBounds = true
        leftDummyView.layer.cornerRadius = 5.0
        leftView = leftDummyView
        leftViewMode = .always
    }

    @objc func tappedSearchStyleTextFieldClearButton(_ sender: Any) {
        if delegate?.textFieldShouldClear?(self) ?? true {
            text = ""
        }
    }
    
    open override func awakeFromNib() {
        super.awakeFromNib()
        self.isExclusiveTouch = true
    }

}

class TextFieldWithAccessoryView: UITextField {
    override public init(frame: CGRect) {
        super.init(frame: frame)
        inputAccessoryView = KeyboardAccessoryView.shared
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        inputAccessoryView = KeyboardAccessoryView.shared
    }
}

class KeyboardAccessoryView: UIView {

    private static let height: CGFloat = 44

    static let shared = KeyboardAccessoryView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: KeyboardAccessoryView.height))

    private func commonInit() {
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(done))
        let numberToolbar = UIToolbar(frame: bounds)
        numberToolbar.barStyle = .default
        numberToolbar.items = [flexibleSpace, doneButton]
        numberToolbar.sizeToFit()
        backgroundColor = .clear
        numberToolbar.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(numberToolbar)
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }

    override public init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    @objc func done(_ sender: Any) {
        UIApplication.shared.sendAction(#selector(resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
