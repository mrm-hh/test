import UIKit

extension UIColor {
    convenience init(rgb: Int64) {
        self.init(red: CGFloat((rgb & 0x00FF0000) >> 16) / 255.0,
                  green: CGFloat((rgb & 0x0000FF00) >> 8) / 255.0,
                  blue: CGFloat(rgb & 0x000000FF) / 255.0,
                  alpha: 1.0)
    }

    convenience init(rgba: Int64) {
        self.init(red: CGFloat((rgba & 0xFF000000) >> 24) / 255.0,
                  green: CGFloat((rgba & 0x00FF0000) >> 16) / 255.0,
                  blue: CGFloat((rgba & 0x0000FF00) >> 8) / 255.0,
                  alpha: CGFloat(rgba & 0x000000FF) / 255.0)
    }

    // Sketchのカラーパレートの名前を指定する場合はprefixとして「theme」を設定する
    /**
        #004831
    */
    class var themeTradGreen: UIColor {
        return UIColor(rgb: 0x004831)
    }

    /**
     #004831 20%
     */
    class var themeTradGreenAlpha20: UIColor {
        return UIColor(rgb: 0x004831).withAlphaComponent(0.2)
    }


    /**
        #004831 10%
    */
    class var themeTradGreenAlpha10: UIColor {
        return UIColor(rgb: 0x004831).withAlphaComponent(0.1)
    }

    /**
        #C4D700
    */
    class var themeFreshGreen: UIColor {
        return UIColor(rgb: 0xC4D700)
    }
    
    /**
     #E5003F
     */
    class var themeCircleRed: UIColor {
        return UIColor(rgb: 0xE5003F)
    }
    
    /**
     #7B5AA4
     */
    class var themeCirclePurple: UIColor {
        return UIColor(rgb: 0x7B5AA4)
    }
    
    class var themeYellow: UIColor {
        return UIColor(rgb: 0xE1C300)
    }
    
    class var themeBlueGreen: UIColor {
        return UIColor(rgb: 0x6AC7DF)
    }
    class var themeLightGreen: UIColor {
        return UIColor(rgb: 0xe6f7f2)
    }
    
    class var themeCircleBlue: UIColor {
        return UIColor(rgb: 0x66B4EA)
    }
    
    class var themeCircleGreen: UIColor {
        return UIColor(rgb: 0x00928F)
    }
    
    class var themeDetailButtonGreen: UIColor {
        return UIColor(rgb: 0x2b755f)
    }
    

    /**
        #FFFFFF
    */
    class var themeWhite: UIColor {
        return UIColor(rgb: 0xFFFFFF)
    }

    /**
        #4B4B4B
    */
    class var themeGray: UIColor {
        return UIColor(rgb: 0x4B4B4B)
    }
    
    class var themeLineGray: UIColor {
        return UIColor(rgb: 0xC4C5C4)
    }
    class var themeTitleCellGray: UIColor {
        return UIColor(rgb: 0xf4f4f4)
    }

    /**
        #4B4B4B 60%
    */
    class var themeGrayAlpha60: UIColor {
        return UIColor(rgb: 0x939393)
    }

    /**
        #4B4B4B 10%
    */
    class var themeGrayAlpha10: UIColor {
        return UIColor(rgb: 0xEDEDED)
    }

    /**
        #4B4B4B 5%
    */
    class var themeGrayAlpha5: UIColor {
        return UIColor(rgb: 0xF6F6F6)
    }

    /**
        #121212
    */
    class var themeUiDarkGray: UIColor {
        return UIColor(rgb: 0x121212)
    }

    /**
        #121212 60%
    */
    class var themeUiDarkGrayAlpha60: UIColor {
        return UIColor(rgb: 0x717171)
    }

    /**
        #4B4B4B 30%
    */
    class var themeUiLightGrayAlpha30: UIColor {
        return UIColor(rgb: 0xC8C8C8)
    }

    /**
        #4B4B4B 20%
    */
    class var themeUiLightGrayAlpha20: UIColor {
        return UIColor(rgb: 0xDCDCDC)
    }

    /**
     #4B4B4B 8%
     */
    class var themeUiLightGrayAlpha08: UIColor {
        return UIColor(rgb: 0x4B4B4B).withAlphaComponent(0.08)
    }

    /**
     #4B4B4B 5%
     */
    class var themeUiLightGrayAlpha05: UIColor {
        return UIColor(rgb: 0x4B4B4B).withAlphaComponent(0.05)
    }

    /**
     #6D6D6D 100%
     */
    class var themeUiDebitSettingUnAvailable: UIColor {
        return UIColor(rgb: 0x6D6D6D)
    }
    
    /**
     #EDEDED 100%
     */
    class var themeUiDebitSettingBgUnAvailable: UIColor {
        return UIColor(rgb: 0xEDEDED)
    }
    
    /**
        #EB0A01
    */
    class var themeRed: UIColor {
        return UIColor(rgb: 0xEB0A01)
    }
    
    class var themeLightRed: UIColor {
        return UIColor(rgb: 0xF44336)
    }

    /**
        #0075C6
    */
    class var themeBlue: UIColor {
        return UIColor(rgb: 0x0075C6)
    }
    
    class var detailTitleGray: UIColor {
        return UIColor(rgb: 0x121212).withAlphaComponent(0.6)
    }

    class var themeTransparentDark: UIColor {
        return UIColor(rgb: 0x000000).withAlphaComponent(0.4)
    }
    
    class var whiteAlpha20: UIColor {
        return UIColor(rgb: 0xFFFFF).withAlphaComponent(0.2)
    }
    class var whiteAlpha10: UIColor {
        return UIColor(rgb: 0xFFFFF).withAlphaComponent(0.1)
    }
    
    /**
        #D2D5DB
     */
    class var themeGrayPicker: UIColor {
        return UIColor(rgb: 0xD2D5DB)
    }
    
    /**
        #80BDB1
     */
    class var themeCardImmeGreen: UIColor {
        return UIColor(rgb: 0x80BDB1)
    }
    
    /**
     #00856D
     */
    class var themeCardImmeBgGreen: UIColor {
        return UIColor(rgb: 0x00856D)
    }
    /**
     #00856D
     */
    class var themeCardImmeBgGreenAlpha30: UIColor {
        return UIColor(rgb: 0xB2DAD3)
    }
    
    class var themeCardImmeGreenLine:UIColor{
        return UIColor(rgb: 0xA0C81E)
    }
    
    /**
     #E8F8F8
    */
    class var themeCardImmeBgLightBlue: UIColor {
        return UIColor(rgb: 0xE8F8F8)
    }
    
    /**
     #C7E8FA
     */
    class var themeHomeBgLightBlue: UIColor {
        return UIColor(rgb: 0xC7E8FA)
    }
    
    /**
     #D8D8D8
     */
    class var themelineGray: UIColor {
        return UIColor(rgb: 0xD8D8D8)
    }
    
    /**
     #EDF7F7
     */
    class var themeLightBlue: UIColor {
        return UIColor(rgb: 0xEDF7F7)
    }
    
    
    /**
     #ED8FB1
     */
    class var themeAccountCellPink: UIColor {
        return UIColor(rgb: 0xED8FB1)
    }
    
    /**
     #ED8FB1
     */
    
    class var themeBorderGreen: UIColor {
        return UIColor(rgb: 0xCFE5DF)
    }
    
    func getHue() -> (CGFloat, CGFloat, CGFloat, CGFloat) {
        var hue: CGFloat = 0.0
        var saturation: CGFloat = 0.0
        var brightness: CGFloat = 0.0
        var alpha: CGFloat = 0.0
        getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: &alpha)
        return (hue, saturation, brightness, alpha)
    }

    func getRgba() -> (CGFloat, CGFloat, CGFloat, CGFloat) {
        var red: CGFloat = 0.0
        var green: CGFloat = 0.0
        var blue: CGFloat = 0.0
        var alpha: CGFloat = 0.0
        getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        return (red, green, blue, alpha)
    }

    func getColorWith(newAlpha: CGFloat) -> UIColor {
        let currentColor = self.getRgba()
        let newColor = UIColor(red: currentColor.0, green: currentColor.1, blue: currentColor.2, alpha: newAlpha)
        return newColor
    }
    
}
