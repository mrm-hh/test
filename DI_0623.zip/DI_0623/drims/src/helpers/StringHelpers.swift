import UIKit

extension String {
    var isNumber: Bool {
        return !isEmpty && rangeOfCharacter(from: NSCharacterSet.decimalDigits.inverted) == nil
    }
    
    var isNumberAndAlphabet: Bool {
        return !isEmpty && rangeOfCharacter(from: NSCharacterSet.alphanumerics.inverted) == nil
    }
    
    var isNumberAndHalfAlphabet: Bool {
        return !isEmpty && NSPredicate(format: "SELF MATCHES %@", "^[A-Z0-9a-z]*$").evaluate(with: self)
    }
    
    var isNumberAndHalfAlphabetAndSpecial: Bool {
        return !isEmpty && NSPredicate(format: "SELF MATCHES %@", "^[@#A-Z0-9a-z]*$").evaluate(with: self)
    }

    var isAllCapitals: Bool {
        return !isEmpty && NSPredicate(format: "SELF MATCHES %@", "^[A-Z]*$").evaluate(with: self)
    }

    subscript (i: Int) -> Character {
        return self[index(startIndex, offsetBy: i)]
    }

    subscript (i: Int) -> String {
        return String(self[i] as Character)
    }

    subscript (r: Range<Int>) -> String {
        let start = index(startIndex, offsetBy: r.lowerBound)
        let end = index(startIndex, offsetBy: r.upperBound)
        return String(self[start ..< end])
    }

    func zeroPadding(length: Int) -> String {
        let zeroLength = length - count
        if zeroLength < 1 {
            return self
        }
        return "".padding(toLength: zeroLength, withPad: "0", startingAt: 0) + self
    }

    var localized: String {
        return NSLocalizedString(self, comment: "")
    }

    func localizedWith(_ args: CVarArg...) -> String {
        return String(format: self.localized, arguments: args)
    }

    func localizedPluralWith(_ args: CVarArg...) -> String {
        let format = NSLocalizedString(self, comment: "")
        return String.localizedStringWithFormat(format, args)
    }

    func getAttributedString(with size: FontSize, strong: FontStrong, color: UIColor = UIColor.themeUiDarkGray, isDynamic: DynamicFontSizeType = .fixed, attributes: [NSAttributedString.Key : Any]? = nil) -> NSMutableAttributedString {
        var att: [NSAttributedString.Key : Any] = [
            .font: UIFont.themeFont(with: size, strong: strong, isDynamic: isDynamic),
            .foregroundColor: color,
        ]
        if attributes != nil {
            att = att.merging(attributes!, uniquingKeysWith: { (v1, v2) -> Any in
                return v1
            })
        }
        let res = NSMutableAttributedString(string: self, attributes: att)
        let pattern = "([a-zA-Z0-9,-]+)"
        let regex = try! NSRegularExpression(pattern: pattern, options: .caseInsensitive)
        regex.enumerateMatches(in: self, options: [], range: NSMakeRange(0, self.count)) { (result, flat, stop) in
            guard let result = result else {
                return
            }
            for i in 0..<result.numberOfRanges {
                let range = result.range(at: i)
                res.addAttribute(.font, value: UIFont.themeFont(with: size, strong: strong, language: .english, isDynamic: isDynamic), range: range)
            }
        }
        return res
    }
    
    /// 統一フォントのNSMutableAttributedStringを取得する。
    /// getAttributedStringを使うと、英数字と日本語でfont-familyとfont-sizeが異なるために行間が変わってしまう。この関数を使って行間を揃えることができる。
    func getUnifiedAttributedString(with size: FontSize, strong: FontStrong, color: UIColor = UIColor.themeUiDarkGray, isDynamic: DynamicFontSizeType = .fixed, attributes: [NSAttributedString.Key : Any]? = nil) -> NSMutableAttributedString {
        var att: [NSAttributedString.Key : Any] = [
            .font: UIFont.themeFont(with: size, strong: strong, isDynamic: isDynamic),
            .foregroundColor: color,
            ]
        if attributes != nil {
            att = att.merging(attributes!, uniquingKeysWith: { (v1, v2) -> Any in
                return v1
            })
        }
        return NSMutableAttributedString(string: self, attributes: att)
    }

    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect,
                                            options: .usesLineFragmentOrigin,
                                            attributes: [.font: font],
                                            context: nil)
        return roundTillHalf(boundingBox.height)
    }

    private func roundTillHalf(_ value: CGFloat) -> CGFloat {
        if value - CGFloat(Int(value)) >= 0.5 {
            return CGFloat(Int(value)) + 1
        } else {
            return CGFloat(Int(value)) + 0.5
        }
    }
    
    func removeHeadZero(standardLength length : Int) -> String {
        if length <= 0 {
            return ""
        }
        if self.count <= length || self.prefix(1) != "0" {
            return self
        }
        
        let index = self.index(self.startIndex, offsetBy: 1)
        let res = self.suffix(from: index)
        return String(res)
    }

//    func maskingLoginAccount(type: AccountInfoType) -> String {
//        switch type{
//        case .account:
//            // 口座番号 (0123)012345678 -> (123 - )0123***7
//            // FIX crash when LoginBankViewController-viewwillappear-loginView.loadAccount() or other place called, account length less than 8
//            let zeroPadString = self.zeroPadding(length: 8)
//            let tmp = zeroPadString[0 ..< 4] + "***" + zeroPadString[7]
//            return tmp.removeHeadZero(standardLength: 7)
//        case .contract:
//            // 後５桁 (01234)56789 -> (01234 - )****9
//            return "****" + self[4]
//        default:
//            // VpassID 012345678  -> 012345 ***
//            let tmpCount = self.count - 3 > 0 ? self.count - 3 : 0
//            //20桁以上
//            if tmpCount > 17 {
//                return self[0 ..< 17] + "***..."
//            } else if tmpCount > 0 {
//                return self[0 ..< tmpCount] + "***"
//            } else {
//                return "***"
//            }
//        }
//    }

    func maskPhoneNumber() -> String {
        let tmpCount = self.count
        if tmpCount <= 4 {
            return self
        } else {
            return self[0 ..< tmpCount - 4] + "****"
        }
    }

//    func toMD5() -> String {
//        let cStr = cString(using: .utf8)
//        let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: 16)
//        CC_MD5(cStr, CC_LONG(strlen(cStr!)), buffer)
//        var md5String = ""
//        for idx in 0...15 {
//            let obcStrl = String.init(format: "%02x", buffer[idx])
//            md5String.append(obcStrl)
//        }
//        free(buffer)
//        return md5String
//    }

    func cutTail(to length: Int) -> String {
        return self.count > length ? self[0 ..< length] : self
    }

    func alterDateString(to toFormat: String, from fromFormat: String = "yyyyMMdd") -> String {
        let df = DateFormatter()
        df.locale = Locale(identifier: "ja_JP")
        df.dateFormat = fromFormat
        let date = df.date(from:toFormat)!
        return df.string(from: date)
    }

    /// yyyyMMdd -> yyyy.MM.dd e.g : 20180101 -> 2018.01.01
    func alterDateStringToDot(from fromFormat: String = "yyyyMMdd") -> String {
        return alterDateString(to: "yyyy.MM.dd", from: fromFormat)
    }

    /// yyyyMMdd -> yyyy年M月d日 e.g : 20180101 -> 2018年1月1日
    func alterDateStringToTraditional(from fromFormat: String = "yyyyMMdd") -> String {
        return alterDateString(to: "COMMON_TRADITIONAL_DATE_FORMAT".localized, from: fromFormat)
    }
    
    /// MMdd -> M月d日 e.g : 0101 -> 1月1日
    func alterDateStringToMMdd(from fromFormat: String = "MMdd") -> String {
        return alterDateString(to: "ACCOUNT_DETAIL_DATE_FORMAT".localized, from: fromFormat)
    }
    
    /// 正規表現でチェック
    func check(with regex: String) -> Bool {
        return NSPredicate(format: regex).evaluate(with: self)
    }

    /// 文字列を指定された長さで分割する
    /// - Note: "abcdef".split(by: 2) -> ["ab", "cd", "ef"]
    ///
    /// - Parameter length: 分割する長さ
    /// - Returns: 分割された文字列の配列
    func split(by length: Int) -> [String] {
        var startIndex = self.startIndex
        var results = [Substring]()

        while startIndex < self.endIndex {
            let endIndex = self.index(startIndex, offsetBy: length, limitedBy: self.endIndex) ?? self.endIndex
            results.append(self[startIndex..<endIndex])
            startIndex = endIndex
        }

        return results.map { String($0) }
    }

    private func convertHex(_ s: String.UnicodeScalarView, i: String.UnicodeScalarIndex, appendTo d: [UInt8]) -> [UInt8] {

        let skipChars = CharacterSet.whitespacesAndNewlines

        guard i != s.endIndex else { return d }

        let next1 = s.index(after: i)

        if skipChars.contains(s[i]) {
            return convertHex(s, i: next1, appendTo: d)
        } else {
            guard next1 != s.endIndex else { return d }
            let next2 = s.index(after: next1)

            let sub = String(s[i..<next2])

            guard let v = UInt8(sub, radix: 16) else { return d }

            return convertHex(s, i: next2, appendTo: d + [ v ])
        }
    }

    /// Hex文字列をData型へ変換
    /// - Note: "0102ab" -> 0x0102ab
    var hexData: Data {
        return Data(convertHex(self.unicodeScalars, i: self.unicodeScalars.startIndex, appendTo: []))
    }

    var fromCommaString: String {
        let replacedString = self.replacingOccurrences(of: ",", with: "")
        return replacedString
    }

//    var toCommaString: String {
//        guard let intValue = Int64(self) else {
//            return ""
//        }
//        return intValue.commaString
//    }
//
//    var toCommaStringIfInt64: String {
//        return (Int64(self)?.commaString ?? self)
//    }
//
//    var toCommaStringWithDecimal: String {
//        guard let doubleValue = Double(self) else {
//            return self
//        }
//        return doubleValue.commaString
//    }
    
    /// HTMLタグのparse
    func stripHTMLTag(_ changeBrTag: Bool = true) -> String {
        let tmp: String
        if changeBrTag {
            tmp = self.replacingOccurrences(of: "<br>", with: "\n")
        } else {
            tmp = self
        }
        return tmp.replacingOccurrences(of: "<[^>]+>",
                                        with: "",
                                        options: .regularExpression,
                                        range: nil)
    }
    
    /// HTML特殊文字コード変換
    func htmlSpecialCharacterCodeConversion() -> String {
        return self.replacingOccurrences(of: "&amp;", with: "&")
    }
    
    static func isNilOrEmpty(_ text: String?) -> Bool {
        guard let text = text else {
            return true
        }
        return text.isEmpty
    }

    /// Replaces host in given string. If not possible returns self
    func stringByReplacingHost(_ host: String) -> String {
        if let url = URL(string: self),
            var components = URLComponents(url: url, resolvingAgainstBaseURL: true) {
                components.host = host
            return components.url?.absoluteString ?? self
        }
        return self
    }
}
