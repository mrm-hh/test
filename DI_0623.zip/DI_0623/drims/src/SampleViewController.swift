//
//  SampleViewController.swift
//  drims
//
//  Created by 卓天成 on 2020/06/11.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import UIKit
import CoreLocation
import SVProgressHUD



class SampleViewController: UIViewController {

    let procService = ProcessService.sharedInstance
    let dataService = DataService.sharedInstance
    var startFlg = true
    var isDoing = false
    var isAnimationInit = false

    var timer: Timer? = Timer()
    var locationManager: CLLocationManager!
    
    @IBOutlet weak var statusBar: UITextView!
    
    var buttonStop: UIButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
    var buttonStart:UIButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.title = "GLOCAL-EYEZ ROAD"
        self.navigationController?.tabBarItem.title = NSLocalizedString("Sample", comment: "")
        self.navigationController?.tabBarController?.tabBar.items![1].title = NSLocalizedString("Video", comment: "")
        self.navigationController?.tabBarController?.tabBar.items![2].title = NSLocalizedString("File", comment: "")
        self.navigationController?.tabBarController?.tabBar.items![3].title = NSLocalizedString("Setting", comment: "")
        
        startFlg = true
        isDoing = false
        isAnimationInit = false
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        if dataService.drimsId == "" {
            print("初期起動")
            dataService.drimsId = NSUUID().uuidString
            dataService.installTime = CommUtil.date2string(Date())!
            dataService.appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
            dataService.deviceID = NSUUID().uuidString
            
            dataService.saveSysInfo()
        }
        let image = UIImage(named: "gps")
        let imageView = UIImageView(image: image!)
        let yPos = UIScreen.main.bounds.size.height * 0.11
        imageView.frame = CGRect(x: 10, y: yPos, width: 95, height: 95)
        view.addSubview(imageView)
        
        self.statusBar.translatesAutoresizingMaskIntoConstraints = false
        let views = ["statusBar": self.statusBar, "gps": imageView]
        let horizontalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "H:|-10-[statusBar(115)]", options: NSLayoutConstraint.FormatOptions.alignAllCenterY, metrics: nil, views: views as [String : Any])
        let verticalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "V:[gps]-(<=0)-[statusBar(100)]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views as [String : Any])
        view.addConstraints(horizontalConstraints)
        view.addConstraints(verticalConstraints)
        
        buttonStop.frame = CGRect(x: 100, y: 100, width: 300, height: 300)
        buttonStop.setImage(UIImage(named: "stop"), for: UIControl.State.normal)
        //        buttonStop.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)
        buttonStop.imageView?.contentMode = .scaleAspectFit
        buttonStop.contentHorizontalAlignment = .fill
        buttonStop.contentVerticalAlignment = .fill
        buttonStop.imageEdgeInsets = UIEdgeInsets(top: 140, left: 140, bottom: 140, right: 140)
        view.addSubview(buttonStop)
        buttonStop.horizenCenter()
        buttonStop.verticalCenter()
        buttonStop.isHidden = true
        
        buttonStart.frame = CGRect(x: 100, y: 100, width: 300, height: 300)
        buttonStart.setImage(UIImage(named: "start"), for: UIControl.State.normal)
        //        buttonStart.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)
        buttonStart.imageView?.contentMode = .scaleAspectFit
        buttonStart.contentHorizontalAlignment = .fill
        buttonStart.contentVerticalAlignment = .fill
        buttonStart.imageEdgeInsets = UIEdgeInsets(top: 140, left: 140, bottom: 140, right: 140)
        view.addSubview(buttonStart)
        buttonStart.horizenCenter()
        buttonStart.verticalCenter()
        
        
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)

        view.addSubview(button)
        button.layouts([
            "H:[self(140)]": .alignAllCenterY,
            "V:[self(140)]": .alignAllCenterX
        ])
        button.horizenCenter()
        button.verticalCenter()

        self.statusBar.textAlignment = .center
        self.statusBar.textColor = .red
        self.statusBar.font = self.statusBar.font?.withSize(20)

        print("\(String(describing: CommUtil.date2string(Date()))) DRIMS APP if started.")
        
        self.navigationController?.navigationBar.barTintColor = UIColor.init(rgb: 0x769ecb)//.init(red: 118, green: 158, blue: 203, alpha:100)
        // ナビゲーションバーのアイテムの色　（戻る　＜　とか　読み込みゲージとか）
        self.navigationController?.navigationBar.tintColor = .white
        // ナビゲーションバーのテキストを変更する
        self.navigationController?.navigationBar.titleTextAttributes = [
            // 文字の色
            .foregroundColor: UIColor.white
        ]
        
    }
    
   override func viewWillAppear(_ animated: Bool) {
        startFlg = true
        isDoing = false
        isAnimationInit = false
        
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
        //timer処理
//        var speed = 1.1;
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true, block: { (timer) in
            if let loc = self.procService.curtLocation {
                self.statusBar.textColor = .black
                
                //GPS info
                var speed = loc.speed
                if speed < 0 {
                    speed = 0;
                }
//                speed = speed + 1;
                let info = String(format: "%.1f km/h", speed * 3.6)
                DispatchQueue.main.async() {
                    self.statusBar.text = info
                }
            }
        })
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
        super.viewDidDisappear(animated)
    }
    
    @objc func procBtnOnClick(_ sender: UIButton) {
        if startFlg {
            
            if isDoing {
                return;
            }
            
            // check setting
            let alert = procService.checkSetting() {
                let vc = self.tabBarController!.viewControllers![3];
                self.tabBarController?.selectedViewController = vc
            }
            if alert != nil {
                self.present(alert!, animated: true, completion: nil)
                return
            }
            
            let confirmParameterAlert = procService.confirmParameter { (UIAlertAction) in
                self.isDoing = true
                UIApplication.shared.isIdleTimerDisabled = true
                
                self.procService.startGetData(completionHandler: {
                    ret in
                    print("*Process is started.")
                    
                    self.startFlg = !self.startFlg
                    
                    self.buttonStop.isHidden = false
                    self.buttonStart.isHidden = true
                    
                    if self.isAnimationInit == false {
                        self.isAnimationInit = true
                        UIView.animate(withDuration: 0.6,
                                       delay: 0,
                                       options: [UIView.AnimationOptions.allowUserInteraction, UIView.AnimationOptions.autoreverse, UIView.AnimationOptions.repeat],
                                       animations: {
                                        self.buttonStop.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
                        },
                                       completion: { _ in
                                        UIView.animate(withDuration: 0.6) {
                                            self.buttonStop.transform = CGAffineTransform.identity
                                        }
                        })
                        self.resumeLayer(layer: self.buttonStop.layer)
                    } else {
                        self.resumeLayer(layer: self.buttonStop.layer)
                    }
                })
            }
            
            if confirmParameterAlert != nil { present(confirmParameterAlert!, animated: true, completion: nil) }
        } else {
            UIApplication.shared.isIdleTimerDisabled = false
            self.pauseLayer(layer: self.buttonStop.layer)
            
            SVProgressHUD.show()
            
            DispatchQueue.global(qos: .default).async {
                self.procService.stopGetData {
                    ret in
                    print("*Process is stoped.")
                    
                    self.startFlg = !self.startFlg
                    self.isDoing = false
                    
                    DispatchQueue.main.async {
                        self.buttonStop.isHidden = true
                        self.buttonStart.isHidden = false
                        self.buttonStop.imageView?.stopAnimating()
                        SVProgressHUD.dismiss(withDelay: 1)
                    }
                }
            }
        }
    }
    
    func pauseLayer(layer: CALayer) {
        let pausedTime: CFTimeInterval = layer.convertTime(CACurrentMediaTime(), from: nil)
        layer.speed = 0.0
        layer.timeOffset = pausedTime
    }

    func resumeLayer(layer: CALayer) {
        let pausedTime: CFTimeInterval = layer.timeOffset
        layer.speed = 1.0
        layer.timeOffset = 0.0
        layer.beginTime = 0.0
        let timeSincePause: CFTimeInterval = layer.convertTime(CACurrentMediaTime(), from: nil) - pausedTime
        layer.beginTime = timeSincePause
    }
}


extension SampleViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:
            print("ユーザーはこのアプリケーションに関してまだ選択を行っていません")
            // 許可を求めるコードを記述する（後述）
            break
        case .denied:
            print("ローケーションサービスの設定が「無効」になっています (ユーザーによって、明示的に拒否されています）")
            // 「設定 > プライバシー > 位置情報サービス で、位置情報サービスの利用を許可して下さい」を表示する
            break
        case .restricted:
            print("このアプリケーションは位置情報サービスを使用できません(ユーザによって拒否されたわけではありません)")
            // 「このアプリは、位置情報を取得できないために、正常に動作できません」を表示する
            break
        case .authorizedAlways:
            print("常時、位置情報の取得が許可されています。")
            procService.initProcess()
            // 位置情報取得の開始処理
            break
        case .authorizedWhenInUse:
            print("起動時のみ、位置情報の取得が許可されています。")
            procService.initProcess()
            // 位置情報取得の開始処理
            break
        }
    }
}
