//
//  RouteMapViewController.swift
//  drims
//
//  Created by xiang yin on 2020/04/11.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import UIKit
import Mapbox

class RouteMapViewController: UIViewController, MGLMapViewDelegate {
    var mapView : MGLMapView!
    var gpsFilePath:String = ""
    var gpsPointList:[gpsPoint] = []
    
    class gpsPoint {
        var lat:Double = 0.0
        var lot:Double = 0.0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = NSLocalizedString("GPS", comment: "")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        mapView = MGLMapView(frame: view.bounds)
        mapView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        mapView.delegate = self
         
        let styleURL = "mapbox://styles/yinxiang/ck8qzt9a40pi41inny9lewhfs"
        mapView.styleURL = URL(string: styleURL)
            //latitude: -122.63748, longitude: 45.52214
        // Set the map’s center coordinate and zoom level.
        mapView.setCenter(CLLocationCoordinate2D(latitude: 45.52214, longitude: -122.63748), zoomLevel: 13, animated: false)
        view.addSubview(mapView)
        
        
        
//        drawPolyline()
    }
         
    func mapView(_ mapView: MGLMapView, didFinishLoading style: MGLStyle) {
         
        // Create point to represent where the symbol should be placed
        let point = MGLPointAnnotation()
        point.coordinate = mapView.centerCoordinate
         
        // Create a data source to hold the point data
        let shapeSource = MGLShapeSource(identifier: "marker-source", shape: point, options: nil)
         
        // Create a style layer for the symbol
        let shapeLayer = MGLSymbolStyleLayer(identifier: "marker-style", source: shapeSource)
         
        // Add the image to the style's sprite
        if let image = UIImage(named: "house-icon") {
            style.setImage(image, forName: "home-symbol")
        }
         
        // Tell the layer to use the image in the sprite
        shapeLayer.iconImageName = NSExpression(forConstantValue: "home-symbol")
         
        // Add the source and style layer to the map
        style.addSource(shapeSource)
        style.addLayer(shapeLayer)
            
//        DispatchQueue.global().async {
            self.readFile(self.gpsFilePath)
//        }
//        var coordinates: [CLLocationCoordinate2D] = []
//        //        polyline.coordinate = MGLco
//        coordinates.append(CLLocationCoordinate2D(latitude:45.52214 , longitude: -122.63748))
//        coordinates.append(CLLocationCoordinate2D(latitude:45.52319 , longitude: -122.6545))
//        let polyline = MGLPolyline(coordinates: &coordinates, count: UInt(coordinates.count))
//        mapView.addAnnotation(polyline)
    }
    
    func readFile(_ path: String) {
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fileUrl = URL(fileURLWithPath: path, relativeTo: documentsURL)

        do {
            let data = try String(contentsOf: fileUrl, encoding: .utf8)
            if !data.isEmpty {
                let csvLines = data.components(separatedBy: .newlines)
                if csvLines.count > 3 {
                    for csvLine in csvLines {
                        let oneLineFields = csvLine.components(separatedBy: ",")
                        
                        if oneLineFields.count < 4 {continue}
                        if oneLineFields.count > 0 && oneLineFields[0] == "CarID" {continue}
                        if oneLineFields.count > 0 && oneLineFields[0] == "localTimeStamp " {continue}
                        
                        let point = gpsPoint()
                        point.lat = Double(oneLineFields[2])!
                        point.lot = Double(oneLineFields[3])!
                        gpsPointList.append(point)
                    }
                } else {
                    let alert = CommUtil.createAlertWithOnlyClose(NSLocalizedString("Warning", comment: ""), message: NSLocalizedString("gps_dta_not_enough", comment: ""), handler: {
                        action in
                    
                        self.navigationController?.popViewController(animated: true)
                    })
                    self.present(alert, animated: true, completion: nil)
                    return;
                }
            } else {
                let alert = CommUtil.createAlertWithOnlyClose(NSLocalizedString("Warning", comment: ""), message: NSLocalizedString("gps_dta_not_enough", comment: ""), handler: {
                    action in
                
                    self.navigationController?.popViewController(animated: true)
                })
                self.present(alert, animated: true, completion: nil)
                return;
            }
            
        } catch {
            print(error)
            let alert = CommUtil.createAlertWithOnlyClose(NSLocalizedString("Warning", comment: ""), message: NSLocalizedString("gps_dta_not_enough", comment: ""), handler: {
                action in
            
                self.navigationController?.popViewController(animated: true)
            })
            self.present(alert, animated: true, completion: nil)
            return;
        }
        
        if gpsPointList.count < 2 {
//            self.navigationController?.popViewController(animated: true)
            mapView.setCenter(CLLocationCoordinate2D(latitude: gpsPointList[0].lat, longitude: gpsPointList[0].lot), zoomLevel: 13, animated: false)
            return;
        }
        
        
//        mapView.setCenter(CLLocationCoordinate2D(latitude: gpsPointList[0].lat, longitude: gpsPointList[0].lot), zoomLevel: 13, animated: false)
        var coordinates: [CLLocationCoordinate2D] = []
        
        for onepoint in gpsPointList{
            coordinates.append(CLLocationCoordinate2D(latitude: onepoint.lat, longitude: onepoint.lot))
        }
        //        polyline.coordinate = MGLco
//        coordinates.append(CLLocationCoordinate2D(latitude:45.52214 , longitude: -122.63748))
//        coordinates.append(CLLocationCoordinate2D(latitude:45.52319 , longitude: -122.6545))
        let polyline = MGLPolyline(coordinates: &coordinates, count: UInt(coordinates.count))
        mapView.addAnnotation(polyline)
        mapView.camera = mapView.cameraThatFitsCoordinateBounds(polyline.overlayBounds)
//        mapView.cameraThatFitsShape(<#T##shape: MGLShape##MGLShape#>, direction: <#T##CLLocationDirection#>, edgePadding: <#T##UIEdgeInsets#>)
//        mapView.cameraThatFitsCoordinateBounds(polyline.overlayBounds)
//        mapView.cameraThatFitsCoordinateBounds(MGLCoordinateBoundsMake(
//            CLLocationCoordinate2D(latitude: gpsPointList[0].lat, longitude: gpsPointList[0].lot),
//            CLLocationCoordinate2D(latitude: gpsPointList[gpsPointList.count-1].lat, longitude: gpsPointList[gpsPointList.count-1].lot)))
//        drawPolyline()
    }
//
//    func drwaRoute() {//route :Route
////        guard route.coordinates > 0 else { return }
//        var polyline = MGLPointFeature()
//        if let source = mapView.style?.source(withIdentifier: "route-source") as? MGLShapeSource {
//            source.shape = polyline
//        } else {
//            let source = MGLShapeSource(identifier: "route-source", features: [polyline], options: nil)
//
//            let linestyle = MGLLineStyleLayer(identifier: "route-style", source: source)
//            linestyle.lineColor = NSExpression(forConstantValue: UIColor(red: 59/255, green: 178/255, blue: 208/255, alpha: 1))
//        }
//
//    }
    
    func drawPolyline() {//geoJson: Data
    // Add our GeoJSON data to the map as an MGLGeoJSONSource.
    // We can then reference this data from an MGLStyleLayer.
     
    // MGLMapView.style is optional, so you must guard against it not being set.
        guard let style = self.mapView.style else { return }
        
//        var polyline = MGLPointFeature()
        var coordinates: [CLLocationCoordinate2D] = []
//        polyline.coordinate = MGLco
        coordinates.append(CLLocationCoordinate2D(latitude:45.52214 , longitude: -122.63748))
        coordinates.append(CLLocationCoordinate2D(latitude:45.52319 , longitude: -122.6545))
        let polyline = MGLPolyline(coordinates: &coordinates, count: UInt(coordinates.count))
        
        let source = MGLShapeSource(identifier: "route-source", shape: polyline, options: nil)
        
//        source.shape = polyline
         
//        guard let shapeFromGeoJSON = try? MGLShape(data: geoJson, encoding: String.Encoding.utf8.rawValue) else {
//        fatalError("Could not generate MGLShape")
//        }
         
//        let source = MGLShapeSource(identifier: "polyline", shape: shapeFromGeoJSON, options: nil)
        style.addSource(source)
         
        // Create new layer for the line.
        let layer = MGLLineStyleLayer(identifier: "polyline", source: source)
         
        // Set the line join and cap to a rounded end.
        layer.lineJoin = NSExpression(forConstantValue: "round")
        layer.lineCap = NSExpression(forConstantValue: "round")
         
        // Set the line color to a constant blue color.
        layer.lineColor = NSExpression(forConstantValue: UIColor(red: 59/255, green: 178/255, blue: 208/255, alpha: 1))
         
        // Use `NSExpression` to smoothly adjust the line width from 2pt to 20pt between zoom levels 14 and 18. The `interpolationBase` parameter allows the values to interpolate along an exponential curve.
        layer.lineWidth = NSExpression(format: "mgl_interpolate:withCurveType:parameters:stops:($zoomLevel, 'linear', nil, %@)",
        [14: 2, 18: 20])
         
        // We can also add a second layer that will draw a stroke around the original line.
        let casingLayer = MGLLineStyleLayer(identifier: "polyline-case", source: source)
        // Copy these attributes from the main line layer.
        casingLayer.lineJoin = layer.lineJoin
        casingLayer.lineCap = layer.lineCap
        // Line gap width represents the space before the outline begins, so should match the main line’s line width exactly.
        casingLayer.lineGapWidth = layer.lineWidth
        // Stroke color slightly darker than the line color.
        casingLayer.lineColor = NSExpression(forConstantValue: UIColor(red: 41/255, green: 145/255, blue: 171/255, alpha: 1))
        // Use `NSExpression` to gradually increase the stroke width between zoom levels 14 and 18.
        casingLayer.lineWidth = NSExpression(format: "mgl_interpolate:withCurveType:parameters:stops:($zoomLevel, 'linear', nil, %@)", [14: 1, 18: 4])
         
        // Just for fun, let’s add another copy of the line with a dash pattern.
        let dashedLayer = MGLLineStyleLayer(identifier: "polyline-dash", source: source)
        dashedLayer.lineJoin = layer.lineJoin
        dashedLayer.lineCap = layer.lineCap
        dashedLayer.lineColor = NSExpression(forConstantValue: UIColor.white)
        dashedLayer.lineOpacity = NSExpression(forConstantValue: 0.5)
        dashedLayer.lineWidth = layer.lineWidth
        // Dash pattern in the format [dash, gap, dash, gap, ...]. You’ll want to adjust these values based on the line cap style.
        dashedLayer.lineDashPattern = NSExpression(forConstantValue: [0, 1.5])
         
        style.addLayer(layer)
        style.addLayer(dashedLayer)
        style.insertLayer(casingLayer, below: layer)
    }

}
