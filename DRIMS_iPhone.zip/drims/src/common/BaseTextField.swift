import UIKit

@objc protocol BaseTextFieldDelegate: NSObjectProtocol {
    @objc optional func tappedBackword(_ textField: BaseTextField)
}

class BaseTextField: TextFieldWithAccessoryView {
    weak var baseTextFieldDelegate: BaseTextFieldDelegate?
    /// "ja", "en"など
    var preferredLanguage: String?

    var isDisabledPaste = false

    override func deleteBackward() {
        if text == "" {
            baseTextFieldDelegate?.tappedBackword?(self)
        }
        super.deleteBackward()
    }

    /// 優先されるキーボードの言語を設定
    /// (例 preferredLanguage = "ja"である 且つ 端末に日本語キーボードがオンになっている場合は日本語キーボードが優先され表示される)
    /// https://stackoverflow.com/questions/12595970/iphone-change-keyboard-language-programmatically
    override var textInputMode: UITextInputMode? {
        let language = preferredLanguage ?? ""
        if language.isEmpty {
            return super.textInputMode
        } else {
            for tim in UITextInputMode.activeInputModes {
                if tim.primaryLanguage!.contains(language) {
                    return tim
                }
            }
            return super.textInputMode
        }
    }

    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        let defaultResult = super.canPerformAction(action, withSender: sender)
        if isDisabledPaste && action == #selector(paste(_:)) {
            return false
        }
        return defaultResult
    }
}
