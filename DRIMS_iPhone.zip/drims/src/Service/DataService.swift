//
//  DataService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import Zip

open class DataService: NSObject{
    // SINGLETON
    public static let sharedInstance : DataService = DataService()
    
    let defaults: Defaults  = Defaults()
  
    var setting: Setting
    var carDataNames: [String]
    
    var isRecording = false
    var deviceID: String = ""
    var appVersion: String = ""
    var installTime: String = ""
    var drimsId: String = ""
  
    private let headerAccText = "localTimeStamp , x, y, z"
    private var recordAccText = ""
    private let headerAngVelText = "localTimeStamp , x, y, z"
    private var recordAngVelText = ""
    private let headerGpsText = "localTimeStamp , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course"
    private var recordGpsText = ""
  
    override init() {
        let hasDatas = defaults.has(.carDatasKey)
        if hasDatas {
            carDataNames = defaults.get(for: .carDatasKey)!
            print("Car data list is getted.")
        } else {
            carDataNames = []
        }
        let hasSetting = defaults.has(.settingKey)
        if hasSetting {
            setting = defaults.get(for: .settingKey)!
        } else {
            setting = Setting(devId: "", wheelbase: 0, sensorPosition: 0, userId: "", userPass: "")
        }
        super.init()
        
}
  
    func saveSetting() {
        defaults.set(setting, for: .settingKey)
    }
    
    func saveSysInfo() {
        defaults.set(appVersion, for: .appVersion)
        defaults.set(deviceID, for: .deviceID)
        defaults.set(drimsId, for: .drimsId)
        defaults.set(installTime, for: .installTime)
    }
    
    func loadData() {
//        deviceID = "2BEA0B88-1DE9-4D96-B25E-FBF702C8957B"
        var flg = defaults.has(.deviceID)
        if flg {
            deviceID = defaults.get(for: .deviceID)!
        }
        
//        appVersion = "1.0"
        flg = defaults.has(.appVersion)
        if flg {
            appVersion = defaults.get(for: .appVersion)!
        }
        
//        installTime = "2020/02/06 00:20:30"
        flg = defaults.has(.installTime)
        if flg {
            installTime = defaults.get(for: .installTime)!
        }
//        drimsId = "xLoKOnZjtN9RmqcpQIPukE05SU8xRQxPsFkDTz1m1lsYZyVMTBHgLrf0Ya90NbKW"
        flg = defaults.has(.drimsId)
        if flg {
            drimsId = defaults.get(for: .drimsId)!
        }
    }
    func startRecording() {
        recordAccText = ""
        recordAccText += headerAccText + "\n"
        recordAngVelText = ""
        recordAngVelText += headerAngVelText + "\n"
        recordGpsText = ""
        recordGpsText += headerGpsText + "\n"
        isRecording = true
    }
    
    func stopRecording() {
        isRecording = false
    }
    
    func addRecordAccText(addText:String) {
        recordAccText += addText + "\n"
        print("加速度：" + addText)
    }
  
    func addRecordAngVelText(addText:String) {
        recordAngVelText += addText + "\n"
        print("角速度：" + addText)
    }
    
    func addRecordGpsText(addText:String) {
        recordGpsText += addText + "\n"
        print("GPS：" + addText)
    }
    
    func initWorkDir(createDirFlg: Bool = true) {
        let fmanager = FileManager.default
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir
        do {
            if isDirectory(filePath) {
                try fmanager.removeItem(atPath: filePath)
            }
            if createDirFlg {
                try fmanager.createDirectory(at: URL(fileURLWithPath: filePath), withIntermediateDirectories: true, attributes: nil)
            }
        } catch let e {
            print(e)
        }
    }
    
    func isDirectory(_ dirName: String) -> Bool {
        let fileManager = FileManager.default
        var isDir: ObjCBool = false
        if fileManager.fileExists(atPath: dirName, isDirectory: &isDir) {
            if isDir.boolValue {
                return true
            }
        }
        return false
    }
    
    // 各ファイル保存メソッド
    func saveAccCsv(saveTime: Date)-> String {
        let recordTitle = "SamplingNumber, 998, SamplingFrequency(Hz), 100, CarID, "
                        + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_acc.dat"
      
        recordAccText = recordTitle + recordAccText
        do{
            try recordAccText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write Acceleration CSV")
        }catch let error as NSError{
            print("Failure to Write Acceleration CSV\n\(error)")
        }
        return filePath
    }
  
    func saveAngVelCsv(saveTime: Date)-> String {
        let recordTitle = "SamplingNumber, 998, SamplingFrequency(Hz), 100, CarID, "
                        + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_ang_vel.dat"
      
        recordAngVelText = recordTitle + recordAngVelText
        do{
            try recordAngVelText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write Ang & Vel CSV")
        }catch let error as NSError{
            print("Failure to Write Ang & Vel CSV\n\(error)")
        }
        return filePath
    }
  
    func saveGpsCsv(saveTime: Date)-> String {
        let recordTitle = "CarID, " + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_gps.dat"
      
        recordGpsText = recordTitle + recordGpsText
        do{
            try recordGpsText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write GPS CSV")
        }catch let error as NSError{
            print("Failure to Write GPS CSV\n\(error)")
        }
        return filePath
    }
  
    func saveCarCsv(saveTime: Date)-> String {
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_carinfo.txt"
        var recordCarinfoText = "id, " + setting.devId + "\n"
        recordCarinfoText += "number plate, " + "\n"
        recordCarinfoText += "car model, " + "\n"
        recordCarinfoText += "car no, " + "\n"
        recordCarinfoText += "weight, " + "\n"
        recordCarinfoText += "wheelbase, " + String(setting.wheelbase) + "\n"
        recordCarinfoText += "axle track, " + "\n"
        recordCarinfoText += "angle x, " + "\n"
        recordCarinfoText += "angle y, " + "\n"
        recordCarinfoText += "direction, None" + "\n"
        recordCarinfoText += "directionV, None" + "\n"
        recordCarinfoText += "sensor position, " + String(setting.sensorPosition) + "\n"
        recordCarinfoText += "comment1, " + "\n"
        recordCarinfoText += "comment2, " + "\n"
        recordCarinfoText += "comment3, " + "\n"

        do{
            try recordCarinfoText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write CarInfo CSV")
        }catch let error as NSError{
            print("Failure to Write CarInfo CSV\n\(error)")
        }
        return filePath
    }
  
    func saveMeasurementCsv(saveTime: Date)-> String {
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_measurement.txt"
        var recordMeasurementText = "device id," + deviceID + "\n"
        recordMeasurementText += "app version," + appVersion + "\n"
        recordMeasurementText += "app install time," + installTime + "\n"
        recordMeasurementText += "idrims id," + drimsId + "\n"
        do{
            try recordMeasurementText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write Measurement CSV")
        }catch let error as NSError{
            print("Failure to Write Measurement CSV\n\(error)")
        }
        return filePath
    }
    
    func getZipFileName(saveTime:Date) -> String {
        let fileName = setting.devId + "_data_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
//        let filePathName = NSHomeDirectory() + AppConstants.DocumentDir + fileName + ".zip"
//        return filePathName
        return fileName
    }
    
    func makeZipFile(saveTime:Date) {
        let zipPath = getZipFileName(saveTime: saveTime)
        let workPath = URL(fileURLWithPath: NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir, isDirectory: true)
//            var urlPaths = [URL]()
//            for fnm in files {
//                urlPaths.append(URL(string: fnm)!)
//            }
        do {
//                let _ = try Zip.quickZipFiles(urlPaths, fileName: zipPath)
            let _ = try Zip.quickZipFiles([workPath], fileName: zipPath)
            print("ZIPファイル：" + zipPath)
            
            initWorkDir(createDirFlg: false)
        } catch let e {
            print(e)
        }
    }

}

extension DefaultsKey {
    static let settingKey = Key<Setting>("settingKey")
    static let carDatasKey = Key<[String]>("carDatasKey")
    
    static let deviceID = Key<String>("deviceID")
    static let appVersion = Key<String>("appVersion")
    static let installTime = Key<String>("installTime")
    static let drimsId = Key<String>("drimsId")
    
}
