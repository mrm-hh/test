//
//  Setting.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/29.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation

struct Setting: Codable {
    var devId: String
    var wheelbase: Int      // 単位：CM
    var sensorPosition: Int // 単位：CM
    
    var userId: String
    var userPass: String
}
