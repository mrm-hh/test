//
//  ViewController.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import UIKit

let procService = ProcessService.sharedInstance

var startFlg = true
var isDoing = false

var timer: Timer? = Timer()

class ViewController: UIViewController {
    var buttonStop: UIButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
    var buttonStart:UIButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
    
    let contentViewController = UINavigationController(rootViewController: UIViewController())
    let sidemenuViewController = SidemenuViewController()
    private var isShownSidemenu: Bool {
        return sidemenuViewController.parent == self
    }
    
    @IBOutlet weak var statusBar: UITextView!
    
    @objc func procBtnOnClick(_ sender: UIButton) {
        print(isDoing)
        if isDoing {
            return;
        }
        
        isDoing = true
        if startFlg {
            
            // check setting
            let alert = procService.checkSetting() {
                self.performSegue(withIdentifier: "showSetting", sender: sender)
            }
            if alert != nil {
                self.present(alert!, animated: true, completion: nil)
                return
            }
            
            procService.startGetData(completionHandler: {
                ret in
                print("*Process is started.")
                
                startFlg = !startFlg
                isDoing = false
                
                self.buttonStop.isHidden = false
                self.buttonStart.isHidden = true

                UIView.animate(withDuration: 0.6,
                delay: 0,
                options: [UIView.AnimationOptions.allowUserInteraction, UIView.AnimationOptions.autoreverse, UIView.AnimationOptions.repeat],
                animations: {
                    self.buttonStop.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
                },
                completion: { _ in
                    UIView.animate(withDuration: 0.6) {
                        self.buttonStop.transform = CGAffineTransform.identity
                    }
                })
            })
            
        } else {
            self.buttonStop.imageView?.stopAnimating()
            procService.stopGetData {
                ret in
                print("*Process is stoped.")
                
                startFlg = !startFlg
                isDoing = false
                
                DispatchQueue.main.async {
                    self.buttonStop.imageView?.stopAnimating()
                }
                DispatchQueue.main.async {
                    self.buttonStop.isHidden = true
                    self.buttonStart.isHidden = false
                }
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        procService.initProcess()
        
//        let backview = UIView()
//        backview.backgroundColor = UIColor.init(red: 66, green: 66, blue: 66, alpha:100)
//        view.addSubview(backview)
        
        let image = UIImage(named: "gps")
        let imageView = UIImageView(image: image!)
        let yPos = UIScreen.main.bounds.size.height * 0.11
        imageView.frame = CGRect(x: 10, y: yPos, width: 95, height: 95)
        view.addSubview(imageView)
        
        self.statusBar.translatesAutoresizingMaskIntoConstraints = false
        let views = ["statusBar": self.statusBar, "gps": imageView]
        let horizontalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "H:|-10-[statusBar(95)]", options: NSLayoutConstraint.FormatOptions.alignAllCenterY, metrics: nil, views: views as [String : Any])
        let verticalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "V:[gps]-(<=0)-[statusBar(100)]", options: NSLayoutConstraint.FormatOptions.alignAllCenterX, metrics: nil, views: views as [String : Any])
        view.addConstraints(horizontalConstraints)
        view.addConstraints(verticalConstraints)
        
        buttonStop.frame = CGRect(x: 100, y: 100, width: 300, height: 300)
        buttonStop.setImage(UIImage(named: "stop"), for: UIControl.State.normal)
//        buttonStop.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)
        buttonStop.imageView?.contentMode = .scaleAspectFit
        buttonStop.contentHorizontalAlignment = .fill
        buttonStop.contentVerticalAlignment = .fill
        buttonStop.imageEdgeInsets = UIEdgeInsets(top: 140, left: 140, bottom: 140, right: 140)
        view.addSubview(buttonStop)
        buttonStop.horizenCenter()
        buttonStop.verticalCenter()
        buttonStop.isHidden = true
        
        buttonStart.frame = CGRect(x: 100, y: 100, width: 300, height: 300)
        buttonStart.setImage(UIImage(named: "start"), for: UIControl.State.normal)
//        buttonStart.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)
        buttonStart.imageView?.contentMode = .scaleAspectFit
        buttonStart.contentHorizontalAlignment = .fill
        buttonStart.contentVerticalAlignment = .fill
        buttonStart.imageEdgeInsets = UIEdgeInsets(top: 140, left: 140, bottom: 140, right: 140)
        view.addSubview(buttonStart)
        buttonStart.horizenCenter()
        buttonStart.verticalCenter()
        
        
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
        button.translatesAutoresizingMaskIntoConstraints = false
//        button.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
//        buttonStart.setImage(UIImage(named: "start"), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)
//        button.imageView?.contentMode = .scaleAspectFit
//        button.contentHorizontalAlignment = .fill
//        button.contentVerticalAlignment = .fill
//        button.imageEdgeInsets = UIEdgeInsets(top: 140, left: 140, bottom: 140, right: 140)
//        button.backgroundColor = UIColor.red
        view.addSubview(button)
        button.layouts([
            "H:[self(140)]": .alignAllCenterY,
            "V:[self(140)]": .alignAllCenterX
        ])
        button.horizenCenter()
        button.verticalCenter()
//        button.frame = CGRect(x: 15, y: 54, width: 300, height: 500)
        
        self.statusBar.textAlignment = .center
        self.statusBar.textColor = .red
        self.statusBar.font = self.statusBar.font?.withSize(20)
//        self.statusBar.layouts([
//            "H:|-10-[self]": .alignAllCenterY,
//            "V:[gps]-(<=0)-[self]": .alignAllCenterX
//        ], with: [
//            "gps": imageView
//        ])
        
        navigationItem.title = "GLOCAL-EYEZxROAD"
        let menuButton:UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "menu"), style: .plain, target: self, action: #selector(sidemenuBarButtonTapped(sender:)))
        menuButton.accessibilityIdentifier = "navbarRightItem"
        
        navigationItem.rightBarButtonItems = [menuButton]

        sidemenuViewController.menuItem = ["Setting", "File"];
        sidemenuViewController.delegate = self as SidemenuViewControllerDelegate
//        sidemenuViewController.startPanGestureRecognizing()
        
        //timer処理
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true, block: { (timer) in
            if let loc = procService.curtLocation {
                self.statusBar.textColor = .white
                
                //GPS info
                var speed = loc.speed
                if speed < 0 {
                    speed = 0;
                }
                let info = String(format: "%.1f", speed)
                self.statusBar.text = info
            }
        })
        print("\(String(describing: CommUtil.date2string(Date()))) DRIMS APP if started.")
        
        
    }
    
    @objc private func sidemenuBarButtonTapped(sender: Any) {
        if self.isShownSidemenu {
            hideSidemenu(animated: true)
        } else {
            showSidemenu(animated: true)
        }
    }
    
    private func showSidemenu(contentAvailability: Bool = true, animated: Bool) {
        if self.isShownSidemenu { return }

        addChild(sidemenuViewController)
        sidemenuViewController.view.autoresizingMask = .flexibleHeight
        sidemenuViewController.view.frame = contentViewController.view.bounds
        view.insertSubview(sidemenuViewController.view, aboveSubview: contentViewController.view)
        sidemenuViewController.didMove(toParent: self)
        if contentAvailability {
            sidemenuViewController.showContentView(animated: animated)
        }
    }

    private func hideSidemenu(animated: Bool) {
        if !self.isShownSidemenu { return }

        sidemenuViewController.hideContentView(animated: animated, completion: { (_) in
            self.sidemenuViewController.willMove(toParent: nil)
            self.sidemenuViewController.removeFromParent()
            self.sidemenuViewController.view.removeFromSuperview()
        })
    }

    @objc func tappedHelp(_ sender: Any) {
//        self.performSegue(withIdentifier: "showSetting", sender: false)
    }

}

extension ViewController: SidemenuViewControllerDelegate {
    func parentViewControllerForSidemenuViewController(_ sidemenuViewController: SidemenuViewController) -> UIViewController {
        return self
    }

    func shouldPresentForSidemenuViewController(_ sidemenuViewController: SidemenuViewController) -> Bool {
        /* You can specify sidemenu availability */
        return true
    }

    func sidemenuViewControllerDidRequestShowing(_ sidemenuViewController: SidemenuViewController, contentAvailability: Bool, animated: Bool) {
        showSidemenu(contentAvailability: contentAvailability, animated: animated)
    }

    func sidemenuViewControllerDidRequestHiding(_ sidemenuViewController: SidemenuViewController, animated: Bool) {
        hideSidemenu(animated: animated)
    }

    func sidemenuViewController(_ sidemenuViewController: SidemenuViewController, didSelectItemAt indexPath: IndexPath) {
//        hideSidemenu(animated: true)
        switch indexPath.row {
            case 0:
                hideSidemenu(animated: false)
                self.performSegue(withIdentifier: "showSetting", sender: false)
            case 1:
                hideSidemenu(animated: false)
//                let documentsPath = NSHomeDirectory() + "/Documents"
//                print(documentsPath)
//                self.createTextFile()
                self.performSegue(withIdentifier: "showFiles", sender: false)
            default:
                hideSidemenu(animated: true)
        }
    }
    
    func createTextFile(){
        let text = "myText.text"
        let textName = "data.txt"

        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).last {
            let path = dir.appendingPathComponent(textName)

            do {
                try text.write(to: path, atomically: true, encoding: String.Encoding.utf8)
            } catch let error as NSError {
                print("エラー：\(error)")
            }
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
        super.viewDidDisappear(animated)
    }
}
