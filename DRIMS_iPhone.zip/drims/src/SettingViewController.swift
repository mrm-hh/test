//
//  ViewController.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import UIKit


enum settingItem: String {
    case DeviceID = "DeviceID"
    case WholeSpan = "Whole span"
    case Distance = "Distance"
    case UserID = "UserID"
    case Password = "Password"
}

class SettingViewController: UIViewController {
    let dataService = DataService.sharedInstance

    var sections = [String]()
    var settingsLabel = [[String]]()
    var settingValue = [[String]]()
    
    private var settingsTableView = UITableView(frame: .zero, style: .plain)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sections = ["Device","Account"]

        for _ in 0 ... 2 {
            settingsLabel.append([])
            settingValue.append([])
        }

        settingsLabel[0] = [
            settingItem.DeviceID.rawValue,
            settingItem.WholeSpan.rawValue,
            settingItem.Distance.rawValue
        ]
        settingsLabel[1] = [
            settingItem.UserID.rawValue,
            settingItem.Password.rawValue
        ]
        
        settingValue[0] = ["","",""]
        settingValue[1] = ["",""]
        self.loadLocalSettings()
        
        navigationItem.title = "setting"

        view.addSubview(settingsTableView)
        settingsTableView.layouts([
            "H:|-10-[self]-10-|": .directionLeadingToTrailing,
            "V:|-10-[self]-10-|": .directionLeadingToTrailing,
            ])
        settingsTableView.tableHeaderView = UIView(frame: CGRect(x: 0.0,
                                                         y: 0.0,
                                                         width: UIScreen.main.bounds.width,
                                                         height: .leastNonzeroMagnitude))
        settingsTableView.separatorInset = .zero
        settingsTableView.dataSource = self
        settingsTableView.delegate = self
        settingsTableView.register(SettingTableviewCell.self, forCellReuseIdentifier: "Default")
        settingsTableView.separatorInset = UIEdgeInsets.zero
        settingsTableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        dataService.saveSetting()
    }
    
    func loadLocalSettings(){
        // deviceID
        settingValue[0][0] = dataService.setting.devId
        
        // wholespan
        settingValue[0][1] = String(dataService.setting.wheelbase)
        
        // distance
        settingValue[0][2] = String(dataService.setting.sensorPosition)
        
        
        // userID
        settingValue[1][0] = dataService.setting.userId
        
        // password
        settingValue[1][1] = dataService.setting.userPass
    }


}

extension SettingViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sections[section]
    }
    
    func tableView(_ tableView: UITableView, rowHeight row: Int) -> Int? {
        return 80
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsLabel[section].count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Default", for: indexPath) as! SettingTableviewCell
        
        cell.setLabelAndValue(
            lebel: settingsLabel[indexPath.section][indexPath.row],
            value: settingValue[indexPath.section][indexPath.row])
        
        if indexPath.section == 1 && indexPath.row == 1 {
            cell.rightTextField.isSecureTextEntry = true
        }
        cell.delegate = self
        
        return cell
    }
    
//    func getCarInfoLabelText(row: Int) -> String {
//        let labelText: String
//        switch row{
//            case 0: labelText = "DeviceID"
//            case 1: labelText = "Whole span"
//            case 2: labelText = "Distance"
//        default:
//            labelText = ""
//        }
//        return labelText
//    }
//
//    func getUserInfoLabelText(row: Int) -> String {
//        let labelText: String
//        switch row{
//            case 0: labelText = "UserID"
//            case 1: labelText = "Password"
//        default:
//            labelText = ""
//        }
//        return labelText
//    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        switch indexPath.row {
//            case 0:
//                self.parent?.performSegue(withIdentifier: "showSetting", sender: false)
//            default:
//                return
//        }
    }
}

extension SettingViewController: SettingTableviewCellDelegate {
    func didChanged(label: String, value: String) {
//        let defaults = UserDefaults.standard
//        defaults.set(value, forKey: label)
//        self.loadLocalSettings()
        switch label {
        case "DeviceID":
            dataService.setting.devId = value
        case "Whole span":
            if let val = Int(value) {
                dataService.setting.wheelbase = val
            } else {
                dataService.setting.wheelbase = 0
            }
        case "Distance":
            if let val = Int(value) {
                dataService.setting.sensorPosition = val
            } else {
                dataService.setting.sensorPosition = 0
            }
        case "UserID":
            dataService.setting.userId = value
        case "Password":
            dataService.setting.userPass = value
        default:
            print("incorecct value")
        }
        
    }
}
