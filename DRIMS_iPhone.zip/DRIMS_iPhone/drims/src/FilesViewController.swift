//
//  ViewController.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import UIKit

class FilesViewController: UIViewController {
    let netService = NetService.sharedInstance
    
    class FileInfo {
        var name: String = ""
        var path: String = ""
        var size: UInt64 = 0
        var careateDate: Date? = nil
        
        open func setValue(name: String, path: String, size: UInt64, careateDate: Date){
            self.name = name
            self.path = path
            self.size = size
            self.careateDate = careateDate
        }

        open func getFormatedSize() -> String {
            let tokens = ["bytes","KB","MB","GB","TB","PB","EB","ZB","YB"]

            var convertedValue = Float(self.size)
            var multiplyFactor = 0
            while (convertedValue > 1024) {
                convertedValue /= 1024
                multiplyFactor += 1
            }

            return String(format: "%4.2f %@", convertedValue, tokens[multiplyFactor])
        }
        
        open func getFormatedCreateDate() -> String {
            if careateDate == nil {
                return ""
            }
            let df = DateFormatter()
            df.locale = Locale(identifier: "ja_JP")
            df.dateFormat = "yyyy/MM/dd HH:mm:ss"
            return df.string(from: careateDate!)
        }
    }
    
    var fileURLs:[URL]? = nil
    var fileInfos:[FileInfo] = []
    private var filesTableView = UITableView(frame: .zero, style: .plain)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadData()

        navigationItem.title = "Files"
        
        view.addSubview(filesTableView)
        
        filesTableView.tableHeaderView = UIView(frame: CGRect(x: 0.0,
                                                         y: 0.0,
                                                         width: UIScreen.main.bounds.width,
                                                         height: .leastNonzeroMagnitude))
        filesTableView.separatorInset = .zero
        filesTableView.dataSource = self
        filesTableView.delegate = self
        filesTableView.register(FileTableviewCell.self, forCellReuseIdentifier: "Default")
        filesTableView.separatorInset = UIEdgeInsets.zero
        filesTableView.isEditing = true
        filesTableView.allowsMultipleSelection = true
        filesTableView.allowsMultipleSelectionDuringEditing = true
        filesTableView.reloadData()
        
        
        let deleteButton = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
        deleteButton.backgroundColor = UIColor.gray
        deleteButton.setTitle("Delete", for: .normal)
        deleteButton.addTarget(self, action: #selector(deleteAction), for: .touchUpInside)

        self.view.addSubview(deleteButton)
        
        let uploadButton = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
        uploadButton.backgroundColor = UIColor.gray
        uploadButton.setTitle("Upload", for: .normal)
        uploadButton.addTarget(self, action: #selector(uploadAction), for: .touchUpInside)

        self.view.addSubview(uploadButton)
     
//        filesTableView.layouts([
//            "H:|[self]|": .directionLeadingToTrailing,
//            "V:|[self]|": .directionLeadingToTrailing,
//        ])
        filesTableView.layouts([
            "H:|-10-[self]-10-|": .directionLeadingToTrailing,
            "V:|-10-[self]-10-[delete(50)]-15-|": .directionLeadingToTrailing,
        ], with: [
            "delete": deleteButton
        ])
        
        deleteButton.layouts([
            "H:|-10-[self]-[upload(==self)]-10-|": .directionLeadingToTrailing
        ], with: [
            "upload": uploadButton
        ])
        
        uploadButton.layouts([
            "V:|-10-[table]-10-[self]-15-|": .directionLeadingToTrailing
        ], with: [
            "table": filesTableView
        ])
    }
    
    fileprivate func loadData() {
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            self.fileInfos = []
            self.fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
            for i in 0..<self.fileURLs!.count {
                let filePath = self.fileURLs![i].path
                let attr = try FileManager.default.attributesOfItem(atPath: filePath)
                
                let fileName = self.fileURLs![i].lastPathComponent
                print(fileName)
                let fileSize = attr[FileAttributeKey.size] as! UInt64
                print(fileSize)
                let createDate = attr[FileAttributeKey.creationDate] as! Date
                
                let fileInfo = FileInfo()
                fileInfo.setValue(name: fileName, path: filePath, size: fileSize, careateDate: createDate)
                
                print(fileInfo.getFormatedSize())
                print(fileInfo.getFormatedCreateDate())
                fileInfos.append(fileInfo)
            }
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
        }
    }
    
    @objc func deleteAction() {
        let delObjs = filesTableView.indexPathsForSelectedRows
        if delObjs != nil {
//            filesTableView.deleteRows(at: delObjs!, with: UITableView.RowAnimation.automatic)
            for delObj in delObjs! {
                let idx = delObj.row
                do {
                    try FileManager.default.removeItem(at: fileURLs![idx])
                } catch let e{
                    print(e)
                }
            }
            loadData()
            filesTableView.reloadData()
        }
    }
    
    @objc func uploadAction() {
        if fileURLs == nil {
            return
        }
        let delObjs = filesTableView.indexPathsForSelectedRows
        var sendURLs:[URL] = []
        var fnames:[String] = []
        for delObj in delObjs! {
            let idx = delObj.row
            sendURLs.append(fileURLs![idx])
            fnames.append(fileInfos[idx].name)
        }
        if sendURLs.count > 0 {
            netService.uploadDrimsFile(fileUrls: sendURLs, fileNames: fnames)
        }
    }
}



extension FilesViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection rows: Int) -> Int {
        return fileInfos.count
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
//        guard indexPath.section == SectionVegetables else { return false }
        return true
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Default", for: indexPath) as! FileTableviewCell
        
        cell.setLabelAndValue(
            name: (fileInfos[indexPath.row].name),
            size: (fileInfos[indexPath.row].getFormatedSize()),
            careateDate: (fileInfos[indexPath.row].getFormatedCreateDate()))
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        switch indexPath.row {
//            case 0:
//                self.parent?.performSegue(withIdentifier: "showSetting", sender: false)
//            default:
//                return
//        }
    }
}
