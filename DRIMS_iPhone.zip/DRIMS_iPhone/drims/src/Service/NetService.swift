//
//  NetService.swift
//  drims
//
//  Created by 黄海 on 2020/02/08.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import Foundation

open class NetService {
    // SINGLETON
    public static let sharedInstance : NetService = NetService()
    
    let dataService = DataService.sharedInstance

    func uploadDrimsFile(fileUrls: [URL], fileNames: [String], completion: @escaping ((Bool) -> Void)) {
        let user = dataService.setting.userId
        let password = dataService.setting.userPass
        let encodedStr = (user + ":" + password).data(using: .utf8)
        
        if let authStr = encodedStr?.base64EncodedString() {
            let userAuth = "Basic " + authStr
            let boundary = "---WebKitFormBoundary\(arc4random())"
            let multiPart = "multipart/form-data; boundary=\(boundary)"
            var parameters:[String: AnyObject] = [:]
            var req = URLRequest(url: URL(string: AppConstants.WebAPIUploadFiles)!)
            let paramsData = createMultiData(files: fileUrls, names: fileNames, boundary: boundary)
            
            req.addValue(userAuth, forHTTPHeaderField: "authorization")
            req.addValue(multiPart, forHTTPHeaderField: "Content-Type")
            req.setValue("\(paramsData.length)", forHTTPHeaderField: "Content-Length")
            req.httpMethod = "POST"
            let sendData = paramsData as Data
            URLSession.shared.uploadTask(with: req, from: sendData) { (data, res, err) in
                if err != nil {
                    completion(false)
                    print(err)
                } else {
                    completion(true)
                    print(data, res)
                }
            }.resume()
            
        }
    }
    
    private func createMultiData(files:[URL], names:[String], boundary: String) -> NSData {
        let sendData = NSMutableData()
        
        var i = 0
        sendData.append(("--" + boundary + "\r\n").data(using: .utf8)!)
        for fileurl:URL in files {
            do {
                let fileData = try Data(contentsOf: fileurl)
                let seperatorStr = "Content-Disposition: form-data; name=\"file\(String(i))\""
                                 + ";filename=\"\(names[i])\"\r\n"
                let seperatorStr2 = "Content-Type: application/zip\r\n"
                sendData.append(seperatorStr.data(using: .utf8)!)
                sendData.append(seperatorStr2.data(using: .utf8)!)
                sendData.append("\r\n".data(using: .utf8)!)
                sendData.append(fileData)
                sendData.append("\r\n".data(using: .utf8)!)
                i += 1
            } catch {
                print(fileurl.absoluteString + "is read error!")
                i += 1
                continue
            }
        }
        sendData.append(("--" + boundary + "--\r\n").data(using: .utf8)!)
        
        return sendData
    }
    
}
