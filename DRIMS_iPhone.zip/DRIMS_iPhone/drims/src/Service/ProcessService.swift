//
//  ProcessService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import CoreLocation
import CoreMotion
import UIKit

open class ProcessService: NSObject {
    // SINGLETON
    public static let sharedInstance : ProcessService = ProcessService()
    
    let dataService = DataService.sharedInstance
    
    let motionManager = CMMotionManager()
    var attitude = SIMD3<Double>.zero
    var gyro = SIMD3<Double>.zero
    var gravity = SIMD3<Double>.zero
    var acc = SIMD3<Double>.zero
    // 現在位置情報
    var curtLocation: CLLocation?
    var req: LocationRequest? = nil
    // DeviceMotionの起動時間
    var motionStartTime: Date? = nil
    // 記録済み数
    var motionCnt = 0
    
    // データ採集タイマー
    var getDataTimer: Timer?
    
    // 初期処理
    func initProcess() {
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir
        if self.dataService.isDirectory(filePath) {
            self.dataService.makeZipFile(saveTime: Date())
        }
        
        dataService.loadData()
        if dataService.drimsId == "" {
            print("初期起動")
            dataService.drimsId = NSUUID().uuidString
            dataService.installTime = CommUtil.date2string(Date())!
            dataService.appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
            dataService.deviceID = NSUUID().uuidString
            
            dataService.saveSysInfo()
        }
        curtLocation = nil
        // GPS情報取得確認
        req = LocationManager.shared.locateFromGPS(.continous, accuracy: .block) { result in
          switch result {
            case .failure(let error):
              debugPrint("Received error: \(error)")
            case .success(let location):
              self.curtLocation = location
              debugPrint("Location received: \(location)")
          }
        }
//        req.stop()
        startSensorUpdates(intervalSeconds: 0.01) // 100Hz
    }
    
    func checkSetting(callback: @escaping ()->Void) -> UIAlertController? {
        if dataService.setting.devId == "" {
            let alert = CommUtil.createAlertWithOnlyClose("Warning", message: "Please set the base info.", handler: {
                    action in
                
                    callback()
                })
            return alert
        }
        return nil
    }
    
    func setLocation(data: CLLocation) {
//        didSet {
//            stopButton.setTitle( (request?.state == .running ? "Stop" : "Remove"), for: .normal)
//            titleLabel.text = "GPS LOCATION (MIN ACCEPTED: \(request?.accuracy.description ?? "-"))"

            let loc = data
            // localTimeStamp , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course
            let localTimeStamp = CommUtil.date2string(Date(), format: "yyyy/MM/dd HH:mm:ss.SSS")!
            let gpsTimeStamp = CommUtil.date2string(loc.timestamp, format: "yyyy/MM/dd HH:mm:ss.SSS")!
            let latitude = loc.coordinate.latitude
            let longitude = loc.coordinate.longitude
            let altitude = loc.altitude
            let horizontalAcuracy = loc.horizontalAccuracy
            let verticalAccuracy = loc.verticalAccuracy
            let speed = loc.speed
            let course = loc.course
            
            self.curtLocation = data
            if dataService.isRecording {
//                let timestamp = CommUtil.date2string(Date(), format: "h:m:s.SSS")!
                var text = ""
//                text += timestamp + ","
                text += localTimeStamp + ","
                text += gpsTimeStamp + ","
                text += String(latitude) + ","
                text += String(longitude) + ","
                text += String(altitude) + ","
                text += String(horizontalAcuracy) + ","
                text += String(verticalAccuracy) + ","
                text += String(speed) + ","
                text += String(course)
                
                dataService.addRecordGpsText(addText: text)
            }

//        }
    }

    func getGPSData() {
        if req != nil {
            req!.stop()
        }
        // GPS情報取得確認
        req = LocationManager.shared.locateFromGPS(.continous,
                                             accuracy: .block,
                                             distance: CLLocationDistance("-1"),
                                             activity: .other,
                                             timeout: .delayed(10)) {result in
            switch result {
              case .failure(let error):
                print("Location error: \(error)")
              case .success(let location):
                
                print("New Location: \(location)")
                self.setLocation(data: location)
            }
        }
        req?.dataFrequency = .fixed(minInterval: 5, minDistance: 5)
    }
    
    func stopGPSData() {
        if let r = req {
            r.stop()
        }
    }
        
  // intervalSeconds 0.02 :50HZ, 0.01 :100HZ
    func startSensorUpdates(intervalSeconds:Double) {
        if !dataService.isRecording {
            return
        }
        
        if motionManager.isDeviceMotionAvailable{
            motionManager.deviceMotionUpdateInterval = intervalSeconds
            
            // start sensor updates
            motionManager.startDeviceMotionUpdates(to: OperationQueue.current!, withHandler: {(motion:CMDeviceMotion?, error:Error?) in
                self.getMotionData(deviceMotion: motion!)
                
            })
        }
    }
    
    func stopSensorUpdates() {
        if !dataService.isRecording {
            return
        }
        
        if motionManager.isDeviceMotionAvailable{
            motionManager.stopDeviceMotionUpdates()
        }
    }
    
    func getMotionData(deviceMotion:CMDeviceMotion) {
        attitude.x = deviceMotion.attitude.pitch
        attitude.y = deviceMotion.attitude.roll
        attitude.z = deviceMotion.attitude.yaw
        gyro.x = deviceMotion.rotationRate.x
        gyro.y = deviceMotion.rotationRate.y
        gyro.z = deviceMotion.rotationRate.z
        gravity.x = deviceMotion.gravity.x
        gravity.y = deviceMotion.gravity.y
        gravity.z = deviceMotion.gravity.z
        acc.x = deviceMotion.userAcceleration.x
        acc.y = deviceMotion.userAcceleration.y
        acc.z = deviceMotion.userAcceleration.z
        
//        displaySensorData()
        
        // record sensor data
        if dataService.isRecording {
            self.motionCnt += 1
            var newTime: Date?
            if self.motionStartTime == nil {
                self.motionStartTime = Date(timeIntervalSinceNow: (-1 * deviceMotion.timestamp))
            }
            newTime = Date(timeInterval: deviceMotion.timestamp, since: motionStartTime!)
            let timestamp = CommUtil.date2string(newTime, format: "h:m:s.SSS")!
            var text = ""
            text += timestamp + ","
            text += String(format: "%.6f", acc.x + gravity.x) + ","
            text += String(format: "%.6f", acc.y + gravity.y) + ","
            text += String(format: "%.6f", acc.z + gravity.z)
            var text2 = ""
            text2 += timestamp + ","
            text2 += String(format: "%.6f", gyro.x) + ","
            text2 += String(format: "%.6f", gyro.y) + ","
            text2 += String(format: "%.6f", gyro.z)
            
            dataService.addRecordAccText(addText: text)
            dataService.addRecordAngVelText(addText: text2)
        }
    }
    
    func startGetData(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.initWorkDir()
        
        self.motionCnt = 0
        dataService.startRecording()
        getGPSData()
        startSensorUpdates(intervalSeconds: AppConstants.GetDataHZ100)
      
        // ①File1
        self.dataService.saveMeasurementCsv()
        // ②File2
        self.dataService.saveCarCsv()
        // ③File3〜5
        self.getDataTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ProcessService.saveSensorData), userInfo: nil, repeats: true)
        
        completionHandler(true)
    }
    
    @objc func saveSensorData() {
        self.dataService.saveAccCsv()
        self.dataService.saveAngVelCsv()
        self.dataService.saveGpsCsv()
    }
    
    func stopGetData(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.initWorkDir()
        stopGPSData()
        dataService.stopRecording()
        self.motionCnt = 0
      
        // ファイル 圧縮
        self!.dataService.makeZipFile(saveTime: curDateTime)
      
        // callback
        completionHandler(true)
    }
}
