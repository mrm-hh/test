//
//  SettingsTableviewCell.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import Foundation
import UIKit
private let sw:CGFloat = UIScreen.main.bounds.width
class FileTableviewCell: UITableViewCell{
    var fileNameLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.themeFont(with: .level2, strong: .level1, language: .japanese)
        label.sizeToFit()
        label.numberOfLines = 1
        label.textColor = UIColor.themeUiDarkGray
        return label
    }()
    
    var fileSizeLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.themeFont(with: .level2, strong: .level1, language: .japanese)
        label.sizeToFit()
        label.numberOfLines = 1
        label.textColor = UIColor.themeUiDarkGray
        return label
    }()
    
    var fileCreateDateLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.themeFont(with: .level2, strong: .level1, language: .japanese)
        label.sizeToFit()
        label.numberOfLines = 1
        label.textColor = UIColor.themeUiDarkGray
        label.textAlignment = .right
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String!)
    {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        contentView.addSubview(self.fileNameLabel)
        contentView.addSubview(self.fileSizeLabel)
        contentView.addSubview(self.fileCreateDateLabel)
        
        self.fileNameLabel.layouts([
            "H:|-10-[self]-10-|": .directionLeadingToTrailing,
            "V:|-10-[self]-[size]-10-|": .directionLeadingToTrailing
        ], with: [
            "size": self.fileSizeLabel
        ])
        
        self.fileSizeLabel.layouts([
            "H:|-10-[self]-[date]-10-|": .directionLeadingToTrailing
        ], with: [
            "date": self.fileCreateDateLabel
        ])

        self.fileCreateDateLabel.layouts([
            "V:|-10-[name]-[self]-10-|": .directionLeadingToTrailing,
        ], with: [
            "name": self.fileNameLabel
        ])

    }
    
    open func setLabelAndValue(name: String, size: String, careateDate: String) {
        self.fileNameLabel.text = name
        self.fileSizeLabel.text = size
        self.fileCreateDateLabel.text = careateDate
    }
    
    required init?(coder aDecoder: NSCoder)
    {
       super.init(coder: aDecoder)
    }
}
