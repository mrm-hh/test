//
//  ContentView.swift
//  drims
//
//  Created by xiang yin on 2020/02/01.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import SwiftUI

@available(iOS 13.0.0, *)
struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

@available(iOS 13.0.0, *)
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
