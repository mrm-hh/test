//
//  ViewController.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import UIKit

let procService = ProcessService.sharedInstance

var startFlg = false

class ViewController: UIViewController {
    let contentViewController = UINavigationController(rootViewController: UIViewController())
    let sidemenuViewController = SidemenuViewController()
    private var isShownSidemenu: Bool {
        return sidemenuViewController.parent == self
    }
    
    @IBAction func procBtnOnClick(_ sender: UIButton) {
        startFlg = !startFlg
        if startFlg {
            sender.setTitle("Stop", for: .normal)
            procService.startGetData(completionHandler: {
                ret in
                print("*Process is started.")
            })
        } else {
            sender.setTitle("Start", for: .normal)
            procService.stopGetData {
                ret in
                print("*Process is stoped.")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "DRIMS"
        let menuButton:UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "menu"), style: .plain, target: self, action: #selector(sidemenuBarButtonTapped(sender:)))
        menuButton.accessibilityIdentifier = "navbarRightItem"
        
        navigationItem.rightBarButtonItems = [menuButton]

        sidemenuViewController.menuItem = ["Setting", "File"];
        sidemenuViewController.delegate = self as SidemenuViewControllerDelegate
        sidemenuViewController.startPanGestureRecognizing()
    }
    
    @objc private func sidemenuBarButtonTapped(sender: Any) {
        if self.isShownSidemenu {
            hideSidemenu(animated: true)
        } else {
            showSidemenu(animated: true)
        }
    }
    
    private func showSidemenu(contentAvailability: Bool = true, animated: Bool) {
        if self.isShownSidemenu { return }

        addChild(sidemenuViewController)
        sidemenuViewController.view.autoresizingMask = .flexibleHeight
        sidemenuViewController.view.frame = contentViewController.view.bounds
        view.insertSubview(sidemenuViewController.view, aboveSubview: contentViewController.view)
        sidemenuViewController.didMove(toParent: self)
        if contentAvailability {
            sidemenuViewController.showContentView(animated: animated)
        }
    }

    private func hideSidemenu(animated: Bool) {
        if !self.isShownSidemenu { return }

        sidemenuViewController.hideContentView(animated: animated, completion: { (_) in
            self.sidemenuViewController.willMove(toParent: nil)
            self.sidemenuViewController.removeFromParent()
            self.sidemenuViewController.view.removeFromSuperview()
        })
    }

     @objc func tappedHelp(_ sender: Any) {
//        self.performSegue(withIdentifier: "showSetting", sender: false)
    }

}

extension ViewController: SidemenuViewControllerDelegate {
    func parentViewControllerForSidemenuViewController(_ sidemenuViewController: SidemenuViewController) -> UIViewController {
        return self
    }

    func shouldPresentForSidemenuViewController(_ sidemenuViewController: SidemenuViewController) -> Bool {
        /* You can specify sidemenu availability */
        return true
    }

    func sidemenuViewControllerDidRequestShowing(_ sidemenuViewController: SidemenuViewController, contentAvailability: Bool, animated: Bool) {
        showSidemenu(contentAvailability: contentAvailability, animated: animated)
    }

    func sidemenuViewControllerDidRequestHiding(_ sidemenuViewController: SidemenuViewController, animated: Bool) {
        hideSidemenu(animated: animated)
    }

    func sidemenuViewController(_ sidemenuViewController: SidemenuViewController, didSelectItemAt indexPath: IndexPath) {
//        hideSidemenu(animated: true)
        switch indexPath.row {
            case 0:
                hideSidemenu(animated: false)
                self.performSegue(withIdentifier: "showSetting", sender: false)
            case 1:
                hideSidemenu(animated: false)
//                let documentsPath = NSHomeDirectory() + "/Documents"
//                print(documentsPath)
//                self.createTextFile()
                self.performSegue(withIdentifier: "showFiles", sender: false)
            default:
                hideSidemenu(animated: true)
        }
    }
    
    func createTextFile(){
        let text = "myText.text"
        let textName = "data.txt"

        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).last {
            let path = dir.appendingPathComponent(textName)

            do {
                try text.write(to: path, atomically: true, encoding: String.Encoding.utf8)
            } catch let error as NSError {
                print("エラー：\(error)")
            }
        }
    }
}
