import UIKit

class DynamicFontController: NSObject {
    var contentSizeStr = ""
    
    static let fontDidChangeNotification = Notification.Name("FontDidChangeNotification")
    static let fontDidChangeNotificationCustomKey = Notification.Name("FontDidChangeNotificationCustomKey")
    
    class var shared: DynamicFontController {
        struct Singleton {
            static let instance = DynamicFontController()
        }
        return Singleton.instance
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func registerDynamicFontNotification() {
        self.contentSizeStr = UIApplication.shared.preferredContentSizeCategory.rawValue
        NotificationCenter.default.addObserver(self, selector: #selector(receivedFontSizeChanged(_:)), name: UIContentSizeCategory.didChangeNotification, object: nil)
    }
    
    @objc func receivedFontSizeChanged(_ notification: Notification) {
        guard
            let userInfo = notification.userInfo,
            let tmpContentSizeStr = userInfo[UIContentSizeCategory.newValueUserInfoKey] as? String
            else {
                return
        }
        
        if tmpContentSizeStr != self.contentSizeStr {
            self.contentSizeStr = tmpContentSizeStr
            self.postDynamicFontNotificationWithContentSizeStr(contentSizeStr)
        }
    }
    
    func postDynamicFontNotificationWithContentSizeStr(_ contentSizeStr: String) {
        NotificationCenter.default.post(name: DynamicFontController.fontDidChangeNotificationCustomKey, object: nil, userInfo: [DynamicFontController.fontDidChangeNotificationCustomKey: contentSizeStr])
    }
}
