import Foundation

/// 画面の状態
enum ViewStatus: String {
    case opaque         //不透明
    case placeholder    //プレースホルダ
    case translucent30  //30%半透明
    case translucent60  //60%半透明
    case disableTranslucent30   //エラーの場合30%半透明
}

@objc protocol ViewStatusProtocol: class {
    func applyVisualStatus(_ viewStatus: String)
}

/// 画面の状態
enum ViewControllerStatus: String {
    case opaque         //不透明
    case placeholder    //プレースホルダ
    case translucent    //半透明
    case reload         //Story-3936の更新ボタンを押下時の状態
}

protocol ViewControllerStatusProtocol: class {
    var status: ViewControllerStatus { get set }

    func configurePlaceholderViews()

    func configureTranslucentViews()

    func configureOpaqueViews()

    func configureAllStatusViews(status: ViewStatus)

    func configureReloadViews()
}
