//
//  ProcessService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import CoreLocation

open class ProcessService: NSObject {
    // SINGLETON
    public static let sharedInstance : ProcessService = ProcessService()
    
    // 現在位置情報
    var curtLocation: CLLocation?
    
    fileprivate override init() {
        super.init()
        curtLocation = nil
    }
    
    // GPS情報取得
    let req = LocationManager.shared.locateFromGPS(.continous, accuracy: .city) { result in
      switch result {
        case .failure(let error):
          debugPrint("Received error: \(error)")
        case .success(let location):
          debugPrint("Location received: \(location)")
      }
    }
//    Location.getLocation(accuracy: .room, frequency: .oneShot, timeout: nil, success: {
//        (request, location) in
//            print("現在地を取得しました \(location)")
//            request.cancel()
//        }){ (request, last, error) in
//            print("Location get failed due to an error \(error)")
//        }
//    
//    Location.onReceiveNewLocation = { location in
//        self.curtLocation = location
////            print("- lat,lng=\(location.coordinate.latitude),\(location.coordinate.longitude), h-acc=\(location.horizontalAccuracy) mts\n")
//    }
    
}
