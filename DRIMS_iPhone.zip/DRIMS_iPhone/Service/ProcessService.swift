//
//  ProcessService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import CoreLocation
import CoreMotion

open class ProcessService: NSObject {
    // SINGLETON
    public static let sharedInstance : ProcessService = ProcessService()
    
    let dataService = DataService.sharedInstance
    
    let motionManager = CMMotionManager()
    var attitude = SIMD3<Double>.zero
    var gyro = SIMD3<Double>.zero
    var gravity = SIMD3<Double>.zero
    var acc = SIMD3<Double>.zero
    // 現在位置情報
    var curtLocation: CLLocation?
    
    fileprivate override init() {
        super.init()
        curtLocation = nil
        
        // GPS情報取得確認
        let req: LocationRequest = LocationManager.shared.locateFromGPS(.oneShot, accuracy: .house) { result in
          switch result {
            case .failure(let error):
              debugPrint("Received error: \(error)")
            case .success(let location):
              debugPrint("Location received: \(location)")
          }
        }
        
        startSensorUpdates(intervalSeconds: 0.01) // 100Hz
    }
//    Location.getLocation(accuracy: .room, frequency: .oneShot, timeout: nil, success: {
//        (request, location) in
//            print("現在地を取得しました \(location)")
//            request.cancel()
//        }){ (request, last, error) in
//            print("Location get failed due to an error \(error)")
//        }
//
//    Location.onReceiveNewLocation = { location in
//        self.curtLocation = location
////            print("- lat,lng=\(location.coordinate.latitude),\(location.coordinate.longitude), h-acc=\(location.horizontalAccuracy) mts\n")
//    }
    
    
    func endGetGPSData() {
//         if let request = request {
//            switch request.state {
//            case .expired:
////                monitorController?.completedRequests.removeAll(where: { $0.id == request.id })
////                monitorController?.reload()
//            default:
//                request.stop()
//            }
//        }
    }
    
    public var request: LocationRequest? {
        didSet {
//            stopButton.setTitle( (request?.state == .running ? "Stop" : "Remove"), for: .normal)
//            titleLabel.text = "GPS LOCATION (MIN ACCEPTED: \(request?.accuracy.description ?? "-"))"

            guard let loc = request?.value else {
                print("GPS Error(not received)")
                return
            }

            guard let request = request else {
                return
            }
            
            // localTimeStamp , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course
            let localTimeStamp = CommUtil.date2string(Date())!
            let gpsTimeStamp = CommUtil.date2string(loc.timestamp)!
            let latitude = loc.coordinate.latitude
            let longitude = loc.coordinate.longitude
            let altitude = loc.altitude
            let horizontalAcuracy = loc.horizontalAccuracy
            let verticalAccuracy = loc.verticalAccuracy
            let speed = loc.speed
            let course = loc.course
            
            if dataService.isRecording {
                let timestamp = CommUtil.date2string(Date(), format: "h:m:s.SSS")!
                var text = ""
                text += timestamp + ","
                text += localTimeStamp + ","
                text += gpsTimeStamp + ","
                text += String(latitude) + ","
                text += String(longitude) + ","
                text += String(altitude) + ","
                text += String(horizontalAcuracy) + ","
                text += String(verticalAccuracy) + ","
                text += String(speed) + ","
                text += String(course)
                
                dataService.addRecordGpsText(addText: text)
            }

        }
    }
  
//    func getGpsData() {
//        LocationManager.shared.locateFromGPS(.continous,
//                                             accuracy: .room,
//                                             distance: CLLocationDistance(2)) { result in
//                                                print("\(result)")
//        }
//    }
    
    func getAccData() {
        if dataService.isRecording {
            dataService.stopRecording()

            // save csv file
//            format.dateFormat = "yyyy-MMdd-HHmmss"
            let dateText = dataService.setting.devId + "_"
                         + CommUtil.date2string(Date(), format: "yyyyMMdd_HHmmss")!
                         + "acc.dat"
//            showSaveCsvFileAlert(fileName: dateText)

//            sensorIntervalSlider.isEnabled = true
//            csvFileManagementButton.isEnabled = true
//            recordCsvButton.setTitle("START", for: .normal)
        }else{
            dataService.startRecording()

//            sensorIntervalSlider.isEnabled = false
//            csvFileManagementButton.isEnabled = false
//            recordCsvButton.setTitle("STOP", for: .normal)
        }
    }
        
//        @IBAction func cscFileManagementButtonAction(_ sender: Any) {
//            let csvFileManagementViewController = self.storyboard?.instantiateViewController(withIdentifier: "CsvFileManagementViewController") as! CsvFileManagementViewController
//            csvFileManagementViewController.modalPresentationStyle = .overCurrentContext
//            csvFileManagementViewController.modalTransitionStyle = .crossDissolve
//            self.present(csvFileManagementViewController, animated: true, completion: nil)
//        }

  // intervalSeconds 0.02 :50HZ, 0.01 :100HZ
    func startSensorUpdates(intervalSeconds:Double) {
        if dataService.isRecording {
            return
        }
        
        if motionManager.isDeviceMotionAvailable{
            motionManager.deviceMotionUpdateInterval = intervalSeconds
            
            // start sensor updates
            motionManager.startDeviceMotionUpdates(to: OperationQueue.current!, withHandler: {(motion:CMDeviceMotion?, error:Error?) in
                self.getMotionData(deviceMotion: motion!)
                
            })
        }
    }
    
    func stopSensorUpdates() {
        if !dataService.isRecording {
            return
        }
        
        if motionManager.isDeviceMotionAvailable{
            motionManager.stopDeviceMotionUpdates()
        }
    }
    
    func getMotionData(deviceMotion:CMDeviceMotion) {
        attitude.x = deviceMotion.attitude.pitch
        attitude.y = deviceMotion.attitude.roll
        attitude.z = deviceMotion.attitude.yaw
        gyro.x = deviceMotion.rotationRate.x
        gyro.y = deviceMotion.rotationRate.y
        gyro.z = deviceMotion.rotationRate.z
        gravity.x = deviceMotion.gravity.x
        gravity.y = deviceMotion.gravity.y
        gravity.z = deviceMotion.gravity.z
        acc.x = deviceMotion.userAcceleration.x
        acc.y = deviceMotion.userAcceleration.y
        acc.z = deviceMotion.userAcceleration.z
        
//        displaySensorData()
        
        // record sensor data
        if dataService.isRecording {
            let timestamp = CommUtil.date2string(Date(), format: "h:m:s.SSS")!
            var text = ""
            text += timestamp + ","
            text += String(acc.x) + ","
            text += String(acc.y) + ","
            text += String(acc.z)
            var text2 = ""
            text2 += String(gyro.x) + ","
            text2 += String(gyro.y) + ","
            text2 += String(gyro.z)
            
            dataService.addRecordAccText(addText: text)
            dataService.addRecordAngVelText(addText: text2)
        }
    }
    
    func startGetData(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.startRecording()
        startSensorUpdates(intervalSeconds: AppConstants.GetDataHZ_100)
        completionHandler(true)
    }
    
    func stopGetData(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.stopRecording()
        
        let queue = DispatchQueue(label: "get_data_que")
        let group:DispatchGroup = DispatchGroup()
        let curDateTime = Date()
        // ①File1
        // グループに 「+1」
        group.enter()
        queue.async(group: group) { [weak self] () -> Void in
            self!.dataService.saveMeasurementCsv(saveTime: curDateTime)
            // グループに 「-1」
            group.leave()
        }
        
        // ②File1
        // グループに 「+1」
        group.enter()
        queue.async(group: group) { [weak self] () -> Void in
            self!.dataService.saveCarCsv(saveTime: curDateTime)
            // グループに 「-1」
            group.leave()
        }
        
        // ③File1
        // グループに 「+1」
        group.enter()
        queue.async(group: group) { [weak self] () -> Void in
            self!.dataService.saveAccCsv(saveTime: curDateTime)
            // グループに 「-1」
            group.leave()
        }
        
        // ④File1
        // グループに 「+1」
        group.enter()
        queue.async(group: group) { [weak self] () -> Void in
            self!.dataService.saveAngVelCsv(saveTime: curDateTime)
            // グループに 「-1」
            group.leave()
        }
        
        // ⑤File1
        // グループに 「+1」
        group.enter()
        queue.async(group: group) { [weak self] () -> Void in
            self!.dataService.saveGpsCsv(saveTime: curDateTime)
            // グループに 「-1」
            group.leave()
        }
        
        group.notify(queue: queue) { [weak self] () -> Void in
            // ファイル 圧縮
            
            // callback
            completionHandler(true)
        }

    }
}
