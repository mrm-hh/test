//
//  DataService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation

open class DataService: NSObject{
    // SINGLETON
    public static let sharedInstance : DataService = DataService()
    
    var defaults: Defaults!
  
    var setting: Setting
    var carDataNames: [String]
    
    var isRecording = false
  
  
    private let headerAccText = "localTimeStamp , x, y, z"
    private var recordAccText = ""
    private let headerAngVelText = "localTimeStamp , x, y, z"
    private var recordAngVelText = ""
    private let headerGpsText = "localTimeStamp , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course"
    private var recordGpsText = ""
  
    override init() {
        let hasDatas = defaults.has(.carDatasKey)
        if hasDatas {
            carDataNames = defaults.get(for: .carDatasKey)!
            print("Car data list is getted.")
        } else {
            carDataNames = []
        }
        let hasSetting = defaults.has(.settingKey)
        if hasSetting {
            setting = defaults.get(for: .settingKey)!
        } else {
            setting = Setting(devId: AppConstants.TestCarId, wheelbase: AppConstants.TestWheelbase, sensorPosition: AppConstants.TestSensorPosition, userId: "", userPass: "")
        }
      
        // Test Code
        setting.devId = "h001"
        setting.wheelbase = 200
        setting.sensorPosition = 90
      
        super.init()
    }
  
    func startRecording() {
        recordAccText = ""
        recordAccText += headerAccText + "\n"
        recordAngVelText = ""
        recordAngVelText += headerAngVelText + "\n"
        recordGpsText = ""
        recordGpsText += headerGpsText + "\n"
        isRecording = true
    }
    
    func stopRecording() {
        isRecording = false
    }
    
    func addRecordAccText(addText:String) {
        recordAccText += addText + "\n"
    }
  
    func addRecordAngVelText(addText:String) {
        recordAngVelText += addText + "\n"
    }
    
    func addRecordGpsText(addText:String) {
        recordGpsText += addText + "\n"
    }
    
    // 各ファイル保存メソッド
    func saveAccCsv(saveTime: Date) {
        let recordTitle = "SamplingNumber, 998, SamplingFrequency(Hz), 100, CarID, "
                        + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + fileName + "_acc.dat"
      
        recordAccText = recordTitle + recordAccText
        do{
            try recordAccText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write Acceleration CSV")
        }catch let error as NSError{
            print("Failure to Write Acceleration CSV\n\(error)")
        }
    }
  
    func saveAngVelCsv(saveTime: Date) {
        let recordTitle = "SamplingNumber, 998, SamplingFrequency(Hz), 100, CarID, "
                        + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + fileName + "_ang_vel.dat"
      
        recordAngVelText = recordTitle + recordAngVelText
        do{
            try recordAngVelText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write Ang & Vel CSV")
        }catch let error as NSError{
            print("Failure to Write Ang & Vel CSV\n\(error)")
        }
    }
  
    func saveGpsCsv(saveTime: Date) {
        let recordTitle = "CarID, " + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)!
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")! + "\n"
        let filePath = NSHomeDirectory() + AppConstants.TempDir + fileName + "_gps.dat"
      
        recordGpsText = recordTitle + recordGpsText
        do{
            try recordGpsText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write GPS CSV")
        }catch let error as NSError{
            print("Failure to Write GPS CSV\n\(error)")
        }
    }
  
    func saveCarCsv(saveTime: Date) {
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + fileName + "_carinfo.txt"
        let recordCarinfoText = ""
        do{
            try recordCarinfoText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write CarInfo CSV")
        }catch let error as NSError{
            print("Failure to Write CarInfo CSV\n\(error)")
        }
    }
  
    func saveMeasurementCsv(saveTime: Date) {
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        let filePath = NSHomeDirectory() + AppConstants.TempDir + fileName + "_measurement.txt"
        let recordMeasurementText = ""
        do{
            try recordMeasurementText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write Measurement CSV")
        }catch let error as NSError{
            print("Failure to Write Measurement CSV\n\(error)")
        }
    }
}

extension DefaultsKey {
    static let settingKey = Key<Setting>("settingKey")
    static let carDatasKey = Key<[String]>("carDatasKey")
}
