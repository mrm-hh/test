//
//  DataService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation

open class DataService: NSObject{
    // SINGLETON
    public static let sharedInstance : DataService = DataService()
    
    var defaults: Defaults!
    
    var carDataNames: [String]
    var setting: Setting
    
    override init() {
        let hasDatas = defaults.has(.carDatasKey)
        if hasDatas {
            carDataNames = defaults.get(for: .carDatasKey)!
            print("Car data list is getted.")
        } else {
            carDataNames = []
        }
        let hasSetting = defaults.has(.settingKey)
        if hasSetting {
            setting = defaults.get(for: .settingKey)!
        } else {
            setting = Setting(devId: AppConstants.TestCarId, wheelbase: AppConstants.TestWheelbase, sensorPosition: AppConstants.TestSensorPosition, userId: "", userPass: "")
        }
        
        super.init()
    }
}

extension DefaultsKey {
    static let settingKey = Key<Setting>("settingKey")
    static let carDatasKey = Key<[String]>("carDatasKey")
}
