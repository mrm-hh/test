//
//  CommUtil.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/30.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation

class CommUtil {
    static let dateFormatterYMD:DateFormatter = {
        let df = DateFormatter()
        df.locale     = Locale(identifier: "ja_JP")
        df.dateFormat = "yyyy/MM/dd"
        return df
    }()
    static let dateFormatterYMDhms:DateFormatter = {
        let df = DateFormatter()
        df.locale     = Locale(identifier: "ja_JP")
        df.dateFormat = "yyyy/MM/dd HH:mm:ss"
        return df
    }()
    static let dateFormatterhmsSSS:DateFormatter = {
        let df = DateFormatter()
        df.locale     = Locale(identifier: "ja_JP")
        df.dateFormat = "H:m:ss.SSS"
        return df
    }()
    
    // 文字列 -> 日付型
    static func string2date(_ date_string: String?, format: String = "yyyy-MM-dd HH:mm:ss") -> Date? {
        if date_string == nil || date_string == "" {return nil}
        
        let date_formatter: DateFormatter?
        if format == "yyyy/MM/dd" {
            date_formatter = CommUtil.dateFormatterYMD
        } else if format == "yyyy/MM/dd HH:mm:ss" {
            date_formatter = CommUtil.dateFormatterYMDhms
        } else if format == "H:m:ss.SSS" {
            date_formatter = CommUtil.dateFormatterhmsSSS
        } else {
            date_formatter = DateFormatter()
            date_formatter!.locale = Locale(identifier: "ja_JP")
            date_formatter!.dateFormat = format
        }
        
        return date_formatter!.date(from: date_string!)
    }
    // 日付型 -> 文字列
    static func date2string(_ date: Date?, format: String = "yyyy-MM-dd HH:mm:ss") -> String? {
        if date == nil {return nil}
        
        let date_formatter: DateFormatter?
        if format == "yyyy/MM/dd" {
            date_formatter = CommUtil.dateFormatterYMD
        } else if format == "yyyy/MM-dd HH:mm:ss" {
            date_formatter = CommUtil.dateFormatterYMDhms
        } else if format == "H:m:ss.SSS" {
            date_formatter = CommUtil.dateFormatterhmsSSS
        } else {
            date_formatter = DateFormatter()
            date_formatter!.locale = Locale(identifier: "ja_JP")
            date_formatter!.dateFormat = format
        }
        
        return date_formatter!.string(from: date!)
    }

}
