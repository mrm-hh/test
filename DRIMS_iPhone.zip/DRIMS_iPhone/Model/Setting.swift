//
//  Setting.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/29.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation

struct Setting: Codable {
    let devId: String
    let wheelbase: Int      // 単位：CM
    let sensorPosition: Int // 単位：CM
    
    let userId: String
    let userPass: String
}
