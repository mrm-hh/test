//
//  CarDataInfo.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/29.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation

struct CarDataInfo: Codable {
    let filename: String
    let filesize: String
    let filetime: String
    let check: Bool
}
