//
//  Constants.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation

struct AppConstants {
    static let TestCarId = "hh"
    static let TestWheelbase = 200
    static let TestSensorPosition = 70
    
    static let TempDir = "/tmp/"
    static let DocumentDir = "/Documents/"
}
