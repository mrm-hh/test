//
//  ProcessService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import CoreLocation
import CoreMotion

open class ProcessService: NSObject {
    // SINGLETON
    public static let sharedInstance : ProcessService = ProcessService()
    
    let dataService = DataService.sharedInstance
    
    let motionManager = CMMotionManager()
    var attitude = SIMD3<Double>.zero
    var gyro = SIMD3<Double>.zero
    var gravity = SIMD3<Double>.zero
    var acc = SIMD3<Double>.zero
    // 現在位置情報
    var curtLocation: CLLocation?
    
    fileprivate override init() {
        super.init()
        curtLocation = nil
        
        // GPS情報取得確認
        let req: LocationRequest = LocationManager.shared.locateFromGPS(.oneShot, accuracy: .house) { result in
          switch result {
            case .failure(let error):
              debugPrint("Received error: \(error)")
            case .success(let location):
              debugPrint("Location received: \(location)")
          }
        }
        
        startSensorUpdates(intervalSeconds: 0.01) // 100Hz
    }
//    Location.getLocation(accuracy: .room, frequency: .oneShot, timeout: nil, success: {
//        (request, location) in
//            print("現在地を取得しました \(location)")
//            request.cancel()
//        }){ (request, last, error) in
//            print("Location get failed due to an error \(error)")
//        }
//
//    Location.onReceiveNewLocation = { location in
//        self.curtLocation = location
////            print("- lat,lng=\(location.coordinate.latitude),\(location.coordinate.longitude), h-acc=\(location.horizontalAccuracy) mts\n")
//    }
    
    
    func endGetData() {
//         if let request = request {
//            switch request.state {
//            case .expired:
//                monitorController?.completedRequests.removeAll(where: { $0.id == request.id })
//                monitorController?.reload()
//            default:
//                request.stop()
//            }
//        }
    }
    
    public var request: LocationRequest? {
        didSet {
//            stopButton.setTitle( (request?.state == .running ? "Stop" : "Remove"), for: .normal)
//            titleLabel.text = "GPS LOCATION (MIN ACCEPTED: \(request?.accuracy.description ?? "-"))"

            guard let loc = request?.value else {
                coordinatesLabel.text = "(not received)"
                accuracyLabel.text = "-"
                updateLabel.text = "-"
                return
            }

            guard let request = request else {
                return
            }

            coordinatesLabel.text = NSString(format: "%0.5f, %0.5f", loc.coordinate.latitude, loc.coordinate.longitude) as String
            accuracyLabel.text = NSString(format: "%0.3f mt",loc.horizontalAccuracy) as String

            if request.state == .running {
                updateLabel.text = NSString(format: "%0.0f secs ago", abs(loc.timestamp.timeIntervalSinceNow)) as String
            } else {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:SS"
                updateLabel.text = dateFormatter.string(from: loc.timestamp)
            }

            stopButton.isEnabled = true
            stopButton.alpha = 1.0
        }
    }
  
    func getGpsData() {
        LocationManager.shared.locateFromGPS(.continous,
                                             accuracy: .room,
                                             distance: CLLocationDistance(2)) { result in
                                                print("\(result)")
        }
    }
    
    func getAccData() {
        if dataService.isRecording {
            dataService.stopRecording()

            // save csv file
//            format.dateFormat = "yyyy-MMdd-HHmmss"
            let dateText = dataService.setting.devId + "_"
                         + CommUtil.date2string(Date(), format: "yyyyMMdd_HHmmss")!
                         + "acc.dat"
//            showSaveCsvFileAlert(fileName: dateText)

//            sensorIntervalSlider.isEnabled = true
//            csvFileManagementButton.isEnabled = true
//            recordCsvButton.setTitle("START", for: .normal)
        }else{
            dataService.startRecording()

//            sensorIntervalSlider.isEnabled = false
//            csvFileManagementButton.isEnabled = false
//            recordCsvButton.setTitle("STOP", for: .normal)
        }
    }
        
//        @IBAction func cscFileManagementButtonAction(_ sender: Any) {
//            let csvFileManagementViewController = self.storyboard?.instantiateViewController(withIdentifier: "CsvFileManagementViewController") as! CsvFileManagementViewController
//            csvFileManagementViewController.modalPresentationStyle = .overCurrentContext
//            csvFileManagementViewController.modalTransitionStyle = .crossDissolve
//            self.present(csvFileManagementViewController, animated: true, completion: nil)
//        }

  // intervalSeconds 0.02 :50HZ, 0.01 :100HZ
    func startSensorUpdates(intervalSeconds:Double) {
        if motionManager.isDeviceMotionAvailable{
            motionManager.deviceMotionUpdateInterval = intervalSeconds
            
            // start sensor updates
            motionManager.startDeviceMotionUpdates(to: OperationQueue.current!, withHandler: {(motion:CMDeviceMotion?, error:Error?) in
                self.getMotionData(deviceMotion: motion!)
                
            })
        }
    }
    
    func stopSensorUpdates() {
        if motionManager.isDeviceMotionAvailable{
            motionManager.stopDeviceMotionUpdates()
        }
    }
    
    func getMotionData(deviceMotion:CMDeviceMotion) {
//        print("attitudeX:", deviceMotion.attitude.pitch)
//        print("attitudeY:", deviceMotion.attitude.roll)
//        print("attitudeZ:", deviceMotion.attitude.yaw)
//        print("gyroX:", deviceMotion.rotationRate.x)
//        print("gyroY:", deviceMotion.rotationRate.y)
//        print("gyroZ:", deviceMotion.rotationRate.z)
//        print("gravityX:", deviceMotion.gravity.x)
//        print("gravityY:", deviceMotion.gravity.y)
//        print("gravityZ:", deviceMotion.gravity.z)
//        print("accX:", deviceMotion.userAcceleration.x)
//        print("accY:", deviceMotion.userAcceleration.y)
//        print("accZ:", deviceMotion.userAcceleration.z)
        
        attitude.x = deviceMotion.attitude.pitch
        attitude.y = deviceMotion.attitude.roll
        attitude.z = deviceMotion.attitude.yaw
        gyro.x = deviceMotion.rotationRate.x
        gyro.y = deviceMotion.rotationRate.y
        gyro.z = deviceMotion.rotationRate.z
        gravity.x = deviceMotion.gravity.x
        gravity.y = deviceMotion.gravity.y
        gravity.z = deviceMotion.gravity.z
        acc.x = deviceMotion.userAcceleration.x
        acc.y = deviceMotion.userAcceleration.y
        acc.z = deviceMotion.userAcceleration.z
        
//        displaySensorData()
        
        // record sensor data
        if dataService.isRecording {
            var text = ""
            text += CommUtil.date2string(Date(), format: "h:m:s.SSS")! + ","
            
//            text += String(attitude.x) + ","
//            text += String(attitude.y) + ","
//            text += String(attitude.z) + ","
//            text += String(gyro.x) + ","
//            text += String(gyro.y) + ","
//            text += String(gyro.z) + ","
//            text += String(gravity.x) + ","
//            text += String(gravity.y) + ","
//            text += String(gravity.z) + ","
            text += String(acc.x) + ","
            text += String(acc.y) + ","
            text += String(acc.z)
            
            dataService.addRecordAccText(addText: text)
        }
    }
}
