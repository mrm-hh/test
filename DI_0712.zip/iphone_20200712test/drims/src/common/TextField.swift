import UIKit

@objc protocol TextFieldDelegate: class {
    @objc optional func didChanged(_ textField: TextField, text: String)
    @objc optional func tappedGoButton(_ textField: TextField)
    @objc optional func textFieldGotFocus(_ textField: TextField)
    @objc optional func textFieldLossFocus(_ textField: TextField)
    @objc optional func textClearButton(_ textField: TextField, text: String)
}

class TextField: UIView {
    enum InputStatus {
        case idle
        case active
        case idleWithError
    }

    private var textField: BaseTextField = {
        let textField = BaseTextField()
        textField.font = UIFont.themeFont(with: .level3, strong: .level1)
        return textField
    }()
    
    private var placeHolderLabel: UILabel = {
        let placeHolderLabel = UILabel()
        placeHolderLabel.font = UIFont.themeFont(with: .level3, strong: .level1)
        placeHolderLabel.textColor = .themeGrayAlpha60
        return placeHolderLabel
    }()
    private var underLineView: UIView = {
        let underLineView = UIView()
        underLineView.backgroundColor = .themeUiLightGrayAlpha30
        return underLineView
    }()
    private var rightDownButton: UIButton = {
        let rightDownButton = UIButton()
//        rightDownButton.setImage(#imageLiteral(resourceName: "downButton"), for: .normal)
        rightDownButton.contentMode = .center
        rightDownButton.isHidden = true
        return rightDownButton
    }()
    private lazy var errorMessageLabel: PaddingLabel = {
        let errorMessageLabel = PaddingLabel()
        errorMessageLabel.padding = UIEdgeInsets(top: 2.0, left: 0.0, bottom: 2.0, right: 0.0)
        errorMessageLabel.adjustsFontSizeToFitWidth = true
        errorMessageLabel.font = UIFont.themeFont(with: .level1, strong: .level1)
        errorMessageLabel.backgroundColor = self.backgroundColor ?? UIColor.themeWhite
        errorMessageLabel.textColor = UIColor.themeRed
        return errorMessageLabel
    }()
    private weak var textFieldTrailingConstraint: NSLayoutConstraint!
    private weak var underLineViewHeightConstraint: NSLayoutConstraint!
    private lazy var bottomConstraintForError: NSLayoutConstraint? = {
        if self.shouldRestrainBounds {
            return self.bottomAnchor.constraint(equalTo: errorMessageLabel.bottomAnchor)
        } else {
            return nil
        }
    }()
    private lazy var bottomConstraintForNormal: NSLayoutConstraint? = {
        if self.shouldRestrainBounds {
            return self.bottomAnchor.constraint(equalTo: underLineView.bottomAnchor)
        } else {
            return nil
        }
    }()

    private var status: InputStatus = .idle {
        didSet {
            if oldValue == status {
                return
            }
            switch status {
            case .idle:
                underLineView.backgroundColor = idleColor
                placeHolderLabel.textColor = idleColor
                underLineViewHeightConstraint.constant = 0.5
                errorMessageLabel.isHidden = true
            case .active:
                underLineView.backgroundColor = activeColor
                placeHolderLabel.textColor = activeColor
                underLineViewHeightConstraint.constant = 1.5
                errorMessageLabel.isHidden = true
            case .idleWithError:
                underLineView.backgroundColor = errorColor
                placeHolderLabel.textColor = idleColor
                underLineViewHeightConstraint.constant = 0.5
                errorMessageLabel.isHidden = false
            }
            if shouldRestrainBounds {
                // FIXME: breaking constraint warning
                bottomConstraintForError?.isActive = (errorMessageLabel.isHidden == false)
                bottomConstraintForNormal?.isActive = (errorMessageLabel.isHidden == true)
            }
        }
    }
    var shouldRestrainBounds:Bool = false {
        didSet{
            if shouldRestrainBounds {
                errorMessageLabel.removeConstraints()
                errorMessageLabel.numberOfLines = 0
                errorMessageLabel.lineBreakMode = .byCharWrapping
                errorMessageLabel.layouts([
                    "H:|[self]|": .directionLeadingToTrailing,
                    "V:[underlineView]-0.5-[self(>=20)]": .directionLeadingToTrailing,
                    ], with: [
                        "underlineView" : underLineView,
                        ])
            }else{
                errorMessageLabel.layouts([
                    "H:|[self]": .directionLeadingToTrailing,
                    "V:[underlineView]-0.5-[self(20)]": .directionLeadingToTrailing,
                    ], with: [
                        "underlineView" : underLineView,
                        ])
            }
        }
    }
  var isHiddenInputAccessoryView = false {
        didSet {
            if isHiddenInputAccessoryView {
                textField.inputAccessoryView = nil
            } else {
                textField.inputAccessoryView = KeyboardAccessoryView.shared
            }
            
        }
    }
    var originFrame:CGRect?
    
    var activeColor: UIColor = UIColor.themeTradGreen
    var idleColor: UIColor = UIColor.themeGrayAlpha60
    var errorColor: UIColor = UIColor.themeRed
    var maxLength: Int = 0
    var onlyNumber: Bool = false
    var onlyNumberAndAlphabet: Bool = false
    var onlyNumberAndHalfAlphabet: Bool = false
    var onlyNumberAndHalfAlphabetAndSpecial: Bool = false
    var preferredLanguage: String? {
        didSet {
            textField.preferredLanguage = preferredLanguage
        }
    }
    var placeHolder: String? {
        didSet {
            placeHolderLabel.text = placeHolder
            placeHolderLabel.isHidden = (placeHolder ?? "").count < 1
            placeHolderLabel.sizeToFit()
        }
    }
    var errorMessage = "" {
        didSet {
            errorMessageLabel.text = errorMessage
            if hasError && textField.isFirstResponder == false {
                status = .idleWithError
            } else if textField.isFirstResponder {
                status = .active
            } else {
                status = .idle
            }
        }
    }
    var hasError: Bool {
        return errorMessage.count > 0
    }
    var hasRightDownButton: Bool = false {
        didSet {
            textFieldTrailingConstraint.constant = hasRightDownButton ? 51.0 : 5.0
            rightDownButton.isHidden = !hasRightDownButton
        }
    }
    var font: UIFont? {
        get {
            return textField.font
        }
        set {
            textField.font = newValue
        }
    }
    var placeHolderFont: UIFont? {
        get {
            return placeHolderLabel.font
        }
        set {
            placeHolderLabel.font = newValue
        }
    }
    var errorFont: UIFont? {
        get {
            return errorMessageLabel.font
        }
        set {
            errorMessageLabel.font = newValue
        }
    }
    var keyboardType: UIKeyboardType {
        get {
            return textField.keyboardType
        }
        set {
            textField.keyboardType = newValue
        }
    }
    var autocapitalizationType: UITextAutocapitalizationType {
        get {
            return textField.autocapitalizationType
        }
        set {
            textField.autocapitalizationType = newValue
        }
    }
    var text: String? {
        get {
            return (maskingText ?? "").count > 0 ? maskingText : textField.text
        }
        set {
            if (maskingText ?? "").count > 0 {
                textField.text = newValue
            }
            else if let _ = format {
                var result :(String, Int)?
                let textString: NSString = ((newValue ?? "") as NSString)

                for (i, ch) in (newValue ?? "").enumerated() {
                    let text = textString.substring(with: NSRange(location: 0, length: i + 1))
                    let range = NSRange(location: i + 1, length: 0)
                    result = checkFormat(text: text, range: range, replacementString: String(ch))
                }

                if let (newText, _) = result {
                    textField.text = newText
                } else {
                    textField.text = newValue
                }
            } else {
                textField.text = newValue
            }

            if 0 < (newValue?.count ?? 0) {
                textFieldTransform()
            } else {
                textFieldNoTransform()
            }
        }
    }
    var isSecureTextEntry: Bool {
        get {
            return textField.isSecureTextEntry
        }
        set {
            textField.isSecureTextEntry = newValue
        }
    }
    
    var maskingText: String? = ""
    
    @available(iOS 10.0, *)
    var textContentType: UITextContentType {
        get {
            return textField.textContentType
        }
        set {
            textField.textContentType = newValue
        }
    }
    var clearButtonMode: UITextField.ViewMode {
        get {
            return textField.clearButtonMode
        }
        set {
            textField.clearButtonMode = newValue
        }
    }
    var returnKeyType: UIReturnKeyType {
        get {
            return textField.returnKeyType
        }
        set {
            textField.returnKeyType = newValue
        }
    }
    var defaultTextAttributes: [NSAttributedString.Key : Any] {
        get {
            return textField.defaultTextAttributes
        }
        set {
            textField.defaultTextAttributes = newValue
        }
    }
    var isEnabled: Bool {
        get {
            return textField.isEnabled
        }
        set {
            textField.isEnabled = newValue
            textField.textColor = newValue ? UIColor.themeUiDarkGray : UIColor.themeGrayAlpha60
            if !newValue {
                underLineView.backgroundColor = UIColor.themeUiLightGrayAlpha20
            }
        }
    }
    
    var textAlignment: NSTextAlignment {
        get {
            return textField.textAlignment
        }
        set {
            textField.textAlignment = newValue
        }
    }
    
    var clearsOnBeginEditing: Bool {
        get {
            return textField.clearsOnBeginEditing
        }
        set {
            textField.clearsOnBeginEditing = newValue
        }
    }

    var isDisabledPaste: Bool = false {
        didSet {
            textField.isDisabledPaste = isDisabledPaste
        }
    }

    override var isFirstResponder: Bool {
        return textField.isFirstResponder
    }

    var format: String? = nil
    weak var delegate: TextFieldDelegate?
    weak var preTextField: TextField?
    weak var nextTextField: TextField?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    convenience init(frame:CGRect,isRestrictBounds:Bool){
        self.init(frame: frame)
        self.setShouldRestrainBounds(shouldRestrainBounds: isRestrictBounds)
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }

    @discardableResult
    override func becomeFirstResponder() -> Bool {
        return textField.becomeFirstResponder()
    }

    @discardableResult
    override func resignFirstResponder() -> Bool {
        return textField.resignFirstResponder()
    }
    
    private func setShouldRestrainBounds(shouldRestrainBounds:Bool){
        self.shouldRestrainBounds = shouldRestrainBounds
    }
    
    private func setup(isRestrictBounds:Bool = false) {
        addSubview(textField)
        textField.layouts([
            "H:|[self]-5-|": .directionLeadingToTrailing,
            "V:|-12-[self(40)]": .directionLeadingToTrailing,
            ])
        textField.delegate = self
        textField.baseTextFieldDelegate = self
        for constraint in constraints {
            if constraint.secondItem === textField && constraint.secondAttribute == .trailing {
                textFieldTrailingConstraint = constraint
                break
            }
        }
        
        addSubview(placeHolderLabel)
        placeHolderLabel.layouts([
            "H:|[self]": .directionLeadingToTrailing,
            "V:|-12-[self(40)]": .directionLeadingToTrailing,
            ])
        
        addSubview(underLineView)
        underLineView.layouts([
            "H:|[self]|": .directionLeadingToTrailing,
            "V:|-52.5-[self(1)]": .directionLeadingToTrailing,
            ])
        for constraint in constraints {
            if constraint.firstItem === underLineView && constraint.firstAttribute == .height {
                underLineViewHeightConstraint = constraint
            }
        }
        
        addSubview(rightDownButton)
        rightDownButton.layouts([
            "H:[self(44)]-4-|": .directionLeadingToTrailing,
            "V:|-10-[self(44)]": .directionLeadingToTrailing,
            ])
        
        addSubview(errorMessageLabel)
        errorMessageLabel.layouts([
            "H:|[self]": .directionLeadingToTrailing,
            "V:[underlineView]-0.5-[self(20)]": .directionLeadingToTrailing,
            ], with: [
                "underlineView" : underLineView,
                ])
    }

    func setRightButtonImage(){
        rightDownButton.setImage(#imageLiteral(resourceName: "search"), for: .normal)
    }
    
    func addRightButtonTarget(_ target: Any, action: Selector) {
        rightDownButton.addTarget(target, action: action, for: .touchUpInside)
    }

    func setCursor(_ pos: Int) {
        let position = textField.position(from: textField.beginningOfDocument, in: .right, offset: pos)!
        textField.selectedTextRange = textField.textRange(from: position, to: position)
    }

    func getCursor() -> Int {
        return textField.offset(from: textField.beginningOfDocument,
                                to: (textField.selectedTextRange?.start)!)
    }

    func checkFormat(text: String, range: NSRange, replacementString string: String) -> (String, Int)? {
        guard let format = self.format else {
            return nil
        }
        if 0 < string.count && !string.isNumber {
            return nil
        }
        var filteredString = text.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        let maxNumberCount = format.filter { $0 == "#" || $0 == "*" }.count
        if  maxNumberCount < filteredString.count {
            filteredString = filteredString[0..<maxNumberCount]
        }
        var i = 0
        var res = ""
        var newPosition = range.location + (0 < range.length ? 0 : 1)
        var lastNumberPosition = 0
        for (j, ch) in format.enumerated() {
            if (ch == "#" || ch == "*") && filteredString.count <= i {
                break
            }
            switch ch {
            case "#":
                let tmp = (filteredString[i] as Character)
                if tmp < "0" || "9" < tmp {
                    return nil
                }
                res += filteredString[i] as String
                i += 1
                lastNumberPosition = i
            case "*":
                res += "*"
                i += 1
                lastNumberPosition = i
            default:
                res += String(ch)
                if j == newPosition {
                    if 0 < range.length {
                        // 削除の場合
                        newPosition = lastNumberPosition - 1
                        res = res[0..<newPosition]
                    } else {
                        newPosition += 1
                    }
                }
            }
        }
        return (res, min(newPosition, res.count))
    }

    func setInputAccessoryView(_ inputAccessoryView: UIView) {
        textField.inputAccessoryView = inputAccessoryView
    }
}

extension TextField: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if (maskingText ?? "").count > 0 {
            self.maskingText = ""
            self.text = ""
            DispatchQueue.main.async {
                self.delegate?.didChanged?(self, text: "")
            }
        }

//        if isSecureTextEntry {
//            self.text = ""
//            DispatchQueue.main.async {
//                self.delegate?.didChanged?(self, text: "")
//            }
//        }
        
        if (status == .idle || status == .idleWithError) && (textField.text ?? "").count < 1 {
            
            UIView.animate(withDuration: 0.15) {
                self.textFieldTransform()
            }
        }
        status = .active

        textField.reloadInputViews()
        delegate?.textFieldGotFocus?(self)
        return true
    }

    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if hasError {
            status = .idleWithError
            if (textField.text ?? "").count < 1 {
                UIView.animate(withDuration: 0.15) {
                    self.textFieldNoTransform()
                }
            }
        } else {
            status = .idle
            if (textField.text ?? "").count < 1 {
                UIView.animate(withDuration: 0.15) {
                    self.textFieldNoTransform()
                }
            }
        }
        delegate?.textFieldLossFocus?(self)
        return true
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // nextFieldが設定されている場合それが優先される
        if nextTextField != nil {
            nextTextField?.becomeFirstResponder()
        } else {
            resignFirstResponder()
            self.delegate?.tappedGoButton?(self)
        }
        return true
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var text = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        var res = true
        if 0 < text.count {
            if onlyNumber && !text.isNumber {
                return false
            }
            
            if onlyNumberAndAlphabet && !text.isNumberAndAlphabet {
                return false
            }
            
            if onlyNumberAndHalfAlphabet && !text.isNumberAndHalfAlphabet {
                return false
            }
            
            if onlyNumberAndHalfAlphabetAndSpecial && !text.isNumberAndHalfAlphabetAndSpecial {
                return false
            }
            
            if let _ = format {
                if let (newText, newPosition) = checkFormat(text: text, range: range, replacementString: string) {
                    textField.text = newText
                    DispatchQueue.main.async {
                        self.setCursor(newPosition)
                    }
                    
                    text = newText
                    res = false
                } else {
                    return false
                }
            }
            if 0 < maxLength {
                if maxLength < text.count {
                    text = text.cutTail(to: maxLength)
                    textField.text = text
                    if nextTextField != nil {
                        DispatchQueue.main.async {
                            self.nextTextField?.becomeFirstResponder()
                        }
                    }
                    res = false
                } else if maxLength == text.count  {
                    DispatchQueue.main.async {
                        self.nextTextField?.becomeFirstResponder()
                    }
                }
            }
        }
        DispatchQueue.main.async {
            self.delegate?.didChanged?(self, text: text)
        }
        return res
    }

    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        DispatchQueue.main.async {
            self.delegate?.didChanged?(self, text: "")
            self.delegate?.textClearButton?(self, text: "")
        }
        return true
    }
}

extension TextField: BaseTextFieldDelegate {
    func tappedBackword(_ textField: BaseTextField) {
        preTextField?.becomeFirstResponder()
    }
}

extension TextField {
    
    func textFieldTransform() {
        let scale: CGFloat = 12.0 / 16.0
        let diff = placeHolderLabel.bounds.width * (1.0 - scale)
        self.placeHolderLabel.transform = CGAffineTransform(scaleX: scale, y: scale).concatenating(CGAffineTransform(translationX: -diff / 2.0, y: -24.0))
    }
    
    func textFieldNoTransform() {
        self.placeHolderLabel.transform = .identity
    }
}
