//
//  TakeVideoViewController.swift
//  drims
//
//  Created by 卓天成 on 2020/06/16.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import UIKit

class TakeVideoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = NSLocalizedString("Video", comment: "")

    }

}
