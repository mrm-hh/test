//
//  RecordViewController.swift
//  drims
//
//  Created by 黄海 on 2020/04/04.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit
import SVProgressHUD

class RecordViewController: UIViewController, UIGestureRecognizerDelegate {
    var startFlg = true
    var isDoing = false
    
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var videoTimerLabel: VideoTimerLabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var speedLabel: UILabel!
    
    @IBOutlet weak var videoFrameView: UIView!
    @IBOutlet var videoFrameViewPanGesture: UIPanGestureRecognizer!
    
    var videoFrame: CGRect?
    
    var timer: Timer? = Timer()
    
    let procService = ProcessService.sharedInstance
    var videoRecoder: VideoService!
    
    
    @IBAction func handlePan(_ gestureRecognizer: UIPanGestureRecognizer) {
        let tabBarHeight = self.navigationController!.tabBarController!.tabBar.frame.size.height
        let bottomLimit = UIScreen.main.bounds.size.height - tabBarHeight
        let frameBottom = (gestureRecognizer.view?.frame.origin.y)! + (gestureRecognizer.view?.frame.size.height)!
        
        if gestureRecognizer.state == .began || gestureRecognizer.state == .changed {
            if (gestureRecognizer.view?.frame.origin.y)! < self.view.safeAreaLayoutGuide.layoutFrame.origin.y {
                var frame = gestureRecognizer.view?.frame
                frame?.origin.y = self.view.safeAreaLayoutGuide.layoutFrame.origin.y
                gestureRecognizer.view?.frame = frame!
            } else if frameBottom > bottomLimit {
                var frame = gestureRecognizer.view?.frame
                frame!.origin.y = bottomLimit - self.view.safeAreaLayoutGuide.layoutFrame.origin.y - (frame?.size.height)! + self.view.safeAreaLayoutGuide.layoutFrame.origin.y
                gestureRecognizer.view?.frame = frame!
            } else {
                let translation = gestureRecognizer.translation(in: self.view)
                gestureRecognizer.view!.center = CGPoint(x: gestureRecognizer.view!.center.x, y: gestureRecognizer.view!.center.y + translation.y)
                gestureRecognizer.setTranslation(CGPoint.zero, in: self.view)
            }
        }
        
        if gestureRecognizer.state == .ended {
            if (gestureRecognizer.view?.frame.origin.y)! < self.view.safeAreaLayoutGuide.layoutFrame.origin.y {
                var frame = gestureRecognizer.view?.frame
                frame?.origin.y = self.view.safeAreaLayoutGuide.layoutFrame.origin.y
                gestureRecognizer.view?.frame = frame!
            } else if frameBottom > bottomLimit {
                var frame = gestureRecognizer.view?.frame
                frame!.origin.y = bottomLimit - self.view.safeAreaLayoutGuide.layoutFrame.origin.y - (frame?.size.height)! + self.view.safeAreaLayoutGuide.layoutFrame.origin.y
                gestureRecognizer.view?.frame = frame!
            }
        }
        
        videoFrame = gestureRecognizer.view?.frame
    }

    // start button click
    @IBAction func recordPressed(_ sender: UIButton) {
        // check setting
        let alert = procService.checkSetting() {
            let vc = self.tabBarController!.viewControllers![3];
            self.tabBarController?.selectedViewController = vc
        }
        
        if alert != nil {
            self.present(alert!, animated: true, completion: nil)
            return
        }
        
        // Get Datas
        print(isDoing)
        if isDoing {
            return;
        }
        
        procService.queue = DispatchQueue(label: "proc_que")
        procService.group = DispatchGroup()
        let queue = procService.queue!
        let group = procService.group!
        
        isDoing = true
        if startFlg {
            videoFrame = self.videoFrameView.frame//CGRect(x: 100, y: 100, width: 600, height: 600) 
            videoRecoder.cropFrame = videoFrame
            videoRecoder.screenFrame = self.view.frame
            videoRecoder.safeAreaFrame = self.view.safeAreaLayoutGuide.layoutFrame
            
            UIApplication.shared.isIdleTimerDisabled = true
            videoFrameViewPanGesture.isEnabled = false
            
            procService.startGetDataWhenVideo(completionHandler: {
                ret in
                print("*Process is started.")
                self.startFlg = !self.startFlg
                self.isDoing = false
            })
            
        } else {
            UIApplication.shared.isIdleTimerDisabled = false
            videoFrameViewPanGesture.isEnabled = false//true
            // グループに 「+1」
            group.enter()
            queue.async(group: group) { [weak self] () -> Void in
                self!.procService.stopGetDataWhenVideo {
                    ret in
                    print("*Process is stoped.")
                    self!.startFlg = !self!.startFlg
                    self!.isDoing = false
                    // グループに 「-1」
                    group.leave()
                }
            }
        }
        
        // Get Video
        if videoRecoder.isInitialized{
            
            if (!videoRecoder.isRecording){
                print(CommUtil.date2string(Date())! + " 動画撮像開始.")
                videoRecoder.startRecording()
                videoTimerLabel.startTimer()
            }else{
                SVProgressHUD.show()
                // グループに 「+1」
                group.enter()
                queue.async(group: group) { [weak self] () -> Void in
                    self!.videoRecoder.stopRecording(completionHandler: {
                        ret in
                        
                        // ファイル 圧縮
                        DataService.sharedInstance.makeZipFileWhenVideo()
                        
                        print(CommUtil.date2string(Date())! + " 動画撮像終了.")
                        // グループに 「-1」
                        group.leave()
                        
                        SVProgressHUD.dismiss(withDelay: 1)
                    })
                }
                
                group.notify(queue: queue) { [weak self] () -> Void in
                    // ファイル 圧縮
//                    DataService.sharedInstance.makeZipFile()
                    print(CommUtil.date2string(Date())! + " ZIPファイルを生成しました.")
                }
            }
        }
        
        updateControls()
    }
    
    func disableTabbarItem(){
        if  let arrayOfTabBarItems = self.tabBarController?.tabBar.items as AnyObject as? NSArray {
            for tabBarItem in arrayOfTabBarItems {
                (tabBarItem as! UITabBarItem).isEnabled = false
            }
        }
    }
    func enableTabbarItem() {
        if  let arrayOfTabBarItems = self.tabBarController?.tabBar.items as AnyObject as? NSArray {
            for tabBarItem in arrayOfTabBarItems {
                (tabBarItem as! UITabBarItem).isEnabled = true
            }
        }
    }
    
    // pause button click
    @IBAction func pausePressed(_ sender: UIButton) {
        if videoRecoder.isInitialized{
            
            if (videoRecoder.isPaused){
                
                videoRecoder.resumeRecording()
                
            }else{
                
                videoRecoder.pauseRecording()
            }
        }
        
        updateControls()
    }
    
    // play button click
    @IBAction func playPressed(_ sender: Any) {
        if hasPlayList{
            
            let playListController = PlayListTableViewController(style: .plain)
            
            let navController = UINavigationController(rootViewController: playListController)
            
            self.present(navController, animated: true, completion: nil)
            
        }
    }
    
    var hasPlayList:Bool{
        
        get{
            
            let playList = DataService.sharedInstance.defaults.get(for: .playListKey)

            return playList != nil && playList!.count > 0
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        videoFrameView.layer.borderWidth = 1.5
        videoFrameView.layer.borderColor = UIColor.white.cgColor
        videoFrameView.alpha = 0.4
        videoFrameViewPanGesture.delegate = self
        
        self.navigationItem.title = NSLocalizedString("Video", comment: "")
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateControls(_:)), name: .VideoRecordingUpdate, object: nil)
                
        videoRecoder = VideoService()
        setupUI()

        checkCameraPermission()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
        
        if procService.curtLocation != nil {
            let lat = procService.curtLocation!.coordinate.latitude
            let lng = procService.curtLocation!.coordinate.longitude
            self.addressLabel.text = procService.curtLocationDesp ?? ""
            self.locationLabel.text = String(format: "%.3f", lat) + " , " + String(format: "%.3f", lng)
        }
        
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true, block: { (timer) in
            if let loc = self.procService.curtLocation {
                //GPS info
                var speed = loc.speed
                if speed < 0 {
                    speed = 0;
                }
                let lat = loc.coordinate.latitude
                let lng = loc.coordinate.longitude
                let info = String(format: "%.1f km/h", speed * 3.6)
                DispatchQueue.main.async() {
                    self.speedLabel.text = info
                    if let addrStr = self.procService.curtLocationDesp {
                        self.addressLabel.text = addrStr
                    }
                    self.locationLabel.text = String(format: "%.3f", lat) + " , " + String(format: "%.3f", lng)
                }
            }
        })
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if videoRecoder.isRecording {
            self.recordPressed(UIButton())
        }
        
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
    }
    
    private func checkCameraPermission(){
        
        AVCaptureDevice.requestAccess(for: .video, completionHandler: {(_ granted: Bool) -> Void in
        
            if granted {
            
                DispatchQueue.main.async(execute: {() -> Void in
                    
                    self.startVideoSession()
                })
            }
            else {
                
                DispatchQueue.main.async(execute: {() -> Void in
                
                    let cameraAlertController = UIAlertController(title: "Camera Permission Denied", message: "RegTrac needs access to your camera in order to scan Barcodes. Please enable it", preferredStyle: .alert)
                    
                    cameraAlertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in
                        
                    }))
                    
                    cameraAlertController.addAction(UIAlertAction(title: "Settings", style: .default, handler: { (action) in
                                                    
                        let settingsURL = URL(string: UIApplication.openSettingsURLString)
                        UIApplication.shared.open(settingsURL!, options: [:], completionHandler: nil)

                    }))
                    
                    self.present(cameraAlertController, animated: true, completion: nil)
                })
            }
        })
    }
    
    private func startVideoSession(){
        
        if videoRecoder.setupRecorder(){
            
            setUpCameraPreview()
            
            videoRecoder.resumeSession()
        }
                
        self.view.bringSubviewToFront(recordButton)
        self.view.bringSubviewToFront(pauseButton)
        self.view.bringSubviewToFront(playButton)
        self.view.bringSubviewToFront(videoTimerLabel)
        
        updateControls()
    }

    private func setupUI(){
        recordButton.applyBorder(20.0, color: .white, width: 2)
        pauseButton.applyBorder(20.0, color: .white, width: 2)
        playButton.applyBorder(20.0, color: .white, width: 2)
        videoTimerLabel.applyBorder(20.0, color: .white, width: 2)

        updateControls()
    }
    
    @objc private func updateControls(_ notification: Notification? = nil){
        DispatchQueue.main.async {
            self.playButton.isHidden = true
//            if self.videoFrame != nil {
//                self.videoFrameView.frame = self.videoFrame!
//            }
            if self.videoRecoder.isRecording{
                self.disableTabbarItem()
    //            pauseButton.isHidden = false
                self.videoTimerLabel.isHidden = false

                self.recordButton.setTitle("STOP", for: .normal)
                
                if self.videoRecoder.isPaused{
                    
                    self.videoTimerLabel.pauseTimer()
                    
                    self.pauseButton.setTitle("RESUME", for: .normal)
                }else{
                    
                    self.videoTimerLabel.startTimer()

                    self.pauseButton.setTitle("PAUSE", for: .normal)
                }
            }else{
                self.videoTimerLabel.stopTimer()
                
                self.recordButton.setTitle("START", for: .normal)
                self.pauseButton.isHidden = true
                self.videoTimerLabel.isHidden = true
                
                if self.hasPlayList{
                    
                    self.playButton.isHidden = false
                }
                
                self.enableTabbarItem()
            }
        }
    }
    
    func setUpCameraPreview() {
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: videoRecoder.session)
        previewLayer.backgroundColor = UIColor.white.cgColor
        previewLayer.videoGravity = .resize//.resizeAspectFill

        let rootLayer: CALayer = self.view.layer
        rootLayer.masksToBounds = true
        
        previewLayer.frame =  CGRect(x: 10, y: 250, width:  168.75, height:300) //rootLayer.bounds
        
//        rootLayer.addSublayer(previewLayer)
        rootLayer.insertSublayer(previewLayer, at: 0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

extension UIView{
    
    func applyBorder(_ radius:CGFloat, color:UIColor, width:CGFloat){
        
        self.layer.cornerRadius = radius
        self.layer.borderColor = color.cgColor
        self.layer.masksToBounds = true
        self.layer.borderWidth = width
    }
}

extension Notification.Name{
    
    static let VideoRecordingUpdate = Notification.Name("VideoRecordingDoneNotification")
}
