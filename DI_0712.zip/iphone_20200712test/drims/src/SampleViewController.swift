//
//  SampleViewController.swift
//  drims
//
//  Created by 卓天成 on 2020/06/11.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import UIKit
import CoreLocation
import SVProgressHUD



class SampleViewController: UIViewController {

    let procService = ProcessService.sharedInstance
    let dataService = DataService.sharedInstance
    var startFlg = true
    var isDoing = false
    var isAnimationInit = false

    var timer: Timer? = Timer()
    var locationManager: CLLocationManager!
    
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var deviceIDTitleLabel: UILabel!
    @IBOutlet weak var deviceIDLabel: UILabel!
    @IBOutlet weak var wheelbaseTitleLabel: UILabel!
    @IBOutlet weak var wheelbaseLabel: UILabel!
    @IBOutlet weak var sensorPositionTitleLabel: UILabel!
    @IBOutlet weak var sensorPositionLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var videoTimerLabel: VideoTimerLabel!

    
    
    var buttonStop: UIButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
    var buttonStart:UIButton = UIButton(type: UIButton.ButtonType.custom) as UIButton
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.title = "GLOCAL-EYEZ ROAD"
        self.navigationController?.tabBarItem.title = NSLocalizedString("Sample", comment: "")
        self.navigationController?.tabBarController?.tabBar.items![1].title = NSLocalizedString("Video", comment: "")
        self.navigationController?.tabBarController?.tabBar.items![2].title = NSLocalizedString("File", comment: "")
        self.navigationController?.tabBarController?.tabBar.items![3].title = NSLocalizedString("Setting", comment: "")
        
        self.deviceIDTitleLabel.text = NSLocalizedString("device_id", comment: "") + ": "
        self.wheelbaseTitleLabel.text = NSLocalizedString("wheel_base", comment: "") + ": "
        self.sensorPositionTitleLabel.text = NSLocalizedString("sensor_position", comment: "") + ": "
        
        startFlg = true
        isDoing = false
        isAnimationInit = false
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        if dataService.drimsId == "" {
            print("初期起動")
            dataService.drimsId = NSUUID().uuidString
            dataService.installTime = CommUtil.date2string(Date())!
            dataService.appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
            dataService.deviceID = NSUUID().uuidString
            
            dataService.saveSysInfo()
        }
        
        buttonStop.frame = CGRect(x: 100, y: 100, width: 300, height: 300)
        buttonStop.setImage(UIImage(named: "stop"), for: UIControl.State.normal)
        //        buttonStop.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)
        buttonStop.imageView?.contentMode = .scaleAspectFit
        buttonStop.contentHorizontalAlignment = .fill
        buttonStop.contentVerticalAlignment = .fill
        buttonStop.imageEdgeInsets = UIEdgeInsets(top: 140, left: 140, bottom: 140, right: 140)
        view.addSubview(buttonStop)
        buttonStop.horizenCenter()
        buttonStop.verticalCenter()
        buttonStop.isHidden = true
        
        buttonStart.frame = CGRect(x: 100, y: 100, width: 300, height: 300)
        buttonStart.setImage(UIImage(named: "start"), for: UIControl.State.normal)
        //        buttonStart.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)
        buttonStart.imageView?.contentMode = .scaleAspectFit
        buttonStart.contentHorizontalAlignment = .fill
        buttonStart.contentVerticalAlignment = .fill
        buttonStart.imageEdgeInsets = UIEdgeInsets(top: 140, left: 140, bottom: 140, right: 140)
        view.addSubview(buttonStart)
        buttonStart.horizenCenter()
        buttonStart.verticalCenter()
        
        
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(self.procBtnOnClick(_ :)), for: UIControl.Event.touchUpInside)

        view.addSubview(button)
        button.layouts([
            "H:[self(140)]": .alignAllCenterY,
            "V:[self(140)]": .alignAllCenterX
        ])
        button.horizenCenter()
        button.verticalCenter()
        
        NotificationCenter.default.addObserver(self, selector: #selector(stopSampleData), name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(checkUnresovledData), name: UIApplication.willEnterForegroundNotification, object: nil)

        print("\(String(describing: CommUtil.date2string(Date()))) DRIMS APP if started.")
        
        videoTimerLabel.applyBorder(20.0, color: .white, width: 2)
    }
    
    
    
   override func viewWillAppear(_ animated: Bool) {
        if dataService.setting.devId == "" {
            deviceIDLabel.text = "-"
        } else {
            deviceIDLabel.text = dataService.setting.devId
        }
        
        if dataService.setting.wheelbase == 0 {
             wheelbaseLabel.text = "-"
        } else {
            wheelbaseLabel.text = String(dataService.setting.wheelbase)
        }
    
        if dataService.setting.sensorPosition == 0 {
            sensorPositionLabel.text = "-"
        } else {
            sensorPositionLabel.text = String(dataService.setting.sensorPosition)
        }

        startFlg = true
        isDoing = false
        isAnimationInit = false

        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
        //timer処理
//        var speed = 1.1;
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true, block: { (timer) in
            if let loc = self.procService.curtLocation {
                //GPS info
                var speed = loc.speed
                if speed < 0 {
                    speed = 0;
                }
//                speed = speed + 1;
                let lat = loc.coordinate.latitude
                let lng = loc.coordinate.longitude
                let info = String(format: "%.1f km/h", speed * 3.6)
                DispatchQueue.main.async() {
                    self.speedLabel.text = info
                    if let addrStr = ProcessService.sharedInstance.curtLocationDesp {
                        self.addressLabel.text = addrStr
                    }
                    self.locationLabel.text = String(format: "%.3f", lat) + " , " + String(format: "%.3f", lng)
                }
            }
        })
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        if timer != nil {
            timer!.invalidate()
            timer = nil
        }
        super.viewDidDisappear(animated)
    }
    
    @objc func checkUnresovledData() {
        // 初期処理procService.initProcess()が実行済なので、不要
//        if self.procService.checkUnresovledData() {
//            SVProgressHUD.show(withStatus: "有未处理的数据，正在处理中...")
//            self.procService.initProcess()
//            SVProgressHUD.dismiss(withDelay: 1)
//        }
    }
    
    @objc func stopSampleData() {
        if !self.startFlg {
            UIApplication.shared.isIdleTimerDisabled = false
            self.pauseLayer(layer: self.buttonStop.layer)
            
            self.startFlg = !self.startFlg
            self.isDoing = false
            
//            DispatchQueue.global(qos: .default).async {
//                self.procService.stopGetDataWhenAbnormal(completionHandler: { ret in
//                    print("*Process is stoped.")
//                })
//            }
            
            DispatchQueue.main.async {
                self.videoTimerLabel.stopTimer()
                
                self.buttonStop.isHidden = true
                self.buttonStart.isHidden = false
                self.buttonStop.imageView?.stopAnimating()

                self.enableTabbarItem()
            }
        }
    }
    
    @objc func procBtnOnClick(_ sender: UIButton) {
        if startFlg {
            
            if isDoing {
                return;
            }
            
            // check setting
            let alert = procService.checkSetting() {
                let vc = self.tabBarController!.viewControllers![3];
                self.tabBarController?.selectedViewController = vc
            }
            if alert != nil {
                self.present(alert!, animated: true, completion: nil)
                return
            }
            
            self.isDoing = true
            UIApplication.shared.isIdleTimerDisabled = true
            
            self.procService.startGetData(completionHandler: {
                ret in
                print("*Process is started.")
                
                self.startFlg = !self.startFlg
                
                self.buttonStop.isHidden = false
                self.buttonStart.isHidden = true
                self.disableTabbarItem()
                
                self.videoTimerLabel.startTimer()
                
                if self.isAnimationInit == false {
                    self.isAnimationInit = true
                    UIView.animate(withDuration: 0.6,
                                   delay: 0,
                                   options: [UIView.AnimationOptions.allowUserInteraction, UIView.AnimationOptions.autoreverse, UIView.AnimationOptions.repeat],
                                   animations: {
                                    self.buttonStop.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
                    },
                                   completion: { _ in
                                    UIView.animate(withDuration: 0.6) {
                                        self.buttonStop.transform = CGAffineTransform.identity
                                    }
                    })
                    self.resumeLayer(layer: self.buttonStop.layer)
                } else {
                    self.resumeLayer(layer: self.buttonStop.layer)
                }
            })
        } else {
            UIApplication.shared.isIdleTimerDisabled = false
            self.pauseLayer(layer: self.buttonStop.layer)
            
            SVProgressHUD.show()
            
            DispatchQueue.global(qos: .default).async {
                self.procService.stopGetData {
                    ret in
                    print("*Process is stoped.")
                    
                    self.startFlg = !self.startFlg
                    self.isDoing = false
                    
                    DispatchQueue.main.async {
                        self.videoTimerLabel.stopTimer()
                        
                        self.buttonStop.isHidden = true
                        self.buttonStart.isHidden = false
                        self.buttonStop.imageView?.stopAnimating()
                        SVProgressHUD.dismiss(withDelay: 1)
                        
                        self.enableTabbarItem()
                    }
                }
            }
        }
    }
    
    func disableTabbarItem(){
        
        if  let arrayOfTabBarItems = self.tabBarController?.tabBar.items as AnyObject as? NSArray {
            for tabBarItem in arrayOfTabBarItems {
                (tabBarItem as! UITabBarItem).isEnabled = false
            }
        }
    }
    func enableTabbarItem() {
        if  let arrayOfTabBarItems = self.tabBarController?.tabBar.items as AnyObject as? NSArray {
            for tabBarItem in arrayOfTabBarItems {
                (tabBarItem as! UITabBarItem).isEnabled = true
            }
        }
    }
    
    func pauseLayer(layer: CALayer) {
        let pausedTime: CFTimeInterval = layer.convertTime(CACurrentMediaTime(), from: nil)
        layer.speed = 0.0
        layer.timeOffset = pausedTime
    }

    func resumeLayer(layer: CALayer) {
        let pausedTime: CFTimeInterval = layer.timeOffset
        layer.speed = 1.0
        layer.timeOffset = 0.0
        layer.beginTime = 0.0
        let timeSincePause: CFTimeInterval = layer.convertTime(CACurrentMediaTime(), from: nil) - pausedTime
        layer.beginTime = timeSincePause
    }
}


extension SampleViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:
            print("ユーザーはこのアプリケーションに関してまだ選択を行っていません")
            // 許可を求めるコードを記述する（後述）
            break
        case .denied:
            print("ローケーションサービスの設定が「無効」になっています (ユーザーによって、明示的に拒否されています）")
            // 「設定 > プライバシー > 位置情報サービス で、位置情報サービスの利用を許可して下さい」を表示する
            break
        case .restricted:
            print("このアプリケーションは位置情報サービスを使用できません(ユーザによって拒否されたわけではありません)")
            // 「このアプリは、位置情報を取得できないために、正常に動作できません」を表示する
            break
        case .authorizedAlways:
            print("常時、位置情報の取得が許可されています。")
            procService.initProcess()
            // 位置情報取得の開始処理
            break
        case .authorizedWhenInUse:
            print("起動時のみ、位置情報の取得が許可されています。")
            procService.initProcess()
            // 位置情報取得の開始処理
            break
        }
    }
}
