//
//  CommUtil.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/30.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import CoreLocation
import UIKit

class CommUtil {
    static let dateFormatterYMD:DateFormatter = {
        let df = DateFormatter()
        df.locale     = Locale(identifier: "ja_JP")
        df.dateFormat = "yyyy/MM/dd"
        return df
    }()
    static let dateFormatterYMDhms:DateFormatter = {
        let df = DateFormatter()
        df.locale     = Locale(identifier: "ja_JP")
        df.dateFormat = "yyyy/MM/dd HH:mm:ss"
        return df
    }()
    static let dateFormatterhmsSSS:DateFormatter = {
        let df = DateFormatter()
        df.locale     = Locale(identifier: "ja_JP")
        df.dateFormat = "H:m:ss.SSS"
        return df
    }()
    
    // 文字列 -> 日付型
    static func string2date(_ date_string: String?, format: String = "yyyy/MM/dd HH:mm:ss") -> Date? {
        if date_string == nil || date_string == "" {return nil}
        
        let date_formatter: DateFormatter?
        if format == "yyyy/MM/dd" {
            date_formatter = CommUtil.dateFormatterYMD
        } else if format == "yyyy/MM/dd HH:mm:ss" {
            date_formatter = CommUtil.dateFormatterYMDhms
        } else if format == "H:m:ss.SSS" {
            date_formatter = CommUtil.dateFormatterhmsSSS
        } else {
            date_formatter = DateFormatter()
            date_formatter!.locale = Locale(identifier: "ja_JP")
            date_formatter!.dateFormat = format
        }
        
        return date_formatter!.date(from: date_string!)
    }
    // 日付型 -> 文字列
    static func date2string(_ date: Date?, format: String = "yyyy/MM/dd HH:mm:ss") -> String? {
        if date == nil {return nil}
        
        let date_formatter: DateFormatter?
        if format == "yyyy/MM/dd" {
            date_formatter = CommUtil.dateFormatterYMD
        } else if format == "yyyy/MM/dd HH:mm:ss" {
            date_formatter = CommUtil.dateFormatterYMDhms
        } else if format == "H:m:ss.SSS" {
            date_formatter = CommUtil.dateFormatterhmsSSS
        } else {
            date_formatter = DateFormatter()
            date_formatter!.locale = Locale(identifier: "ja_JP")
            date_formatter!.dateFormat = format
        }
        
        return date_formatter!.string(from: date!)
    }
    
    // シンプルメッセージボクス
    static func createAlertWithOnlyClose(_ title: String, message: String,
                                         handler: ((UIAlertAction) -> Void)? = nil) -> UIAlertController {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Close", style: UIAlertAction.Style.default, handler: handler))
        return alert
    }
    
    static func alertSheet(title: String, message: String, sheetTitle: String, handler: ((UIAlertAction) -> Void)? = nil) -> UIAlertController {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        let websiteAction: UIAlertAction = UIAlertAction(title: sheetTitle, style: .default, handler: handler)
        let closeAction: UIAlertAction = UIAlertAction(title: NSLocalizedString("Close", comment: ""), style: .default) { action -> Void in }
        
        alert.addAction(websiteAction)
        alert.addAction(closeAction)
        
        return alert
    }

    static func getLocationDesp(loc: CLLocation, onComplete: ((String) -> Void)!) {
        var loc_desp = ""

        LocationManager.shared.locateFromCoordinates(loc.coordinate) { result in
            switch result {
              case .failure(let error):
                print("An error has occurred: \(error)")
                onComplete("")
                return
              case .success(let places):
                guard let placemark = places.first?.placemark else {
                    onComplete("")
                    return
                }
                print("Found \(placemark)")
                var addr1 = ""
                var addr2 = ""
                var addr3 = ""
                if let addrDic = placemark.addressDictionary {
                    if let state = addrDic["State"] as? String {
                        addr1 = state
                    }
                    if let city = addrDic["City"] as? String {
                        addr2 = city
                    }
                    if let street = addrDic["Street"] as? String {
                        addr3 = street
                    }
                    loc_desp = addr1 + " " + addr2 + " " + addr3
                }
                onComplete(loc_desp)
            }
        }
    }
}

extension String {
    func splitInto(_ length: Int) -> [String] {
        var str = self.replacingOccurrences(of: ",", with: "\u{255}")
        if str.count == 0 { return [String]() }
        for i in 0 ..< (str.count - 1) / max(length, 1) {
            str.insert(",", at: str.index(str.startIndex, offsetBy: (i + 1) * max(length, 1) + i))
        }
        var ret = str.components(separatedBy: ",")
        for i in 0..<ret.count {
            if ret[i] == "\u{255}" {
                ret[i] = ","
            }
        }
        return ret
    }
    
    func isAlphanumeric() -> Bool {
        return NSPredicate(format: "SELF MATCHES %@", "[a-zA-Z0-9]+").evaluate(with: self)
    }
}
