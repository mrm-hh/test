//
//  PlayListTableViewController.swift
//  VideoRecorder
//
//  Created by Natarajan Subbiah on 3/5/20.
//  Copyright © 2020 CompuSystems. All rights reserved.
//

import UIKit
import AVKit

class PlayListTableViewController: UITableViewController {

    let playList = DataService.sharedInstance.defaults.get(for: .playListKey) ?? [String]()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Play list"
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .camera, target: self, action: #selector(closePlayList))
    }
    
    @objc func closePlayList(){
        
        self.dismiss(animated: true, completion: nil)
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return playList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "playListCellIdentifier")
        
        if (cell == nil){
            
            cell = UITableViewCell(style: .default, reuseIdentifier: "playListCellIdentifier")                        
        }
        
        cell!.textLabel?.text = playList[indexPath.row]

        return cell!
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let fileName = playList[indexPath.row]
        let dirName = fileName.split(separator: ".")[0]
        
        let videoOutputURL = URL(fileURLWithPath: NSHomeDirectory() + AppConstants.DocumentDir + dirName + "/" + fileName)
        
        let avPlayerController = AVPlayerViewController()
                                
        let avAsset = AVAsset(url: videoOutputURL)
        let avPlayerItem = AVPlayerItem(asset: avAsset)
        let avPlayer = AVPlayer(playerItem: avPlayerItem)
                        
        avPlayerController.player = avPlayer
                
        self.present(avPlayerController, animated: true, completion: {
        
            avPlayer.play()
        })
    }
    
}
