import UIKit
import Foundation
enum DynamicFontSizeType {
    case fixed   //文字サイズ変動しない
    case enabled //文字サイズが条件的に変動する
    case always  //文字サイズ変動する
}
enum FontSize {
    case levelCopyright
    case level0
    case level1
    case level2
    case level3
    case level4
    case level5
    case parSmall
    case parBig
    case smsBig

    fileprivate func isDynamicEnabled() -> Bool {
        return LanguageUtility.shared.cachedLangauge() == .ja
    }
    
    fileprivate func getSize(isJapanese: Bool = true, isDynamic: DynamicFontSizeType = .fixed) -> CGFloat {
        
        var offset: CGFloat = 0

        if isDynamic == .always || (isDynamic == .enabled && isDynamicEnabled()) {
            let contentSizeStr =  DynamicFontController.shared.contentSizeStr
            if #available(iOS 10.0, *) {
                switch contentSizeStr {
                case UIContentSizeCategory.unspecified.rawValue:
                    offset = -4
                    break
                case UIContentSizeCategory.extraSmall.rawValue:
                    offset = -3
                    break
                case UIContentSizeCategory.small.rawValue:
                    offset = -2
                    break
                case UIContentSizeCategory.medium.rawValue:
                    offset = -1
                    break
                case UIContentSizeCategory.large.rawValue:
                    offset = 0
                    break
                case UIContentSizeCategory.extraLarge.rawValue:
                    offset = 1
                    break
                case UIContentSizeCategory.extraExtraLarge.rawValue:
                    offset = 2
                    break
                case UIContentSizeCategory.extraExtraExtraLarge.rawValue:
                    offset = 3
                    break
                case UIContentSizeCategory.accessibilityMedium.rawValue, UIContentSizeCategory.accessibilityLarge.rawValue, UIContentSizeCategory.accessibilityExtraLarge.rawValue, UIContentSizeCategory.accessibilityExtraExtraLarge.rawValue, UIContentSizeCategory.accessibilityExtraExtraExtraLarge.rawValue:
                    offset = 4
                    break
                default:
                    offset = 0
                    break
                }
            } else {
                switch contentSizeStr {
                case UIContentSizeCategory.extraSmall.rawValue:
                    offset = -3
                    break
                case UIContentSizeCategory.small.rawValue:
                    offset = -2
                    break
                case UIContentSizeCategory.medium.rawValue:
                    offset = -1
                    break
                case UIContentSizeCategory.large.rawValue:
                    offset = 0
                    break
                case UIContentSizeCategory.extraLarge.rawValue:
                    offset = 1
                    break
                case UIContentSizeCategory.extraExtraLarge.rawValue:
                    offset = 2
                    break
                case UIContentSizeCategory.extraExtraExtraLarge.rawValue:
                    offset = 3
                    break
                case UIContentSizeCategory.accessibilityMedium.rawValue, UIContentSizeCategory.accessibilityLarge.rawValue, UIContentSizeCategory.accessibilityExtraLarge.rawValue, UIContentSizeCategory.accessibilityExtraExtraLarge.rawValue, UIContentSizeCategory.accessibilityExtraExtraExtraLarge.rawValue:
                    offset = 4
                    break
                default:
                    offset = 0
                    break
                }
            }
        }
        
        switch self {
        case .levelCopyright:
            return 10.0
        case .level0:
            return (isJapanese ? 11.0 : 12.0) + offset
        case .level1:
            return (isJapanese ? 12.0 : 13.0) + offset
        case .level2:
            return (isJapanese ? 14.0 : 15.0) + offset
        case .level3:
            return (isJapanese ? 16.0 : 18.0) + offset
        case .level4:
            return (isJapanese ? 18.0 : 20.0) + offset
        case .level5:
            return (isJapanese ? 20.0 : 22.0) + offset
        case .parSmall:
            return (isJapanese ? 24.0 : 28.0) + offset
        case .parBig:
            return (isJapanese ? 28.0 : 32.0) + offset
        case .smsBig:
            return (isJapanese ? 34.0 : 39.0) + offset
        }
    }
}

enum FontStrong {
    case level1
    case level2
    case level3

    fileprivate func getFontType(isJapanese: Bool = true) -> FontType {
        switch self {
        case .level1:
            return isJapanese ? .hiraginoW3 : .avenirRegular
        case .level2:
            return isJapanese ? .hiraginoW5 : .avenirMedium
        case .level3:
            return isJapanese ? .hiraginoW6 : .avenirDemiBold
        }
    }
}

fileprivate enum FontType: RawRepresentable {
    typealias RawValue = String

    case hiraginoW3
    case hiraginoW5
    case hiraginoW6
    case avenirRegular
    case avenirMedium
    case avenirDemiBold

    init?(rawValue: String) {
        switch rawValue {
        case "HiraginoSans-W3":
            self = .hiraginoW3
        case "HiraginoSans-W5":
            self = .hiraginoW5
        case "HiraginoSans-W6":
            self = .hiraginoW6
        case "AvenirNext-Regular":
            self = .avenirRegular
        case "Avenir-Medium":
            self = .avenirMedium
        case "AvenirNext-DemiBold":
            self = .avenirDemiBold
        default:
            return nil
        }
    }

    var rawValue: String {
        switch self {
        case .hiraginoW3:
            return "HiraginoSans-W3"
        case .hiraginoW5:
            return "HiraginoSans-W5"
        case .hiraginoW6:
            return "HiraginoSans-W6"
        case .avenirRegular:
            return "AvenirNext-Regular"
        case .avenirMedium:
            return "AvenirNext-Medium"
        case .avenirDemiBold:
            return "AvenirNext-DemiBold"
        }
    }

    var postScryptName: String {
        return self.rawValue
    }

    var isJp: Bool {
        switch self {
        case .hiraginoW3, .hiraginoW5, .hiraginoW6:
            return true
        default:
            return false
        }
    }

    func font(with size: CGFloat) -> UIFont {
        return UIFont(name: self.rawValue, size: size)!
    }

    func font(with size: FontSize) -> UIFont {
        return UIFont(name: self.rawValue, size: size.getSize(isJapanese: isJp))!
    }
}

enum FontLanguage {
    case system
    case japanese
    case english

    var isJapanese: Bool {
        switch self {
        case .system:
            // 多言語対応する際にはSystem言語を取得して判断するようにする - 対応する前は固定
            return  LanguageUtility.shared.isLanguageAppJapanese()
        case .japanese:
            return true
        case .english:
            return false
        }
    }
}

extension UIFont {
    class func themeFont(with size: FontSize, strong: FontStrong, language: FontLanguage = .system, isDynamic: DynamicFontSizeType = .fixed) -> UIFont {
        return UIFont(name: strong.getFontType(isJapanese: language.isJapanese).postScryptName,
                      size: size.getSize(isJapanese: language.isJapanese, isDynamic: isDynamic))!
    }
}
