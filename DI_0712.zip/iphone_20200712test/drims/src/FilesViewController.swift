//
//  ViewController.swift
//  testyx
//
//  Created by scrummaster on 2020/01/27.
//  Copyright © 2020 scrummaster. All rights reserved.
//

import UIKit
import SVProgressHUD

class FilesViewController: UIViewController {
    let netService = NetService.sharedInstance
    let dataService = DataService.sharedInstance

    
    class FileInfo {
        var name: String = ""
        var path: String = ""
        var size: UInt64 = 0
        var careateDate: Date? = nil
        var gpsFile: String = ""
        var isSelected: Bool = false
        
        open func setValue(name: String, path: String, size: UInt64, careateDate: Date){
            self.name = name
            self.path = path
            self.size = size
            self.careateDate = careateDate
        }

        open func getFormatedSize() -> String {
            let tokens = ["bytes","KB","MB","GB","TB","PB","EB","ZB","YB"]

            var convertedValue = Float(self.size)
            var multiplyFactor = 0
            while (convertedValue > 1024) {
                convertedValue /= 1024
                multiplyFactor += 1
            }

            return String(format: "%4.2f %@", convertedValue, tokens[multiplyFactor])
        }
        
        open func getFormatedCreateDate() -> String {
            if careateDate == nil {
                return ""
            }
            let df = DateFormatter()
            df.locale = Locale(identifier: "ja_JP")
            df.dateFormat = "yyyy/MM/dd HH:mm:ss"
            return df.string(from: careateDate!)
        }
    }
    
    var fileURLs:[URL]? = nil
    var fileInfos:[FileInfo] = []
    var gpsInfos:[String] = []
    var showGPSFilePath = ""
    
    private var filesTableView = UITableView(frame: .zero, style: .plain)
    
    @IBAction func barBtnItemDelAction(_ sender: Any) {
        deleteAction()
    }
    
    @IBAction func barBtnItemUploadAction(_ sender: Any) {
        uploadAction()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
//        SVProgressHUD.show()
        loadData()
//        DispatchQueue.main.async {
//            SVProgressHUD.dismiss(withDelay: 1)
//        }
        filesTableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.title = NSLocalizedString("File", comment: "")
        self.navigationItem.leftBarButtonItem?.tintColor = .gray
        self.navigationItem.rightBarButtonItem?.tintColor = .gray
        
        view.addSubview(filesTableView)
        
        filesTableView.tableHeaderView = UIView(frame: CGRect(x: 0.0,
                                                         y: 0.0,
                                                         width: UIScreen.main.bounds.width,
                                                         height: .leastNonzeroMagnitude))
        filesTableView.separatorInset = .zero
        filesTableView.dataSource = self
        filesTableView.delegate = self
        filesTableView.register(FileTableviewCell.self, forCellReuseIdentifier: "Default")
        filesTableView.showsVerticalScrollIndicator = false
        filesTableView.reloadData()

        filesTableView.layouts([
            "H:|-10-[self]-10-|": .directionLeadingToTrailing,
            "V:|-10-[self]-\(self.navigationController!.tabBarController!.tabBar.frame.size.height)-|": .directionLeadingToTrailing,
        ])
    }
    
    fileprivate func loadData() {
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            var fileURLDict: [String:URL] = [:]
            self.fileInfos = []
            self.gpsInfos = []
            self.fileURLs = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)
            
            for i in 0..<self.fileURLs!.count {
                let fileUrl = self.fileURLs![i]
                var zipFileName = ""
                
                do {
                    let fileURLs = try fileManager.contentsOfDirectory(at: fileUrl, includingPropertiesForKeys: nil)
                    for filePath:URL in fileURLs {
                        if filePath.absoluteString.contains(".zip") {
                            zipFileName = filePath.lastPathComponent
                            let attr = try FileManager.default.attributesOfItem(atPath: filePath.path)
                            
                            let fileSize = attr[FileAttributeKey.size] as! UInt64
                            let createDate = attr[FileAttributeKey.creationDate] as! Date
                            
                            let fileInfo = FileInfo()
                            fileInfo.setValue(
                                name: zipFileName,
                                path: zipFileName.replacingOccurrences(of: ".zip", with: ""),
                                size: fileSize,
                                careateDate: createDate)
                            
                            fileInfos.append(fileInfo)
                            fileURLDict[fileInfo.name] = filePath
                        }
                        if filePath.absoluteString.contains("_gps.dat") {
                            let data = try String(contentsOf: filePath, encoding: .utf8)
                            if !data.isEmpty {
                                let csvLines = data.components(separatedBy: .newlines)
                                if csvLines.count > 3 {
                                    gpsInfos.append(filePath.lastPathComponent);
                                }
                            }
                        }
                    }
                } catch {
                    print("create file list error:\(error)")
                }
            }
            
            for gpsfile:String in gpsInfos {
                let zipFileName = gpsfile.replacingOccurrences(of: "_gps.dat", with: ".zip")

                for oneFile in fileInfos {
                    if zipFileName == oneFile.name {
                        oneFile.gpsFile = gpsfile
                        break;
                    }
                }
            }
            
            self.fileInfos = self.fileInfos.sorted(by: { (a, b) -> Bool in
                return a.careateDate! > b.careateDate!
            })
            self.fileURLs = []
            for i in 0..<self.fileInfos.count {
                let fileInfo = self.fileInfos[i]
                self.fileURLs!.append(fileURLDict[fileInfo.name]!)
            }
        } catch {
            print("Error while enumerating files \(documentsURL.path): \(error.localizedDescription)")
        }
    }
    
    @objc func deleteAction() {
        var objs: [FileInfo] = []
        var playList: [String] = []
        let oldPlayList = dataService.defaults.get(for: .playListKey) ?? [String]()
        for obj in fileInfos {
            if obj.isSelected {
                objs.append(obj)
            } else {
                let fnm = obj.name.replacingOccurrences(of: ".zip", with: ".mp4")
                if oldPlayList.contains(fnm) {
                    playList.append(fnm)
                }
            }
        }
        
        if objs.count > 0 {
            
            func deletefile() {
                let fileManager = FileManager.default
                let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
                
                for delObj in objs {
                    do {
                        try FileManager.default.removeItem(at: URL(fileURLWithPath: delObj.name.replacingOccurrences(of: ".zip", with: ""), relativeTo: documentsURL))
                    } catch let e{
                        print(e)
                    }
                }
                dataService.defaults.set(playList, for: .playListKey)
                loadData()
                filesTableView.reloadData()
            }
            
            let alert = UIAlertController(
                title: NSLocalizedString("Warning", comment: ""),
                message: NSLocalizedString("befor_delete_file", comment: ""),
                preferredStyle: UIAlertController.Style.alert)
            
            
            alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: {
                action in
            
                return;
            }))
            alert.addAction(UIAlertAction(title: NSLocalizedString("Delete", comment: ""), style: .destructive, handler: {
                action in
            
                deletefile();
            }))
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    
    @objc func uploadAction() {
        if fileURLs == nil {
            return
        }
        
        var uploadObjs: FileInfo?
        for obj in fileInfos {
            if obj.isSelected {
                uploadObjs = obj
            }
        }
        
        if uploadObjs == nil {
//            let alert = CommUtil.createAlertWithOnlyClose(
//            NSLocalizedString("Error", comment: ""),
//            message: NSLocalizedString("msg_no_file", comment: ""))
//            self.present(alert, animated: true, completion: nil)
            return
        }
        
        let user = dataService.setting.userId
        let password = dataService.setting.userPass
        
        if user == "" || password == "" {
            let alert = CommUtil.createAlertWithOnlyClose(
            NSLocalizedString("Error", comment: ""),
            message: NSLocalizedString("msg_not_input", comment: ""))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        var sendURLs:[URL] = []
        var fnames:[String] = []
        
        for i in 0..<fileInfos.count {
            let model = fileInfos[i]
            if model.isSelected {
                sendURLs.append(fileURLs![i])
                fnames.append(fileInfos[i].name)
            }
        }

        if sendURLs.count > 0 {
            SVProgressHUD.show()
            netService.uploadDrimsFile(fileUrls: sendURLs, fileNames: fnames, completion: {
                [weak self] result in
                
                if result != "" {
                    DispatchQueue.main.async() {
                        let alert = CommUtil.alertSheet(title: NSLocalizedString("Success", comment: ""), message: "如需查看数据，请点击\"Websiteへ\"ボタン", sheetTitle: "Websiteへ", handler: { result in
                            
                            if let url = URL(string: "https://www.smc-road.com/vehicles"),
                                        UIApplication.shared.canOpenURL(url) {
                                UIApplication.shared.open(url, options: [:], completionHandler: {result in
                                    print("website opened")
                                })
                            }
                        })
                        
                        for i in 0..<self!.fileInfos.count {
                            let model = self!.fileInfos[i]
                            model.isSelected = false
                        }
                        
                        SVProgressHUD.dismiss(withDelay: 1, completion: {
                            self!.present(alert, animated: true, completion: nil)
                            self!.filesTableView.reloadData()
                        })
                    }
                }
                else {
                    DispatchQueue.main.async() {
                        let alert = CommUtil.createAlertWithOnlyClose(
                        NSLocalizedString("Error", comment: ""),
                        message: NSLocalizedString("msg_upload_failed", comment: ""))
                        
                        SVProgressHUD.dismiss(withDelay: 1, completion: {
                            self!.present(alert, animated: true, completion: nil)
                        })
                    }
                }
            })
        }
    }
}

extension FilesViewController:  FileTableviewCellDelegate {
    func checkBoxStatusChanged(status: Bool, row: Int) {
        let model = fileInfos[row]
        model.isSelected = status
        
        refreshUI()
    }
    
    func refreshUI() {
        var objs: [FileInfo] = []
        for obj in fileInfos {
            if obj.isSelected {
                objs.append(obj)
            }
        }
        
        if objs.count > 0 {
            self.navigationItem.leftBarButtonItem?.tintColor = .white
            self.navigationItem.rightBarButtonItem?.tintColor = .white
        } else {
            self.navigationItem.leftBarButtonItem?.tintColor = .gray
            self.navigationItem.rightBarButtonItem?.tintColor = .gray
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showGPS" {
            if let destinationVC = segue.destination as? RouteMapViewController {
                destinationVC.gpsFilePath = showGPSFilePath
            }
        }
    }
}


extension FilesViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection rows: Int) -> Int {
        return fileInfos.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Default", for: indexPath) as! FileTableviewCell
        cell.delegate = self
        cell.setup(
        name: (fileInfos[indexPath.row].name),
        size: (fileInfos[indexPath.row].getFormatedSize()),
        careateDate: (fileInfos[indexPath.row].getFormatedCreateDate()),
        gpsFilePath: fileInfos[indexPath.row].gpsFile.isEmpty ? "" : fileInfos[indexPath.row].path + "/" + fileInfos[indexPath.row].gpsFile,
        checkBoxStatus: fileInfos[indexPath.row].isSelected,
        row: indexPath.row)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = fileInfos[indexPath.row]
        
        if model.gpsFile != "" {
            showGPSFilePath = model.path + "/" +  model.gpsFile
            self.performSegue(withIdentifier: "showGPS", sender: false)
        }
    }
}
