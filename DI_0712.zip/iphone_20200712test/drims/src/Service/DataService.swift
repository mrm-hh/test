//
//  DataService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import Zip

open class DataService: NSObject{
    // SINGLETON
    public static let sharedInstance : DataService = DataService()
    
    let defaults: Defaults  = Defaults()
  
    var setting: Setting
    var carDataNames: [String]
    
    var isRecording = false
    var saveTime: Date? = nil
  
    var deviceID: String = ""
    var appVersion: String = ""
    var installTime: String = ""
    var drimsId: String = ""
  
    private var fileAcc:FileHandle? = nil
    private let headerAccText = "localTimeStamp , x, y, z"
    private var recordAccText = "init"
    private var fileAngVel:FileHandle? = nil
    private let headerAngVelText = "localTimeStamp , x, y, z"
    private var recordAngVelText = "init"
    private var fileGPS:FileHandle? = nil
    private let headerGpsText = "localTimeStamp , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course"
    private let headerGpsDistancText = "No , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course"
    private var recordGpsText = "init"
  
    override init() {
        let hasDatas = defaults.has(.carDatasKey)
        if hasDatas {
            carDataNames = defaults.get(for: .carDatasKey)!
            print("Car data list is getted.")
        } else {
            carDataNames = []
        }
        let hasSetting = defaults.has(.settingKey)
        if hasSetting {
            setting = defaults.get(for: .settingKey)!
        } else {
            setting = Setting(devId: "", wheelbase: 0, sensorPosition: 0, userId: "", userPass: "")
        }
        super.init()
        
    }
  
    func saveSetting() {
        defaults.set(setting, for: .settingKey)
    }
    
    func saveSysInfo() {
        defaults.set(appVersion, for: .appVersion)
        defaults.set(deviceID, for: .deviceID)
        defaults.set(drimsId, for: .drimsId)
        defaults.set(installTime, for: .installTime)
    }
    
    func loadData() {
//        deviceID = "2BEA0B88-1DE9-4D96-B25E-FBF702C8957B"
        var flg = defaults.has(.deviceID)
        if flg {
            deviceID = defaults.get(for: .deviceID)!
        }
        
//        appVersion = "1.0"
        flg = defaults.has(.appVersion)
        if flg {
            appVersion = defaults.get(for: .appVersion)!
        }
        
//        installTime = "2020/02/06 00:20:30"
        flg = defaults.has(.installTime)
        if flg {
            installTime = defaults.get(for: .installTime)!
        }
//        drimsId = "xLoKOnZjtN9RmqcpQIPukE05SU8xRQxPsFkDTz1m1lsYZyVMTBHgLrf0Ya90NbKW"
        flg = defaults.has(.drimsId)
        if flg {
            drimsId = defaults.get(for: .drimsId)!
        }
    }
    func startRecording() {
        recordAccText = ""
        recordAccText += headerAccText + "\n"
        recordAngVelText = ""
        recordAngVelText += headerAngVelText + "\n"
        recordGpsText = ""
        recordGpsText += headerGpsText + "\n"
        isRecording = true
        saveTime = Date()
    }
    
    func stopRecording() {
        isRecording = false
      
        // ファイルを閉じる
        if fileAcc != nil {
            fileAcc!.closeFile()
            fileAcc = nil
        }
        if fileAngVel != nil {
            fileAngVel!.closeFile()
            fileAngVel = nil
        }
        if fileGPS != nil {
            fileGPS!.closeFile()
            fileGPS = nil
        }
    }
    
    func addRecordAccText(addText:String) {
        recordAccText += addText + "\n"
//        print("加速度：" + addText)
    }
  
    func addRecordAngVelText(addText:String) {
        recordAngVelText += addText + "\n"
//        print("角速度：" + addText)
    }
    
    func addRecordGpsText(addText:String) {
        recordGpsText += addText + "\n"
//        print("GPS：" + addText)
    }
    
    func createTestItemDir(saveTime: Date) {
        let targetPathName = getSaveTargetPathName(saveTime: saveTime)

        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let targetPath = documentsURL.appendingPathComponent(targetPathName, isDirectory: true)
        do {
            try fileManager.createDirectory(at: targetPath, withIntermediateDirectories: true, attributes: nil)
        } catch let e {
            print(e)
        }
    }
    
    func initWorkDir(createDirFlg: Bool = true) {
        let fmanager = FileManager.default
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir
        do {
            if isDirectory(filePath) {
                try fmanager.removeItem(atPath: filePath)
            }
            if createDirFlg {
                try fmanager.createDirectory(at: URL(fileURLWithPath: filePath), withIntermediateDirectories: true, attributes: nil)
            }
        } catch let e {
            print(e)
        }
    }
    
    func initImgDir(createDirFlg: Bool = true) {
        let fmanager = FileManager.default
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.ImgDir
        do {
            if isDirectory(filePath) {
                try fmanager.removeItem(atPath: filePath)
            }
            if createDirFlg {
                try fmanager.createDirectory(at: URL(fileURLWithPath: filePath), withIntermediateDirectories: true, attributes: nil)
            }
        } catch let e {
            print(e)
        }
    }
    
    func isDirectory(_ dirName: String) -> Bool {
        let fileManager = FileManager.default
        var isDir: ObjCBool = false
        if fileManager.fileExists(atPath: dirName, isDirectory: &isDir) {
            if isDir.boolValue {
                return true
            }
        }
        return false
    }
    
    // 各ファイル保存メソッド
    func saveAccCsv() {
        if !isRecording {
            return
        }
        if fileAcc == nil {
            let recordTitle = "SamplingNumber, 998, SamplingFrequency(Hz), 100, CarID, "
                            + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
            let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
                // + "_" + self.getTimeZoneID() /// TODO:timezone
            let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_acc.dat"
            do {
                try "".write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
                fileAcc = FileHandle(forWritingAtPath: filePath)!
                
            } catch let error as NSError {
                print("Failure to Write Acceleration CSV\n\(error)")
            }
            recordAccText = recordTitle + recordAccText
        }
        let buff = recordAccText
        recordAccText = ""
        do {
          // String->Dataに変換
          let contentData = buff.data(using: .utf8)!
          // 一番うしろにシーク
          fileAcc!.seekToEndOfFile()
          // Dataを書き込み
          fileAcc!.write(contentData)
          
//            try recordAccText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
//            print("Success to Write Acceleration CSV")
        } catch let error as NSError {
            print("Failure to Write Acceleration CSV\n\(error)")
        }
    }
  
    func saveAngVelCsv() {
        if !isRecording {
            return
        }
        if fileAngVel == nil {
            let recordTitle = "SamplingNumber, 998, SamplingFrequency(Hz), 100, CarID, "
                            + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
            let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
                // + "_" + self.getTimeZoneID() /// TODO:timezone
            let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_ang_vel.dat"
          
            do {
                try "".write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
                fileAngVel = FileHandle(forWritingAtPath: filePath)!
            } catch let error as NSError {
                print("Failure to Write Ang & Vel CSV\n\(error)")
            }
            recordAngVelText = recordTitle + recordAngVelText
        }
        let buff = recordAngVelText
        recordAngVelText = ""
        do{
            // String->Dataに変換
            let contentData = buff.data(using: .utf8)!
            // 一番うしろにシーク
            fileAngVel!.seekToEndOfFile()
            // Dataを書き込み
            fileAngVel!.write(contentData)
        }catch let error as NSError{
            print("Failure to Write Ang & Vel CSV\n\(error)")
        }
    }
  
    func saveGpsCsv() {
        if !isRecording {
            return
        }
        if fileGPS == nil {
            let recordTitle = "CarID, " + setting.devId + ", MeasurementDate, " + CommUtil.date2string(saveTime)! + "\n"
            let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
                // + "_" + self.getTimeZoneID() /// TODO:timezone
            let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_gps.dat"
          
            do {
                try "".write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
                fileGPS = FileHandle(forWritingAtPath: filePath)!
            } catch let error as NSError {
                print("Failure to Write GPS CSV\n\(error)")
            }
            recordGpsText = recordTitle + recordGpsText
        }
        let buff = recordGpsText
        recordGpsText = ""
        do{
            // String->Dataに変換
            let contentData = buff.data(using: .utf8)!
            // 一番うしろにシーク
            fileGPS!.seekToEndOfFile()
            // Dataを書き込み
            fileGPS!.write(contentData)
        }catch let error as NSError{
            print("Failure to Write GPS CSV\n\(error)")
        }
    }
  
    func saveCarCsv()-> String {
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        //+ "_" + self.getTimeZoneID() /// TODO:timezone
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_carinfo.txt"
        var recordCarinfoText = "id, " + setting.devId + "\n"
        recordCarinfoText += "number plate, " + "\n"
        recordCarinfoText += "car model, " + "\n"
        recordCarinfoText += "car no, " + "\n"
        recordCarinfoText += "weight, " + "\n"
        recordCarinfoText += "wheelbase, " + String(setting.wheelbase) + "\n"
        recordCarinfoText += "axle track, " + "\n"
        recordCarinfoText += "angle x, " + "\n"
        recordCarinfoText += "angle y, " + "\n"
        recordCarinfoText += "direction, None" + "\n"
        recordCarinfoText += "directionV, None" + "\n"
        recordCarinfoText += "sensor position, " + String(setting.sensorPosition) + "\n"
        recordCarinfoText += "comment1, " + "\n"
        recordCarinfoText += "comment2, " + "\n"
        recordCarinfoText += "comment3, " + "\n"

        do{
            try recordCarinfoText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write CarInfo CSV")
        }catch let error as NSError{
            print("Failure to Write CarInfo CSV\n\(error)")
        }
        return filePath
    }
  
    func saveMeasurementCsv()-> String {
        let fileName = setting.devId + "_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
        // + "_" + self.getTimeZoneID() /// TODO:timezone
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir + fileName + "_measurement.txt"
        var recordMeasurementText = "device id," + deviceID + "\n"
        recordMeasurementText += "app version," + appVersion + "\n"
        recordMeasurementText += "app install time," + installTime + "\n"
//        recordMeasurementText += "idrims id," + drimsId + "\n"
        recordMeasurementText += "timezone," + self.getTimeZone() + "\n"
        recordMeasurementText += "start time," + CommUtil.date2string(Date(), format: "yyyy/MM/dd HH:mm:ss")! + "\n"
        do{
            try recordMeasurementText.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
            print("Success to Write Measurement CSV")
        }catch let error as NSError{
            print("Failure to Write Measurement CSV\n\(error)")
        }
        return filePath
    }
    
    func getFileCreatedDate(atPath: String) -> Date {

        var theCreationDate = Date()
        do {
            let aFileAttributes = try FileManager.default.attributesOfItem(atPath: atPath) as [FileAttributeKey:Any]
            theCreationDate = aFileAttributes[FileAttributeKey.creationDate] as! Date

        } catch let theError as NSError {
            print("file not found \(theError)")
        }
        return theCreationDate
    }
    
    func getZipFileName() -> String {
        if self.saveTime == nil {
            return ""
        }
        let fileName = setting.devId + "_data_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")!
//        let filePathName = NSHomeDirectory() + AppConstants.DocumentDir + fileName + ".zip"
//        return filePathName
        return fileName
    }
    
    // fileKbn(0:*_gps.datと同じ、1:指定距離ごとにデータ出力(処理用)、2:指定距離ごとにデータ出力(送信用))
    func getGpsFileURL(fileKbn: Int) -> URL{
        var fileName = getZipFileName()
        var newFileName = fileName
        var path = ""
        if fileKbn == 2 {
            newFileName += "_gps.dat"
            path = NSHomeDirectory() + AppConstants.TempDir + AppConstants.ImgDir
        } else {
            if fileKbn == 0 {
                newFileName += "_gps.json"
            } else {
                newFileName += "_gpsd.json"
            }
            
            path = NSHomeDirectory() + AppConstants.DocumentDir + fileName + "/"
        }
        // Documents下にデータフォルダを作成する
        if !isDirectory(path) {
            do {
                let fileManager = FileManager.default
                try fileManager.createDirectory(at: URL(fileURLWithPath: path, isDirectory: true), withIntermediateDirectories: true, attributes: nil)
            } catch let e {
                print(e)
            }
        }

        return URL(fileURLWithPath: path + newFileName)
    }
    
    func outputGPSInfo(datas: [GpsData]){
        // 地図、写真用GPS情報ファイル出力
        var jsonData: JSON = JSON([])
        for i in 0..<datas.count {
            let gjson = datas[i].toJSON()
            jsonData.array!.append(gjson)
        }
        do {
            if jsonData.error == nil {
                let url = getGpsFileURL(fileKbn: 0)
                try jsonData.description.write(to: url, atomically: false, encoding: .utf8)
            }
        } catch {
            print("gpsファイル(一般)出力失敗：\(error)")
        }
        
        // -------------------------------------------------------
        // 指定距離毎にGPS情報出力
        var newDatas:[GpsData] = []
//        var gpsDistances: [GpsData] = []
        var timeinterval: TimeInterval = 0.0
        var prevGD: GpsData?
        // 指定距離毎計算用
        var calcDistance: Double = 0.0
        var calcInterval: TimeInterval = 0.0
        let startTime: Date = saveTime!
        print("gpsファイル(指定距離)出力開始：" + CommUtil.date2string(startTime)!)
        
//        // Test Code ----------------------
//        var timeIvl: TimeInterval = 1.0
//        while (timeIvl < TimeInterval(5.0)) {
//            let fileTime = Date(timeInterval: timeIvl, since: startTime)
//            let newData = GpsData(lat: "135.25", lng: "131.53", timestamp: fileTime)
//            newDatas.append(newData)
//            timeIvl += (ceil((1.0/30.0) * 1000) / 1000)
//        }
//        // --------------------------------
        
        for i in 0..<datas.count {
            let gpsData = datas[i]
            let nowTime: Date = gpsData.timestamp!

            // 1件目を処理しない
            if i == 0 {
                continue
            }
//            let gpsData = GpsData(lat: v["lat"].string!, lng: v["lng"].string!, timestamp: nowTime)
            if prevGD != nil {
                // get interval
                let prevTime = prevGD!.timestamp
                // 前回情報との経過時間
                let ti = nowTime.timeIntervalSince(prevTime!)
                // 前回情報との経過距離 (meter)
                let distance = gpsData.distanceTo(other: prevGD!)

                if (calcDistance + distance) < AppConstants.DistanceForCapture {
                    calcDistance += distance
                    calcInterval += ti
                } else {
                    // 指定距離に残り距離
                    var interMeters = AppConstants.DistanceForCapture - calcDistance
//                    if AppConstants.DistanceForCapture > distance {
                    var radio = Double(interMeters) / Double(distance)
                        // 指定距離に残り時間間隔
                    var interTime = round(radio * ti * 1000) / 1000

                    // Data output
                    calcInterval += interTime
                    // startTime からの時間間隔
                    timeinterval += calcInterval
                    var fileTime = Date(timeInterval: timeinterval, since: startTime)
                    var newData = GpsData(lat: gpsData.lat, lng: gpsData.lng, timestamp: fileTime)
                    newData.altitude = gpsData.altitude
                    newData.horizontalAccuracy = gpsData.horizontalAccuracy
                    newData.verticalAccuracy = gpsData.verticalAccuracy
                    newData.speed = gpsData.speed
                    newData.course = gpsData.course

                    newDatas.append(newData)

//                    } else {
//                        interMeters = -1 * interMeters
//                        let radio = AppConstants.DistanceForCapture * 1.0 / distance * 1.0
//                        let interTime = round(radio * distance * 1000 / 1000)
//
//                        // Data output
//                        calcInterval += interTime
//                        // startTime からの時間間隔
//                        timeinterval += calcInterval
//                        let fileTime = Date(timeInterval: timeinterval, since: startTime)
//                        let newData = GpsData(lat: prevGD!.lat, lng: prevGD!.lng, timestamp: fileTime)
//                        newDatas.append(newData)
//                    }
                    repeat {
                        calcDistance = distance - interMeters
                        if calcDistance >= AppConstants.DistanceForCapture {
                            calcDistance = AppConstants.DistanceForCapture
                            radio = Double(AppConstants.DistanceForCapture) / Double(distance)
                            calcInterval = round(radio * ti * 1000) / 1000

                            interTime += calcInterval
                            timeinterval += calcInterval
                            fileTime = Date(timeInterval: timeinterval, since: startTime)
                            newData = GpsData(lat: gpsData.lat, lng: gpsData.lng, timestamp: fileTime)
                            newData.altitude = gpsData.altitude
                            newData.horizontalAccuracy = gpsData.horizontalAccuracy
                            newData.verticalAccuracy = gpsData.verticalAccuracy
                            newData.speed = gpsData.speed
                            newData.course = gpsData.course

                            newDatas.append(newData)
                            interMeters += AppConstants.DistanceForCapture
                        } else {
                            // 残りの時間算出
                            calcInterval = ti - interTime
                        }
                    } while (calcDistance == AppConstants.DistanceForCapture)

                }

            } else {
                timeinterval = nowTime.timeIntervalSince(startTime)
            }

            prevGD = gpsData
        }
        // 全体の累積でも指定距離を超えない場合
        if newDatas.count == 0 && datas.count > 1 {
            timeinterval += calcInterval
            let dataTimestamp = Date(timeInterval: timeinterval, since: startTime)
            // 距離指定毎のレコード生成
            prevGD = datas[datas.count - 1]
            let gpsDistance = GpsData(lat: prevGD!.lat, lng: prevGD!.lng, timestamp: dataTimestamp)
//            gpsDistance.distance = Int(calcInterval)
            gpsDistance.altitude = prevGD!.altitude
            gpsDistance.horizontalAccuracy = prevGD!.horizontalAccuracy
            gpsDistance.verticalAccuracy = prevGD!.verticalAccuracy
            gpsDistance.speed = prevGD!.speed
            gpsDistance.course = prevGD!.course
            
            newDatas.append(gpsDistance)
        }
        
        jsonData = JSON([])
        for i in 0..<newDatas.count {
            let gjson = newDatas[i].toJSON()
            jsonData.array!.append(gjson)
        }
        do {
            if jsonData.error == nil {
                let url = getGpsFileURL(fileKbn: 1)
                try jsonData.description.write(to: url, atomically: false, encoding: .utf8)
            }
            let url = getGpsFileURL(fileKbn: 2)
            outputGPSDisatanceFile(url: url, datas: newDatas, startTime: saveTime!)
        } catch {
            print("gpsファイル(指定距離)出力失敗：\(error)")
        }
    }
    
    func outputGPSDisatanceFile(url: URL, datas: [GpsData], startTime: Date) {
        var recordTitle = "SamplingNumber, " + String(datas.count) + ", SamplingFrequency(m), " + String(AppConstants.DistanceForCapture)
                        + ", CarID," + setting.devId + ", MeasurementDate, " + CommUtil.date2string(startTime, format: "yyyy/MM/dd HH:mm:ss")! + "\n"
                        + "No , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course\n"
        var recordText = ""
        for i in 0..<datas.count {
            let data = datas[i]
            recordText += (String(i + 1) + "," + data.toCSVLine() + "\n")
        }
        do {
            try (recordTitle + recordText).write(to: url, atomically: false, encoding: .utf8)
        } catch let error as NSError {
            print("Failure to Write GPS CSV\n\(error)")
        }
    }
    
    func getSaveTargetPathName(saveTime:Date) -> String {
        let fileName = setting.devId + "_data_" + CommUtil.date2string(saveTime, format: "yyyyMMdd_HHmmss")! // + "_" + self.getTimeZoneID() /// TODO:timezone
//        let filePathName = NSHomeDirectory() + AppConstants.DocumentDir + fileName + ".zip"
//        return filePathName
        return fileName
    }
    
    func makeZipFile() {
        let targetPathName = getSaveTargetPathName(saveTime: saveTime!)
        let workPath = URL(fileURLWithPath: NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir, isDirectory: true)
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let targetPath = documentsURL.appendingPathComponent(targetPathName, isDirectory: true)
        do {
            try fileManager.createDirectory(at: targetPath, withIntermediateDirectories: true, attributes: nil)
        } catch let e {
            print(e)
        }
        
        do {
            let _ = try Zip.quickZipFiles([workPath], fileName: targetPathName + "/" + targetPathName)
            var gpsSourceFilePath:URL? = nil
            do {
                let fileURLs = try fileManager.contentsOfDirectory(at: workPath, includingPropertiesForKeys: nil)
                for filePath:URL in fileURLs {
                    if filePath.absoluteString.contains("_gps.dat") {
                        gpsSourceFilePath = filePath
                    }
                }
            } catch {
                print("Error while enumerating files \(workPath): \(error.localizedDescription)")
            }
            
            if gpsSourceFilePath != nil {
                let gpsTargetFilePath = URL(fileURLWithPath:targetPathName + "_gps.dat", relativeTo: targetPath)
                try fileManager.moveItem(at: gpsSourceFilePath!, to: gpsTargetFilePath)
            }
            
            initWorkDir(createDirFlg: false)
        } catch let e {
            print(e)
        }
    }
    
    func makeZipFileWhenVideo() {
        let targetPathName = getSaveTargetPathName(saveTime: saveTime!)
        let workPath = URL(fileURLWithPath: NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir, isDirectory: true)
        let imagePath = URL(fileURLWithPath: NSHomeDirectory() + AppConstants.TempDir + AppConstants.ImgDir, isDirectory: true)
        
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let targetPath = documentsURL.appendingPathComponent(targetPathName, isDirectory: true)
        do {
            try fileManager.createDirectory(at: targetPath, withIntermediateDirectories: true, attributes: nil)
        } catch let e {
            print(e)
        }
        
        do {
            let _ = try Zip.quickZipFiles([workPath, imagePath], fileName: targetPathName + "/" + targetPathName)
            var gpsSourceFilePath:URL? = nil
            do {
                let fileURLs = try fileManager.contentsOfDirectory(at: workPath, includingPropertiesForKeys: nil)
                for filePath:URL in fileURLs {
                    if filePath.absoluteString.contains("_gps.dat") {
                        gpsSourceFilePath = filePath
                    }
                }
            } catch {
                print("Error while enumerating files \(workPath): \(error.localizedDescription)")
            }
            
            if gpsSourceFilePath != nil {
                let gpsTargetFilePath = URL(fileURLWithPath:targetPathName + "_gps.dat", relativeTo: targetPath)
                try fileManager.moveItem(at: gpsSourceFilePath!, to: gpsTargetFilePath)
            }
            
            initWorkDir(createDirFlg: false)
            initImgDir(createDirFlg: false)
        } catch let e {
            print(e)
        }
    }
    
    func getTimeZone() -> String {
        let zone = NSTimeZone.system
    
        let interval = zone.secondsFromGMT()
        let hourDiff = interval/3600
        
        var ret: String = ""
        if hourDiff >= 0 {
            ret = "UTC+\(hourDiff)"
        } else {
            ret = "UTC\(hourDiff)"
        }

        return ret
    }

    func getTimeZoneID() -> String {
        var timeZoneID = TimeZone.current.identifier
        
        timeZoneID = timeZoneID.replacingOccurrences(of: "/", with: "_")
        
        return timeZoneID
    }
}

extension DefaultsKey {
    static let settingKey = Key<Setting>("settingKey")
    static let carDatasKey = Key<[String]>("carDatasKey")
    static let playListKey = Key<[String]>("playListKey")
    
    static let deviceID = Key<String>("deviceID")
    static let appVersion = Key<String>("appVersion")
    static let installTime = Key<String>("installTime")
    static let drimsId = Key<String>("drimsId")
    
}
