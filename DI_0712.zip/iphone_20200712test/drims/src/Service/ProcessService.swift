//
//  ProcessService.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation
import CoreLocation
import CoreMotion
import UIKit
import AVFoundation
import AVKit

open class ProcessService: NSObject {
    // SINGLETON
    public static let sharedInstance : ProcessService = ProcessService()
    
    let dataService = DataService.sharedInstance
    
    let motionManager = CMMotionManager()
    var attitude = SIMD3<Double>.zero
    var gyro = SIMD3<Double>.zero
    var gravity = SIMD3<Double>.zero
    var acc = SIMD3<Double>.zero
    // 現在位置情報
    var curtLocation: CLLocation?
    var curtLocationDesp: String?
    var req: LocationRequest? = nil
    // DeviceMotionの起動時間
    var motionStartTime: Date? = nil
    // 記録済み数
    var motionCnt = 0
    
    // データ採集タイマー
    var getDataTimer: Timer?
    // アプリ起動フラグ
    var appStartupFlg = false
    // GPS track情報
    var gpsDatas: [GpsData] = []
    
    // 非同期処理制御
    var queue:DispatchQueue? = nil
    var group:DispatchGroup? = nil
    
    // 初期処理
    func initProcess() {
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir
        if self.dataService.isDirectory(filePath) {
            self.dataService.saveTime = self.dataService.getFileCreatedDate(atPath: filePath)
            self.dataService.makeZipFile()
        }
        
        dataService.loadData()
        
        // アプリの初期化へ移動
//        if dataService.drimsId == "" {
//            print("初期起動")
//            dataService.drimsId = NSUUID().uuidString
//            dataService.installTime = CommUtil.date2string(Date())!
//            dataService.appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
//            dataService.deviceID = NSUUID().uuidString
//
//            dataService.saveSysInfo()
//        }
        curtLocation = nil
        // GPS情報取得確認
        req = LocationManager.shared.locateFromGPS(.oneShot, accuracy: .block,
//                                                   accuracy: .custom(kCLLocationAccuracyNearestTenMeters),
                                                   distance: CLLocationDistance("-1"),
        activity:.otherNavigation ) { result in
          switch result {
            case .failure(let error):
              debugPrint("Received error: \(error)")
            case .success(let location):
              self.curtLocation = location
              CommUtil.getLocationDesp(loc: self.curtLocation!, onComplete: {desp in
                  self.curtLocationDesp = desp
              })
              debugPrint("Location received: \(location)")
              self.startGPSData()
          }
        }
        
        startSensorUpdates(intervalSeconds: 0.01) // 100Hz
        self.appStartupFlg = true
    }
    
    func checkSetting(callback: @escaping ()->Void) -> UIAlertController? {
        if dataService.setting.devId == "" {
            let alert = CommUtil.createAlertWithOnlyClose(NSLocalizedString("Warning", comment: ""), message: NSLocalizedString("msg_not_setting", comment: ""), handler: {
                    action in
                
                    callback()
                })
            return alert
        }
        return nil
    }
    
    func confirmParameter(handler: ((UIAlertAction) -> Void)?) -> UIAlertController? {
        let message: String = String(format: "%@\n%@: %@\n%@: %3d\n%@: %3d\n\n%@",
            NSLocalizedString("msg_confirm_parameter", comment: ""),
            NSLocalizedString("device_id", comment: ""),
            DataService.sharedInstance.setting.devId,
            NSLocalizedString("wheel_base", comment: ""),
            DataService.sharedInstance.setting.wheelbase,
            NSLocalizedString("sensor_position", comment: ""),
            DataService.sharedInstance.setting.sensorPosition,
            NSLocalizedString("msg_confirm_parameter2", comment: ""))
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .left
        let messageText = NSAttributedString(
            string: message,
            attributes: [
                NSAttributedString.Key.paragraphStyle: paragraphStyle,
            ]
        )

        let alert = UIAlertController(title: NSLocalizedString("Warning", comment: ""), message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: UIAlertAction.Style.cancel, handler: nil))
        alert.addAction(UIAlertAction(title: NSLocalizedString("Start", comment: ""), style: UIAlertAction.Style.default, handler: handler))
        alert.setValue(messageText, forKey: "attributedMessage")
        
        return alert
    }
    
    func setLocation(data: CLLocation) {
        if !dataService.isRecording {
            return
        }

        let loc = data
        // localTimeStamp , GPStimeStamp, latitude, longitude, altitude, horizontalAccuracy , verticalAccuracy, speed, course
        let localTimeStamp = CommUtil.date2string(Date(), format: "yyyy/MM/dd HH:mm:ss.SSS")!
        let gpsTimeStamp = CommUtil.date2string(loc.timestamp, format: "yyyy/MM/dd HH:mm:ss.SSS")!
        let latitude = loc.coordinate.latitude
        let longitude = loc.coordinate.longitude
        let altitude = loc.altitude
        let horizontalAccuracy = loc.horizontalAccuracy
        let verticalAccuracy = loc.verticalAccuracy
        let speed = loc.speed
        let course = loc.course
        
        self.curtLocation = data
        
        let gd = GpsData(lat: String(latitude), lng: String(longitude), timestamp: loc.timestamp)
        gd.altitude = String(altitude)
        gd.horizontalAccuracy = String(horizontalAccuracy)
        gd.verticalAccuracy = String(verticalAccuracy)
        gd.speed = String(speed)
        gd.course = String(course)
        if gpsDatas.count > 0 {
            gd.distance = gd.distanceTo(other: gpsDatas[gpsDatas.count - 1])
//        } else {
//            data.timestamp = dataService.saveTime
        }
        self.gpsDatas.append(gd)
//          let timestamp = CommUtil.date2string(Date(), format: "h:m:s.SSS")!
        var text = ""
//          text += timestamp + ","
        text += localTimeStamp + ","
        text += gpsTimeStamp + ","
        text += String(latitude) + ","
        text += String(longitude) + ","
        text += String(altitude) + ","
        text += String(horizontalAccuracy) + ","
        text += String(verticalAccuracy) + ","
        text += String(speed) + ","
        text += String(course)
        
        dataService.addRecordGpsText(addText: text)
        
    }

//    func getGPSData() {
////        if req != nil {
////            req!.stop()
////        }
//        gpsDatas = []
//        if curtLocation != nil {
//            // 開始時locationを出力
//            self.setLocation(data: curtLocation!)
//        }
//        // GPS情報取得確認
//        req = LocationManager.shared.locateFromGPS(.continous,
//                                                   accuracy: .house,
//                                                   distance: CLLocationDistance("-1"),
//                                                   activity: .otherNavigation,
//                                             timeout: .delayed(10)) {result in
//            switch result {
//              case .failure(let error):
//                print("Location error: \(error)")
//              case .success(let location):
//
//                if self.filterLocation(location) {
//                    print("New Location: \(location)")
//                    self.setLocation(data: location)
//                }
//            }
//        }
//        req?.dataFrequency = .fixed(minInterval: 5, minDistance: 5)
//    }
    
    // GPS精度向上
    private func filterLocation(_ location: CLLocation) -> Bool{
        let age = -location.timestamp.timeIntervalSinceNow
        // SwiftLocation value: 60(block)
        if age > 10{
            return false
        }
        // error data
        if location.horizontalAccuracy < 0{
            return false
        }
        // SwiftLocation value: 100(block)、60(house)
//        if location.horizontalAccuracy > 60{
//            return false
//        }
        
        return true
    }
    
    func startGPSData() {
        if let r = req {
            r.stop()
            req = nil
        }
        print("GPSリクストを開始します。")
        // GPS情報取得
        req = LocationManager.shared.locateFromGPS(.continous,
              accuracy: .house,
              distance: CLLocationDistance("-1"),
              activity: .otherNavigation,
              timeout: .delayed(10)) {[weak self] result in
//        req = LocationManager.shared.locateFromGPS(.continous,
//                accuracy: .block,
//                distance: CLLocationDistance("-1"),
//                activity: .otherNavigation
//        ) {[weak self] result in
            switch result {
            case .failure(let error):
                debugPrint("Received error: \(error)")
            case .success(let location):
                self!.curtLocation = location
                CommUtil.getLocationDesp(loc: self!.curtLocation!, onComplete: {desp in
                    self!.curtLocationDesp = desp
                })
                debugPrint("Location received: \(location), horizontalAccuracy: \(location.horizontalAccuracy)")
                
                // 採集中の場合、データ出力
                if self!.dataService.isRecording {
                    if self!.gpsDatas.count == 0 {
                        self!.setLocation(data: location)
                    }
                    // 採集中、精度向上
                    else if self!.filterLocation(location) {
                        print("Correct Location: \(location)")
                        self!.setLocation(data: location)
                    }
                }
            }
        }
        req?.dataFrequency = .fixed(minInterval: 5, minDistance: 5)
    }
    
    func stopGPSData() {
        if let r = req {
            r.stop()
            print("GPSリクストを停止しました。")
            req = nil
        }
    }
        
  // intervalSeconds 0.02 :50HZ, 0.01 :100HZ
    func startSensorUpdates(intervalSeconds:Double) {
        if !dataService.isRecording {
            return
        }
        
        if motionManager.isDeviceMotionAvailable{
            motionManager.deviceMotionUpdateInterval = intervalSeconds
            
            // start sensor updates
            motionManager.startDeviceMotionUpdates(to: OperationQueue.current!, withHandler: {(motion:CMDeviceMotion?, error:Error?) in
                self.getMotionData(deviceMotion: motion!)
                
            })
        }
    }
    
    func stopSensorUpdates() {
        if !dataService.isRecording {
            return
        }
        
        if motionManager.isDeviceMotionAvailable{
            motionManager.stopDeviceMotionUpdates()
        }
    }
    
    func getMotionData(deviceMotion:CMDeviceMotion) {
        attitude.x = deviceMotion.attitude.pitch
        attitude.y = deviceMotion.attitude.roll
        attitude.z = deviceMotion.attitude.yaw
        gyro.x = deviceMotion.rotationRate.x
        gyro.y = deviceMotion.rotationRate.y
        gyro.z = deviceMotion.rotationRate.z
        gravity.x = deviceMotion.gravity.x
        gravity.y = deviceMotion.gravity.y
        gravity.z = deviceMotion.gravity.z
        acc.x = deviceMotion.userAcceleration.x
        acc.y = deviceMotion.userAcceleration.y
        acc.z = deviceMotion.userAcceleration.z
        
//        displaySensorData()
        
        // record sensor data
        if dataService.isRecording {
            self.motionCnt += 1
            var newTime: Date?
            if self.motionStartTime == nil {
                self.motionStartTime = Date(timeIntervalSinceNow: (-1 * deviceMotion.timestamp))
            }
            newTime = Date(timeInterval: deviceMotion.timestamp, since: motionStartTime!)
            let timestamp = CommUtil.date2string(newTime, format: "HH:mm:ss.SSS")!
            var text = ""
            text += timestamp + ","
            text += String(format: "%.6f", acc.x + gravity.x) + ","
            text += String(format: "%.6f", acc.y + gravity.y) + ","
            text += String(format: "%.6f", acc.z + gravity.z)
            var text2 = ""
            text2 += timestamp + ","
            text2 += String(format: "%.6f", gyro.x) + ","
            text2 += String(format: "%.6f", gyro.y) + ","
            text2 += String(format: "%.6f", gyro.z)
            
            dataService.addRecordAccText(addText: text)
            dataService.addRecordAngVelText(addText: text2)
        }
    }
    
    func checkUnresovledData() -> Bool {
        let filePath = NSHomeDirectory() + AppConstants.TempDir + AppConstants.SubDir
        if self.dataService.isDirectory(filePath) {
            return true
        }
        return false
    }
    
    func startGetData(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.initWorkDir()
        
        self.motionCnt = 0
        dataService.startRecording()
//        getGPSData()
        startSensorUpdates(intervalSeconds: AppConstants.GetDataHZ100)
      
        // ①File1
        self.dataService.saveMeasurementCsv()
        // ②File2
        self.dataService.saveCarCsv()
        // ③File3〜5
        self.getDataTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ProcessService.saveSensorData), userInfo: nil, repeats: true)
        
        completionHandler(true)
    }
    
    func startGetDataWhenVideo(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.initWorkDir()
        dataService.initImgDir()
        
        self.motionCnt = 0
        dataService.startRecording()
//        getGPSData()
        startSensorUpdates(intervalSeconds: AppConstants.GetDataHZ100)
      
        // ①File1
        self.dataService.saveMeasurementCsv()
        // ②File2
        self.dataService.saveCarCsv()
        // ③File3〜5
        self.getDataTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ProcessService.saveSensorData), userInfo: nil, repeats: true)
        
        completionHandler(true)
    }
    
    @objc func saveSensorData() {
        print(CommUtil.date2string(Date())! + "save sensor data~~~")
        self.dataService.saveAccCsv()
        self.dataService.saveAngVelCsv()
        self.dataService.saveGpsCsv()
    }
    
    func stopGetData(completionHandler: @escaping ( Bool ) -> Void) {
//        stopGPSData()
        dataService.stopRecording()
        self.motionCnt = 0
        self.motionStartTime = nil
        if self.getDataTimer != nil {
            self.getDataTimer!.invalidate()
            self.getDataTimer = nil
        }
        // ファイル 圧縮
        self.dataService.makeZipFile()
        // callback
        completionHandler(true)
    }
    
    func stopGetDataWhenAbnormal(completionHandler: @escaping ( Bool ) -> Void) {
        dataService.stopRecording()
        self.motionCnt = 0
        self.motionStartTime = nil
        if self.getDataTimer != nil {
            self.getDataTimer!.invalidate()
            self.getDataTimer = nil
        }
        
        // callback
        completionHandler(true)
    }
    
    func stopGetDataWhenVideo(completionHandler: @escaping ( Bool ) -> Void) {
//        stopGPSData()
        dataService.stopRecording()
        self.motionCnt = 0
        self.motionStartTime = nil
        if self.getDataTimer != nil {
            self.getDataTimer!.invalidate()
            self.getDataTimer = nil
        }
        
        // 地図・写真用GPSファイル生成
        self.dataService.outputGPSInfo(datas: self.gpsDatas)
        self.gpsDatas = []
        print(CommUtil.date2string(Date())! + " データ採集終了.")
        
        // callback
        completionHandler(true)
    }
    
    func testGetGPSByDistance(){

        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX") // set locale to reliable US_POSIX
        dateFormatter.dateFormat = "yyyy/MM/dd HH:mm:ss.SSS"
        
        self.dataService.saveTime = dateFormatter.date(from:"2020/07/07 22:37:14.584")
        
        addGpsData(lat: "35.70170536640631", lng: "139.83006826614945", timestamp:"2020/07/07 22:37:14.997",speed: "10.9700002670288")
        addGpsData(lat: "35.701704989220666", lng: "139.8301870377174", timestamp:"2020/07/07 22:37:15.997",speed: "10.5200004577636")
        addGpsData(lat: "35.70170536640631", lng: "139.83030287561922", timestamp:"2020/07/07 22:37:16.997",speed: "10.3000001907348")
        addGpsData(lat: "35.70170192982601", lng: "139.83041427111237", timestamp:"2020/07/07 22:37:17.997",speed: "10.3000001907348")
        addGpsData(lat: "35.70169866088377", lng: "139.83052809735744", timestamp:"2020/07/07 22:37:18.997",speed: "10.0299997329711")
        addGpsData(lat: "35.701694679479765", lng: "139.83063722973674", timestamp:"2020/07/07 22:37:19.997",speed: "9.75")
        addGpsData(lat: "35.70169484711783", lng: "139.830748960506", timestamp:"2020/07/07 22:37:20.997",speed: "9.52999973297119")
        
        
        self.dataService.outputGPSInfo(datas: self.gpsDatas)
        self.gpsDatas = []
    }
    
    func addGpsData(lat:String, lng:String,timestamp:String,speed:String){
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX") // set locale to reliable US_POSIX
        dateFormatter.dateFormat = "yyyy/MM/dd HH:mm:ss.SSS"
        
        let gd1 = GpsData(lat: lat, lng: lng, timestamp: dateFormatter.date(from:timestamp)!)
        gd1.altitude = "21.640947341918945"
        gd1.horizontalAccuracy = "65.0"
        gd1.verticalAccuracy = "0.0"
        gd1.speed = speed
        gd1.course = "75.40720462092767"
        if gpsDatas.count > 0 {
            gd1.distance = gd1.distanceTo(other: gpsDatas[gpsDatas.count - 1])
        }
        self.gpsDatas.append(gd1)
    }

    func testGetImageFromVideo(){
        let fileManager = FileManager.default
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let mp4file = URL(fileURLWithPath: "か_data_20200711_114628/か_data_20200711_114627.mp4", relativeTo: documentsURL)
        let jpgfiles = URL(fileURLWithPath: "か_data_20200711_114628/", relativeTo: documentsURL)

        do {
            
            
            
            let fileURLs = try fileManager.contentsOfDirectory(at: jpgfiles, includingPropertiesForKeys: nil)

            for filePath:URL in fileURLs {
                if filePath.absoluteString.contains(".jpg") {
                    try FileManager.default.removeItem(at: filePath)
                    print("<<<<<<<<remove image>>>>>>>>")
                }
            }
        }catch{
            print("create file list error:\(error)")
        }
        
        let asset = AVURLAsset(url: mp4file)

        let assetIG = AVAssetImageGenerator(asset: asset)
        assetIG.appliesPreferredTrackTransform = true
        assetIG.apertureMode = AVAssetImageGenerator.ApertureMode.encodedPixels
        let lastFrameSeconds: Float64 = CMTimeGetSeconds(asset.duration)
        assetIG.requestedTimeToleranceBefore = CMTimeMake(value: 0, timescale: 30)
        assetIG.requestedTimeToleranceAfter = CMTimeMake(value: Int64(lastFrameSeconds), timescale: 30)
        
        outputImage(path: documentsURL, assetIG: assetIG, at: 0, order: 1 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.1, order: 2 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.2, order: 3 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.3, order: 4 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.4, order: 5 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.5, order: 6 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.6, order: 7 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.7, order: 8 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.8, order: 9 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 0.9, order: 10 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1, order: 11 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.1, order: 12 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.2, order: 13 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.3, order: 14 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.4, order: 15 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.5, order: 16 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.6, order: 17 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.7, order: 18 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.8, order: 19 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 1.9, order: 20 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2, order: 21 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.1, order: 22 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.2, order: 23 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.3, order: 24 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.4, order: 25 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.5, order: 26 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.6, order: 27 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.7, order: 28 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.8, order: 29 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 2.9, order: 30 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 3, order: 31 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 3.1, order: 32 )
        outputImage(path: documentsURL, assetIG: assetIG, at: 3.2, order: 33 )
//            let attr = try FileManager.default.attributesOfItem(atPath: mp4file.path)
//            let fileSize = attr[FileAttributeKey.size] as! UInt64
        
    }
    
    func outputImage(path: URL, assetIG: AVAssetImageGenerator, at time: TimeInterval,order: Int) {
        do {
//            let mp4file = URL(fileURLWithPath: "か_data_20200710_235645/か_data_20200710_235645.mov", relativeTo: documentsURL)
//            let capturingTime: CMTime = generateCMTime(movieURL: mp4file, time: time)
//            let image: CGImage = captureImage(movieURL: yourMovieURL, capturingTime: capturingTime)
            
            let image = imageFromVideo(assetIG: assetIG, at: time)
             let imageData = image!.jpegData(compressionQuality: CGFloat(AppConstants.imgCompressQuality))
             let picURL = URL(fileURLWithPath: "か_data_20200711_114628/test1-\(order).jpg", relativeTo: path)
             try imageData!.write(to: picURL)
            print("<<<<<<<<get image>>>>>>>>")
        } catch {
            print("create file list error:\(error)")
        }
    }
    
//    func generateCMTime(movieURL: URL, time: TimeInterval) -> CMTime {
//        let asset = AVURLAsset(url: movieURL, options: nil)
//        let lastFrameSeconds: Float64 = CMTimeGetSeconds(asset.duration)
//        let capturingTime: CMTime = CMTimeMakeWithSeconds(lastFrameSeconds * capturingPoint, 1)
//        return capturingTime
//    }
    
    func imageFromVideo(assetIG: AVAssetImageGenerator, at time: TimeInterval) -> UIImage? {
        let cmTime = CMTime(seconds: time, preferredTimescale: 30)
        CMTimeShow(cmTime)
        let thumbnailImageRef: CGImage
        do {
//            let cmTimeA = CMTime(seconds: 8.1, preferredTimescale: 60)
//            let cmTimeB = CMTime(seconds: 8.879, preferredTimescale: 60)
//            var number = 2
//            let aa = UnsafeMutablePointer<CMTime>.allocate(capacity: 2)
//            aa!. = cmTimeA
//            aa![1] = cmTimeB
            thumbnailImageRef = try assetIG.copyCGImage(at: cmTime, actualTime: nil)
        } catch let error {
            print("imageFromVideo Error: \(error)")
            return nil
        }

        return UIImage(cgImage: thumbnailImageRef)
    }
}
