//
//  Constants.swift
//  DRIMS_iPhone
//
//  Created by 黄海 on 2020/01/28.
//  Copyright © 2020 未来夢. All rights reserved.
//

import Foundation

struct AppConstants {
//    static let TestCarId = "hh"
//    static let TestWheelbase = 200
//    static let TestSensorPosition = 70
    
    static let TempDir = "/tmp/"
    static let DocumentDir = "/Documents/"
//    static let SubDir = "result/"
    static let SubDir = "data/"
    static let ImgDir = "img/"
    static let GetDataHZ100 = 0.01
    
    //    static let VideoFrameRate = 12
    static let VideoFrameRate = 30
    static let VideoExt = "mp4"
    static let imgCompressQuality = 0.95
    // 画像取得の間隔距離（メートル）
    static let DistanceForCapture: Double = 5.0
    
//     static let BackServer = "http://192.168.100.109:3000"
//    static let BackServer = "https://www.smc-road.com"
//    static let BackServer = "http://192.168.2.186:3000"
    static let BackServer = "http://52.194.247.101:3000"
    static let WebAPIUploadFiles = BackServer + "/public/uploadFiles"
}
