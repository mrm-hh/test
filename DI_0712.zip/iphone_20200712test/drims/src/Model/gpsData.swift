//
//  gpsData.swift
//  drims
//
//  Created by 黄海 on 2020/05/06.
//  Copyright © 2020 xiang yin. All rights reserved.
//

import Foundation
import CoreLocation

class GpsData: NSObject {
    var lat: String
    var lng: String
    var timestamp: Date?
    var distance: Double?
    
    var altitude = ""
    var horizontalAccuracy = ""
    var verticalAccuracy = ""
    var speed = ""
    var course = ""
    
    override init() {
        lat = ""
        lng = ""
        timestamp = nil
        distance = 0
        super.init()
    }
    
    convenience init(lat: String, lng: String, timestamp: Date?) {
        self.init()
        self.lat = lat
        self.lng = lng
        self.timestamp = timestamp
    }
    
    // distance: from self to other
    // unit: meter
    func distanceTo(other: GpsData) -> Double {
        var distance = 0.0
        let speed = (other.speed == "" ? 0 : Double(other.speed)!)
        if speed > 0.0 {
            let time = self.timestamp!.timeIntervalSince(other.timestamp!)
            distance = speed * time
        } else {
//            let nowLoc = CLLocation(latitude: Double(self.lat)!, longitude: Double(self.lng)!)
//            let toLoc = CLLocation(latitude: Double(other.lat)!, longitude: Double(other.lng)!)
//            distance = nowLoc.distance(from: toLoc)
            distance = 0
        }
        return distance
    }
    
    func toJSON() -> JSON {
        var json:JSON = JSON([:])
        json["timestamp"].string = CommUtil.date2string(timestamp, format: "yyyyMMddHHmmssSSS")
        json["lat"].string = lat
        json["lng"].string = lng
        json["distance"].string = String(self.distance!)
        return json
    }
    
    func toCSVLine() -> String {
        let text = CommUtil.date2string(timestamp, format: "yyyy/MM/dd HH:mm:ss.SSS")! + ","
                 + lat + ","
                 + lng + ","
                 + altitude + ","
                 + horizontalAccuracy + ","
                 + verticalAccuracy + ","
                 + speed + ","
                 + course
        return text
    }
}
