import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { NumberPipe } from './number.pipe';
import { DatePipe } from './date.pipe';
import { ConstantPipe } from './constant.pipe';
import { MessagePipe } from './message.pipe';

@NgModule({
  declarations: [
    NumberPipe,
    DatePipe,
    ConstantPipe,
    MessagePipe
  ],
  imports: [
    BrowserModule,
    CommonModule
  ],
  exports: [
    NumberPipe,
    DatePipe,
    ConstantPipe,
    MessagePipe
  ]
})
export class PipeModule { }
