import { Pipe, PipeTransform } from '@angular/core';
import _ from 'lodash';
import { Message } from '@typings/message';
import staticManager from '@utils/static-manager';

@Pipe({
  name: 'message'
})
export class MessagePipe implements PipeTransform {

  transform (message: Message): string {
    if (staticManager.user.messages[message.id]) {
      let text = staticManager.user.messages[message.id];
      _.each(message.replaces, one => {
        text = text.replace(one.key, one.value);
      });
      return text;
    } else {
      return '';
    }
  }

}
