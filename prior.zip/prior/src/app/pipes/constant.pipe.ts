import { Pipe, PipeTransform } from '@angular/core';
import { ConstantBase } from '@models/constants.model';
import staticManager from '@utils/static-manager';

@Pipe({
  name: 'constant'
})
export class ConstantPipe implements PipeTransform {

  transform (constantBase: ConstantBase): string {
    if (staticManager.user.constants[constantBase.type] && staticManager.user.constants[constantBase.type][constantBase.code]) {
      return staticManager.user.constants[constantBase.type][constantBase.code];
    } else {
      return '';
    }
  }

}
