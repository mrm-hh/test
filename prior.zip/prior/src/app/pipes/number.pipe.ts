import { Pipe, PipeTransform } from '@angular/core';
import BigNumber from 'bignumber.js';

@Pipe({
  name: 'number'
})
export class NumberPipe implements PipeTransform {

  transform (value: BigNumber, dp: 0 | 1 | 2 | 3 | 4 | 5 = 0): string {
    return value.toFormat(dp);
  }

}
