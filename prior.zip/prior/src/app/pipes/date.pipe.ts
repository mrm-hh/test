import { Pipe, PipeTransform } from '@angular/core';
import moment from 'moment';

@Pipe({
  name: 'date'
})
export class DatePipe implements PipeTransform {

  transform (value: moment.Moment): string {
    return value.format('YYYY/MM/DD');
  }

}
