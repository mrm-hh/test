import { User } from '@models/user.model';

class StaticManager {
  user: User;

  constructor () {
    this.user = null;
  }
}

export default new StaticManager();
