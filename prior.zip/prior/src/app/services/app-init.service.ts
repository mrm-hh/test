import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

import staticManager from '@utils/static-manager';
import { User } from '@models/user.model';

@Injectable()
export class AppInitService {

  constructor () {
  }

  initApp () {
    staticManager.user = new User();
  }

}
