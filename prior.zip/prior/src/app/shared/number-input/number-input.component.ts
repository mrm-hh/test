import { Component, Input, Output, EventEmitter } from '@angular/core';
import { InputBaseComponent } from '@shared/input-base.component';
import BigNumber from 'bignumber.js';

import { Message } from '@typings/message';

@Component({
  selector: 'app-number-input',
  templateUrl: './number-input.component.html',
  styleUrls: ['./number-input.component.scss']
})
export class NumberInputComponent extends InputBaseComponent {
  @Input() dp: number;
  @Input() max: number | BigNumber;
  @Input() min: number | BigNumber;
  @Input('value') set data (v: BigNumber) {
    this.value = v;
    if (this.value && !this.value.isNaN()) {
      this.text = this.value.toString();
    }
  }
  @Output() valueChange = new EventEmitter<BigNumber>();
  private value: BigNumber;
  text: string;

  constructor (
  ) {
    super();
  }

  get binder (): string {
    return this.text;
  }
  set binder (v: string) {
    this.innerMessage = null;
    const bn = new BigNumber(v);
    if (bn.isNaN()) {
      if (!v && this.required) {
        this.innerMessage = { id: 'U000' };
      }
      if (v) {
        this.innerMessage = { id: 'U003' };
      }
      this.valueChange.emit(null);
      return;
    }
    if (this.dp != null && bn.dp() > this.dp) {
      this.innerMessage = { id: 'U004', replaces: [{ key: '%VALUE%', value: `${this.dp}` }] };
      this.valueChange.emit(null);
      return;
    }
    if (this.min != null && bn.lt(this.min)) {
      this.innerMessage = { id: 'U001', replaces: [{ key: '%VALUE%', value: `${new BigNumber(this.min).toString()}` }] };
      this.valueChange.emit(null);
      return;
    }
    if (this.max != null && bn.gt(this.max)) {
      this.innerMessage = { id: 'U002', replaces: [{ key: '%VALUE%', value: `${new BigNumber(this.max).toString()}` }] };
      this.valueChange.emit(null);
      return;
    }
    this.valueChange.emit(bn);
  }

}
