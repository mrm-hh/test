import { Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';

import { Message } from '@typings/message';

export abstract class InputBaseComponent {
  @ViewChild('input', { static: true }) input: ElementRef;
  private timer: ReturnType<typeof setTimeout>;
  isTouched: boolean;

  @Input() message: Message;
  @Input() required: boolean;
  @Input() label: string;
  @Input() placeholder: string;
  innerMessage: Message;

  constructor (
  ) {
    this.innerMessage = null;
  }

  get hint (): Message {
    if (this.innerMessage) {
      return this.innerMessage;
    } else {
      return this.message;
    }
  }

  onFocus () {
    this.isTouched = true;
    if (!this.timer) {
      this.timer = setTimeout(() => {
        this.input.nativeElement.select();
        this.timer = null;
      }, 0);
    }
  }

}
