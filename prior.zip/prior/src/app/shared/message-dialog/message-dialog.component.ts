import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { IMessageDialog } from '@typings/message-dialog';
import staticManager from '@utils/static-manager';

@Component({
  selector: 'app-message-dialog',
  templateUrl: './message-dialog.component.html',
  styleUrls: ['./message-dialog.component.scss']
})
export class MessageDialogComponent {
  title = '';
  message = '';

  constructor (
    private dialogRef: MatDialogRef<MessageDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public config: IMessageDialog
  ) {
    this.dialogRef.disableClose = true;
    const message = staticManager.user.messages[config.id];
    if (message) {
      this.title = message.title;
      this.message = message.message;
    }
  }

}
