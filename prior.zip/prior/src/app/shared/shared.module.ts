import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaterialModule } from '../material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PipeModule } from '@pipes/pipes.module';

import { HeaderComponent } from './header/header.component';
import { SidenavListComponent } from './sidenav-list/sidenav-list.component';
import { LockUIComponent } from './lock-ui/lock-ui.component';
import { MessageDialogComponent } from './message-dialog/message-dialog.component';
import { SelectionDialogComponent } from './selection-dialog/selection-dialog.component';

import { NumberInputComponent } from './number-input/number-input.component';

@NgModule({
  declarations: [
    HeaderComponent,
    SidenavListComponent,
    LockUIComponent,
    MessageDialogComponent,
    SelectionDialogComponent,
    NumberInputComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    PipeModule
  ],
  exports: [
    HeaderComponent,
    SidenavListComponent,
    NumberInputComponent
  ],
  entryComponents: [
    LockUIComponent,
    MessageDialogComponent,
    SelectionDialogComponent
  ]
})
export class SharedModule { }
