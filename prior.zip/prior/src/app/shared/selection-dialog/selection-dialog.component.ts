import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ISelectionDialog } from '@typings/selection-dialog';
import staticManager from '@utils/static-manager';

@Component({
  selector: 'app-selection-dialog',
  templateUrl: './selection-dialog.component.html',
  styleUrls: ['./selection-dialog.component.scss']
})
export class SelectionDialogComponent {
  title = '';
  message = '';

  constructor (
    private dialogRef: MatDialogRef<SelectionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public config: ISelectionDialog
  ) {
    this.dialogRef.disableClose = true;
    const message = staticManager.user.messages[config.id];
    if (message) {
      this.title = message.title;
      this.message = message.message;
    }
  }

  excuteYes () {
    this.config.no = null;
  }

  excuteNo () {
    this.config.yes = null;
  }

}
