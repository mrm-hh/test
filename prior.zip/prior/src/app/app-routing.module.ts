import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// component
import { MainComponent } from './main/main.component';
import { TopComponent } from './main/top/top.component';
import { SettingComponent } from './main/setting/setting.component';

// utils
import { InitGuard } from './utils/init-guard';

const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      {
        path: '',
        component: TopComponent,
        canActivate: [InitGuard]
      },
      {
        path: 'setting',
        component: SettingComponent,
        canActivate: [InitGuard]
      }
    ]
  },
  { path: '**', component: MainComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
