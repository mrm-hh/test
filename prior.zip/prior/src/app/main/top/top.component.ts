import { Component, OnInit, AfterViewInit, OnDestroy, ViewChild, ElementRef, HostListener } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatDialog, MatSort } from '@angular/material';

import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import * as pluginDataLabels from 'chartjs-plugin-datalabels';

import * as XLSX from 'xlsx';
// import { IpcRenderer } from 'electron';
// declare var ipcRenderer: any;
// declare var remote: any;

import { ElectronService } from '../../services/electron.service';

import { Data } from '@models/data.model';

@Component({
  selector: 'app-top',
  templateUrl: './top.component.html',
  styleUrls: ['./top.component.scss']
})
export class TopComponent implements AfterViewInit {

constructor (
    private router: Router,
    private electron: ElectronService
  ) {
    this.scatterChartOptions.scales.xAxes[0].ticks.max = 30;
    this.scatterChartOptions.scales.yAxes[0].ticks.max = 0.4;

    this.datas = [
      new Data({
        rank: 1,
        line: '東北本線',
        direction: '上り',
        kilo: '12,345.67',
        category: '高低右（基準補正）',
        point: 150,
        displacement: 15.24456,
        progress: 0.312,
        days: 27.6,
        area: 'Ⅰ'
      }),
      new Data({
        rank: 2,
        line: '東北本線',
        direction: '下り',
        kilo: '12,345.67',
        category: '高低左（基準補正）',
        point: 140,
        displacement: 17.62,
        progress: 0.17,
        days: 29.5,
        area: 'Ⅱ'
      }),
      new Data({
        rank: 3,
        line: '日光線',
        direction: '上り',
        kilo: '12,345.67',
        category: '変面性',
        point: 130,
        displacement: 35.1,
        progress: 0.07,
        days: 40,
        area: 'Ⅲ'
      }),
      new Data({
        rank: 4,
        line: '日光線',
        direction: '下り',
        kilo: '12,345.67',
        category: '高低右（基準補正）',
        point: 90,
        displacement: 25.24456,
        progress: 0.19,
        days: 59.1,
        area: 'Ⅳ'
      }),
      new Data({
        rank: 5,
        line: '東北本線',
        direction: '上り',
        kilo: '12,345.67',
        category: '高低右（基準補正）',
        point: 150,
        displacement: 15.24456,
        progress: 0.312,
        days: 27.6,
        area: 'Ⅰ'
      }),
      new Data({
        rank: 6,
        line: '東北本線',
        direction: '下り',
        kilo: '12,345.67',
        category: '高低左（基準補正）',
        point: 140,
        displacement: 17.62,
        progress: 0.17,
        days: 29.5,
        area: 'Ⅱ'
      }),
      new Data({
        rank: 7,
        line: '日光線',
        direction: '上り',
        kilo: '12,345.67',
        category: '変面性',
        point: 130,
        displacement: 35.1,
        progress: 0.07,
        days: 40,
        area: 'Ⅲ'
      }),
      new Data({
        rank: 8,
        line: '日光線',
        direction: '下り',
        kilo: '12,345.67',
        category: '高低右（基準補正）',
        point: 90,
        displacement: 25.24456,
        progress: 0.19,
        days: 59.1,
        area: 'Ⅳ'
      }),
    ];
    this.dataSource.data = this.datas;
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        default: return item[property];
      }
    };
  }

  scatterChartOptions: ChartOptions = {
    responsive: true,
    hover: {
      mode: null
    },
    scales: {
      xAxes: [
        {
          ticks: {
            beginAtZero: true,
            max: 60
          }
        }
      ],
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            max: 1
          }
        }
      ]
    }
  };
  scatterChartLabels: Label[] = ['Eating', 'Drinking', 'Sleeping', 'Designing', 'Coding', 'Cycling', 'Running'];
  scatterChartData: ChartDataSets[] = [
    {
      data: [
        { x: 10, y: 0.1 },
        { x: 21, y: 0.3 },
        { x: 5, y: 0.2 },
        { x: 14, y: 0.14 },
        { x: 25, y: 0.23 },
        { x: 24.9, y: 0.235 },
      ],
      label: 'Series A',
      pointRadius: 10,
    },
  ];
  scatterChartType: ChartType = 'scatter';
  scatterChartLegend = false;
  @ViewChild('contentWrapper', { static: false }) private contentWrapper: ElementRef;
  @ViewChild('chartWrapper', { static: false }) private chartWrapper: ElementRef;

  displayedColumns: string[] = ['rank', 'line', 'direction', 'kilo', 'category', 'point', 'displacement', 'progress', 'days', 'area'];
  dataSource = new MatTableDataSource<Data>();
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  datas: Data[];

  @ViewChild('fileSelect', { static: true }) private fileSelect: ElementRef;

  @HostListener('window:resize', ['$event']) onResize (event) {
    this.resize();
  }

  ngAfterViewInit () {
    this.dataSource.sort = this.sort;
    this.resize();
  }

  resize () {
    const width = this.contentWrapper.nativeElement.offsetWidth;
    const height = this.contentWrapper.nativeElement.offsetHeight;
    if ((width / 2) > height) {
      this.chartWrapper.nativeElement.style.width = (height * 2) + 'px';
      this.chartWrapper.nativeElement.style.height = height + 'px';
    } else {
      this.chartWrapper.nativeElement.style.width = width + 'px';
      this.chartWrapper.nativeElement.style.height = (width / 2) + 'px';
    }
  }

  open () {
      // this.fileSelect.nativeElement.click();
      // this.ipc.send('callFile');
    this.electron.ipcRenderer.on('getData', (event, arg) => {
      console.log('getData: ' + arg);
    });
    this.electron.ipcRenderer.send('openFile');
  }


  output () {
    this.exportExcel();
  }

  public async exportExcel (): Promise < any > {
    const filename = 'test.xls';

    /* table id is passed over here */
    const element = document.getElementById('station-table');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    XLSX.writeFile(wb, filename);
  }

}
