import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { Subscription } from 'rxjs';

import eventManager from '@utils/event-manager';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
})
export class MainComponent implements OnDestroy {

  sidebarOpen = false;
  preScrollTop: number;
  trigger: boolean;
  scrollSubscription: Subscription;
  @ViewChild('appBody', { static: false }) private appBody: ElementRef;

  constructor () {
    this.trigger = false;
    this.scrollSubscription = eventManager.toTop.subscribe(() => {
      if (this.appBody) {
        this.appBody.nativeElement.scrollTop = 0;
      }
    });
  }

  ngOnDestroy () {
    if (this.scrollSubscription) { this.scrollSubscription.unsubscribe(); }
  }

  handleScroll (e) {
    if (this.preScrollTop > 0 && this.preScrollTop < e.srcElement.scrollTop) {
      if ((e.srcElement.scrollTop + e.srcElement.clientHeight) >= (e.target.scrollHeight - 100)) {
        if (!this.trigger) {
          this.trigger = true;
          eventManager.atBottom.next(true);
          setTimeout(() => {
            this.trigger = false;
          }, 200);
        }
      }
    }
    this.preScrollTop = e.srcElement.scrollTop;
  }

}
