import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import BigNumber from 'bignumber.js';

import { Conf } from '@models/conf.model';
import { Message } from '@typings/message';
import eventManager from '@utils/event-manager';

@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.scss']
})
export class SettingComponent {
  rankingConfs: Conf[];
  days = 30;
  progress = 0.15;
  test: BigNumber;
  message: Message;

  constructor (
    private router: Router
  ) {
    this.rankingConfs = [];
    [
      { rank: 10, point: 10 },
      { rank: 20, point: 8 },
      { rank: 50, point: 5 },
      { rank: 80, point: 3 },
      { rank: 100, point: 1 }
    ].forEach(one => {
      this.rankingConfs.push(new Conf(one));
    });
    this.test = new BigNumber(123456789.12);
    this.message = null;
  }

  sortConf () {
    this.rankingConfs.sort((a, b) => {
      if (a.rank == null && b.rank == null) {
        return 0;
      }
      if (a.rank == null && b.rank != null) {
        return 1;
      }
      if (a.rank != null && b.rank == null) {
        return -1;
      }
      return a.rank > b.rank ? 1 : -1;
    });
  }

  addConf () {
    this.rankingConfs.push(new Conf({ rank: null, point: null }));
  }

  removeConf (i: number) {
    this.rankingConfs.splice(i, 1);
  }

  initConf () {
    this.rankingConfs = [new Conf({ rank: null, point: null })];
  }

  save () {
    eventManager.messageDialog.next({
      id: 'I001',
      next: () => {
        this.router.navigate(['/']);
      }
    });
  }

}
