export type Lock = {
  lock: boolean;
  key: string;
}
