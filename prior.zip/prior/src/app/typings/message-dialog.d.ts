export interface IMessageDialog {
  id: string;
  next?: () => void;
}
