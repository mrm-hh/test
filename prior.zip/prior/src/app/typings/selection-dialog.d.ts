export interface ISelectionDialog {
  id: string;
  yes?: () => void;
  no?: () => void;
}
