export type Message = {
  id: string;
  replaces?: [{ key: string, value: string }];
}
