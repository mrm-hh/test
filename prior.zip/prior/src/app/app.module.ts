import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { FlexLayoutModule } from '@angular/flex-layout';
import { ChartsModule } from 'ng2-charts';
import { MaterialModule } from './material.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { PipeModule } from './pipes/pipes.module';

import { MainComponent } from './main/main.component';
import { TopComponent } from './main/top/top.component';
import { SettingComponent } from './main/setting/setting.component';

// services
import { AppInitService } from './services/app-init.service';
import { ElectronService } from './services/electron.service';

// utils
import { InitGuard } from './utils/init-guard';

import { Observable } from 'rxjs';

export const MY_FORMATS = {
  parse: {
    dateInput: 'YYYY/MM/DD',
  },
  display: {
    dateInput: 'YYYY/M/D',
    monthYearLabel: 'YYYY/MMM',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY/MMMM',
  },
};

export function appFactory (appInitService: AppInitService) {
  return (): Observable<void> => {
    appInitService.initApp();
    return;
  };
}

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    TopComponent,
    SettingComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never'}),
    FormsModule,
    MaterialModule,
    ChartsModule,
    FlexLayoutModule,
    MaterialModule,
    SharedModule,
    PipeModule
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: appFactory,
      deps: [AppInitService],
      multi: true
    },
    InitGuard,
    AppInitService,
    ElectronService,
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }
