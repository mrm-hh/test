export class Data {
  rank: number;
  line: string;
  direction: string;
  kilo: string;
  category: string;
  point: number;
  displacement: number;
  progress: number;
  days: number;
  area: string;

  constructor (data) {
    this.rank = data.rank;
    this.line = data.line;
    this.direction = data.direction;
    this.kilo = data.kilo;
    this.category = data.category;
    this.point = data.point;
    this.displacement = data.displacement;
    this.progress = data.progress;
    this.days = data.days;
    this.area = data.area;
  }
}
