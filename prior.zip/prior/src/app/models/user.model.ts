import constantsJa from '@jsons/constants.ja.json';
import messagesJa from '@jsons/messages.ja.json';

export class User {
  language: 'ja' | 'en';
  constants: any;
  messages: any;

  constructor () {
    this.language = 'ja';
    switch (this.language) {
      case 'ja':
        this.constants = constantsJa;
        this.messages = messagesJa;
        break;
      default:
        // this.constants = constantsEn;
        // this.messages = messagesEn;
    }
  }

}
