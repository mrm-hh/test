export class Conf {
  rank: number;
  point: number;

  constructor (data) {
    this.rank = data.rank;
    this.point = data.point;
  }

  isValid (): boolean {
    return this.rank > 0 && this.point > 0;
  }

}
