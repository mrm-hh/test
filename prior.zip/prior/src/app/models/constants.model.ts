import _ from 'lodash';

export class ConstantBase {
  type: string;
  code: string;

  constructor (type: string, code: string) {
    this.type = type;
    this.code = code;
  }

  isEqual (constant: ConstantBase): boolean {
    return this.type === constant.type && this.code === constant.code;
  }
}

export class Product extends ConstantBase {
  isInterestSwap: boolean;

  constructor (code: string, isInterestSwap: boolean) {
    super('product', code);
    this.isInterestSwap = isInterestSwap;
  }
}

export class Frequency extends ConstantBase {
  constructor (code: string) {
    super('frequency', code);
  }
}

class ConstantManager {
  product = {
    irs: new Product('IRS', true),
    xcs: new Product('XCS', true)
  };
  frequency = {
    oneMonth: new Frequency('1M'),
    threeMonth: new Frequency('3M'),
    sixMonth: new Frequency('6M')
  };

  createConstant (type: string, code: string) {
    if (this.hasOwnProperty(type)) {
      const group = this[type];
      for (const key in group) {
        if (group.hasOwnProperty(key)) {
          if (group[key].code === code) {
            return _.cloneDeep(group[key]);
          }
        }
      }
    }
  }
}

export default new ConstantManager();
