// const {shell} = require('electron');
const { dialog } = require('electron');
const fs = require('fs');
const fsPromises = fs.promises;
const app = require('electron').app;

// ファイル呼び出しボタンが押されたとき
exports.openFile = function (event) {
  // shell.openItem('test.csv');
  const rootPath = app.getAppPath();
  const filePath = rootPath + "/test.csv";
  fsPromises.access(filePath, fs.constants.R_OK | fs.constants.W_OK)
    .then(() => {
      var text = fs.readFileSync(filePath, 'utf8');
      showMessageBox(filePath, text);
      event.sender.send('getData', text)
    })
    .catch(() => showMessageBox("File not found.", "ファイルが見つかりませんでした。"));
}

// ダイアログメッセージ表示
function showMessageBox(msg, detail) {
  var options = {
    type: 'info',
    buttons: ['OK'],
    title: 'Local Message',
    message: msg,
    detail: detail
  };

  dialog.showMessageBox(null, options);
}